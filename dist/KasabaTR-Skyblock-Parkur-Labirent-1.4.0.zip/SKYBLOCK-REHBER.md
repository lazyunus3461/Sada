# KasabaTR Skyblock 1.3.0

Paper 1.21.10 / Java 21. Bu sürümü KasabaHub 1.12.2, KasabaRoles 1.6.2 ve KasabaEvcil 1.2.1 ile kur. Mevcut KasabaAuth ve KasabaAkce eklentileri ağda kalır. Dağıtım canlı sunucuya otomatik kurulmaz.

## Oyuna başlama

`/sb gir` → `/sb olustur`. Tek kalıcı `kasabatr_skyblock` dünyasında her ada tam 100×100 bloktur; komşu merkezler 2048 blok aralıklıdır. Yükseklik Minecraft'ın -64…319 aralığıdır. Yetkisiz ada erişimi kapalıdır. Oyuncular gizlenir; `show-island-members: true` takım arkadaşlarını gösterir. Varsayılan takım 4 kişidir.

Başlangıç sandığı adanın içindedir: taş kazma, taş çapa, çalışma masası,16 ekmek, su, yedek fidan, tohumlar, havuç, patates, kemik tozu, toprak, kum, kamış, kaktüs, meşale ve rehber kitap. Sandığın gerçek envanteri kaydedilir; tekrar giriş sandığı doldurmaz. Eski adanın sahibi `/sb baslangic` ile bir kez taş kazma/çapa,8 ekmek ve 8 tohum alabilir. Yeni adanın sandığı varken bu ek destek verilmez.

Hazır jeneratör adanın içinde 6×3 blokluk su/lav kanalıdır; kaynakların üstünde demir tuzak kapakları ve çevresinde güvenlik kenarları vardır. Maden çekirdeği doğma merkezinden 2 blok doğu ve 1 blok kuzeydedir. Kaynaklar, kapaklar ve çerçeve korunur; yalnız çekirdek kazılır. Kırılan çekirdek bir sonraki oyun tikinde yenilenir;20 TPS'de yaklaşık 50 ms. İlk şanslar: %70 kırık taş, %10 kömür, %8 demir, %8 bakır, %4 lapis. İlerleyen beş seviyede bu üç maden korunur; üst cevherler eklenir. Oyuncunun yerleştirdiği cevher görev sayılmaz. `/sb jenerator` eski adada uygun boş 6×3 alan varsa dönüştürür; oyuncu yapısını zorla silmez. Değiştirilmemiş eski ek jeneratör tanınırsa kaldırılır; oyuncunun değiştirdiği alan korunur.

## İlk Yardım ve görevler

`/sb rehber` ve Usta Poyraz aynı kısa rehberi açar. Dokuz aşama: sandık → ağaç →32 jeneratör bloğu →16 ürün satışı → kendi adanda 8 olgun hasat → ilk iki madenci ödülü → üretici minyon → ekmek yüklenmiş Bakıcı → ileri hedefler. Tamamlanma gerçek işlemlerden hesaplanır; düğmeye basarak tamamlanmış gösterilmez. Her sayfanın Hedefi aç düğmesi ilgili menüye veya adaya götürür.

`/gorevler`: madencilik, tarım, balıkçılık, avcılık, yapı.40 görev vardır:32 kalıcı,4 günlük,4 haftalık. Açıklama, kalan miktar, ödül ve kilit durumu görünür. Hazır ödüle tıkla. İlk 32 blok 200 Altın, toplam 128 blok 300 Altın verir: ilk minyonun 500 Altını. **Görev ödülü ortak ada kasasına, satış parası kişisel cüzdana gider.** Ada kasası sağ panelde görünür. Ödül takım için bir kez verilir. Günlükler Türkiye saati 00.00, haftalıklar pazartesi 00.00 yenilenir. Alınmış eski ödüller korunur; yeni ilk ödül tutarı geriye dönük tekrar ödenmez.

`/sb teslim`:3 günlük,3 haftalık,3 aylık malzeme siparişi; eksikler parçalı verilir. Bir dönemin üçünü bitirmek %25 sözleşme Altını ve ek Mühür kazandırır. Günlük değişim bedeli 100 ada Altını; günde en fazla 3 değişim. Teslimatlar görev sayaçlarından ayrıdır.

Rehberi çağır/gizle: `/sb rehber yanima`, `/sb rehber kapat`, `/sb rehber ac`.

## Market ve kişisel hasat bahçesi

`/market` ilk ekranda **SATIN AL** ve **ÜRÜN SAT** olarak ayrılır. Alış yolunda 9 kaynak kategorisi, satış yolunda çantandaki satılabilir ürünler görünür. Özel tezgâhlar ve kişisel hasat bahçesi de menüdedir. Ürünler gerçek malzeme simgelerini kullanır. Alış yeşil, satış altın rengindedir. Ürün → adet → toplam → ONAYLA. Ürüne tekrar tıklamak+1; ±1/16/64 düğmeleri vardır. Adet seçmek ödeme yapmaz. Tam dolu çanta/yetersiz bakiye işlemi geri alır. Satış sadece normal, özel adı/verisi olmayan eşyaları tüketir. Kaynak marketi adası olmayan Skyblock oyuncusuna da açıktır.

Satış ekranı yalnız çantandaki satılabilir ürünleri gösterir. Özel tezgâhlardan minyon,12 tür spawner, oyuncu pazarı, VIP/Kredi, Mühür ödülleri ve VIP haklarına ulaşılır. VIP yıldız, uçuş elytra, minyon kazma gibi amacına uygun simgelerle gösterilir.

`/warp sb tarla` seni **yalnız senin etkileşebildiğin kişisel bahçene** götürür. Her oyuncunun 80 olgun buğdayı ve ilk başarılı girişle başlayan kendi 15 dakikalık yenilenme saati vardır. Başkasının girişi senin süreni değiştirmez; çıkıp girmek süreyi veya ürünleri sıfırlamaz. Bilgi menüsünü açmak saati başlatmaz. Kalan süre ve ürün sayısı panelde görünür. Süre dolduğunda senin bahçen yeniden dolar; kullanılmayan ürünler birikmez.

Olgun buğdayı biçince 1 buğday doğrudan çantana gelir; çanta doluysa ürün ve hakkın korunur. Toprak, su ve çevre korunur; başka oyuncu bahçene ışınlanamaz veya hasat yapamaz. **Çiftçi Efe** satış ekranını açar; normal buğday satışı 4 Altındır. Böylece bir tam bahçe VIP bonusu olmadan 320 Altın, saatte en çok 1.280 Altın sağlar. Bu alan kendi ada tarım görevini ilerletmez. Kalan ürünler ve süre yeniden başlatmada saklanır. Kasaba merkezindeki tarla dekoru ve havadaki yazılar bu özel bahçeden ayrıdır.

`/sb banka`: kişisel cüzdan ve ada kasası ayrıdır. Üye yatırabilir; yalnız sahip çekebilir. **Topluluk pazarı** `/sb pazar` veya `/market` içindeki düğmeden açılır. Elindeki ürünü seç → adet → bütün ilanın toplam fiyatı → Yayınla. İlanlarım, satın alma ayrıntısı ve geri alma ekranları vardır. Sınır 5 ilan/24 saat, satış vergisi %5; kazanç satıcının kişisel cüzdanına gider. Süresi dolan ilan satılamaz ama eşya silinmez; sahibi geri alır. Alıcı/satıcı/emanet/eşya kayıtları aynı işlemde yazılır. Tam dolu çanta ve yetersiz para ilandaki eşyayı kaybettirmez; kendi ilanını satın alamazsın.

## Minyonlar

Özgün, yaklaşık bir blok boyunda küçük işçi figürleri: mesleğe göre renkli şapka/önlük, yüz, araç ve çalışma animasyonu. Kaynak paketi veya dışarıdan oyuncu kaplaması indirilmez. `/sb minyon` ile yönetilir. Taşçı/Oduncu/Çiftçi/Balıkçı üretir; **Bakıcı ekmek dağıtır**. Kurulum 500 ada Altını + türüne uygun 32 ürün; Bakıcı için 32 ekmek. Kurulum malzemesi depo veya enerji değildir.

**Taşçı hazır jeneratörün yanına kurulur.** Önündeki gerçek jeneratör çekirdeğinde ne çıktıysa onu demir kazma kurallarıyla kırar: taş/kırık taş, kömür, ham demir, ham bakır, lapis, kızıl taş, ham altın, elmas veya zümrüt. Oyuncunun yapısını kazmaz; ürettiği bloklar oyuncuya görev veya XP sayılmaz. Seviye 1/2/3 çalışma aralığı Taşçı için 4/2,5/1,5 saniye, diğer üreticiler için 30/20/10 saniyedir.

**Oduncu** önündeki düz 3×3 alanda gerçek meşe fidanı diker, büyütür, üç gövdeyi sırayla keser ve yeniden diker. 5 blok boş yükseklik bırak. Alan başka bir yapıyla doluysa işe başlamaz; sonradan oyuncunun koyduğu bloğu kesmez ve yakıt harcamadan bekler. Kendi ağacına müdahale etmek yerine minyonu taşı/kaldır. Her üretim işlemi 1 meşe odunu verir; görsel ağaç ayrıca ücretsiz elle kazılamaz. Çevrimdışı aynı süre/yakıt/depo sınırlarıyla hesaplanır; chunk zorla açılmaz.

Her minyonun yanında **kendi sandığı** vardır. Ürünler otomatik bu sandığa gider; sandığa sağ tıkla veya `/sb minyon sandik 1` kullan. Artık “Depoyu topla” adımı yoktur. Eski sayısal depo mevcut eşyalar korunarak sandık içeriğine bir kez dönüştürülür. Başlangıçta 9 yuva açıktır; minyon seviyesi ve ada depolamasıyla en çok 54 yuva açılır. Açık yuva sayısı `min(54, 9 × minyon seviyesi × ada depo seviyesi)` olur. Kilitli yuvalar belirgindir. Dolu sandıkta üretim ve yakıt tüketimi durur. Erişim verilen kooperatif/üyeler aynı güncel içeriği görür. Fiziksel sandık bu kayıtlı depoyu açar; huniyle aktarım bu sürümde desteklenmez.

Üreticiye 1 kömür veya 1 ekmek eklemek varsayılan 30 dakika enerji verir. **Bakıcı sandığına normal ekmek koy.** Bakıcı ihtiyacı olan ve ürün için yeri bulunan üreticiye gerçek bir ekmek tüketerek 30 dakika enerji aktarır; başka ürün kabul etmez. Yiyecek yokken ücretsiz üretim yoktur. Çevrimdışı hesap tek seferde en fazla 6 saat; enerji ve kapasiteyle sınırlıdır. Çevrimdışı ada sürekli yüklü tutulmaz.

Başlangıç 2 yuva, geliştirmeyle 6; üç minyon seviyesi ve üç ada depo seviyesi. Kaldırmadan önce sandığındaki eşyaları al; kalan enerji ayrıca onaylanarak silinir. Normal spawner/huni/yaratık sınırları 4/16/32'dir.

## Depolu spawner

`/sb spawner` veya marketteki spawner tezgâhı. 12 tür vardır: Domuz, İnek, Koyun, Tavuk, Zombi, İskelet, Örümcek, Blaze, Enderman, Cadı, Guardian ve Demir Golem. **Dünyaya canlı doğurmaz.** Türüne ait normal ürünleri 45 saniyelik çevrimlerle kendi deposunda biriktirir. Hayvanlarda çiğ et ve türe göre deri/yün/tüy; canavarlarda kemik, ip, blaze çubuğu gibi gerçek satış ürünleri kullanılır. Spawner XP üretmez, avcılık görevinin yerine geçmez.

Adada veya sunucuda bulunman gerekmez. Yüklenmemiş adanın üretimi sonraki erişimde geçmiş zamandan hesaplanır; varsayılan tek hesapta en fazla 6 saat ve **3456 eşya** sınırı vardır. Dolu depoda geriye dönük sınırsız üretim saklanmaz. Süre ayarı `spawners.maximum-offline-hours` (varsayılan6) olur. Eski kayıtlı spawnerlar tür/konum korunarak boş depo ve güncel başlangıç saatiyle dönüştürülür; bilinmeyen geçmişten ücretsiz ürün verilmez.

Spawner üstündeki yazı depo durumunu gösterir. Sağ tık → ürün/64 al, hepsini al veya satış onayı. Ürün alımına çantada yer yoksa depoda kalır. Satış normal market fiyatı ve varsa gerçek VIP satış bonusuyla kişisel Altın cüzdanına ödenir. Dolu spawner kırılmaz; önce ürünleri al/sat. Yerleştirme, depo ve kaldırma ada sahibine aittir. Ada başına mevcut4spawner sınırı ve satın alma seviye/fiyatları korunur.

## Otomatik hasat pistonu

`/sb piston` veya Diğer işlemler → **Otomatik hasat pistonu**. 500 ada Altını +32 kırık taş; OP test modunda ücretsizdir. Aldığın özel pistonu tarla kenarına yerleştir; yerleştirirken baktığın yöne çalışır. Önündeki **3 blok geniş ×5 blok uzun** alanı tarar. Bitkiler pistonla aynı yükseklikte, tarla zemini bir blok altında olmalı.

Olgun buğday/havuç/patates/pancar toplanır ve çıkan üründen bir ekim malzemesi ayrılarak yeniden ekilir. Kamış, bambu ve kaktüsün dip bloğu kalır; üstleri alınır. Karpuz ve bal kabağı da toplanır. Olgunlaşmamış bitki kesilmez. Gerçek ürünler kendi3456eşyalık deposuna girer. Depo doluyken bitki olduğu gibi kalır. Sağ tıkla ürünleri al veya onayla sat; satılamayan tohumlar depoda kalır. Depolu piston kırılmaz. Varsayılan ada başına4adet, ayar `limits.harvest-pistons` olur.

Piston gerçek bitki toplar; alan yüklüyken sen adanın başka yerindeyken de çalışır. **Minecraft'ın yüklenmemiş alanda büyümeyen bitkilerinden çevrimdışı ürün uydurmaz ve chunk zorla yüklemez.** Spawner/minyonun çevrimdışı hesabı bundan ayrıdır. Tarama2saniyede, güvenli kayıt ve depo aktarımı en fazla10saniyede tamamlanır. Kayıt sırasında bitkiye su dökme/kırma gibi müdahaleler kısa süre korunur. Hasat günlüğü → dünya disk kaydı → depo işlemi sırası eşya çoğalmasını önler. Dünya dışı yüksekliğe yerleştirme reddedilir.

## Kişisel sandıklar

`/chest` menüsü veya `/chest 1`…`/chest 4`. Her sayfa 54 yuva; yalnız sahibi açar. Oyuncu 1, Gezgin/VIP 2, Usta/VIP+3, Mimar/VIP Ultra 4 sayfa. Ayar: `chests.pages-by-tier`; ek izinler `kasabaskyblock.chest.1`…`.4`. OP dört sayfayı açabilir. VIP bitince kilitli sayfanın eşyaları silinmez. Sandık hareketi, kişisel çanta ve imleç birlikte kalıcı kaydedilir. Skyblock dışındaki oyun çantalarıyla karışmaz.

## Ölüm, dönüş ve ada havası

**Skyblock oturumunda ölümde eşya ve deneyim korunur.** Lav dahil normal ölümlerde yere eşya/XP bırakılmaz; güvenli ada doğma noktasına dönülür. Boşluk kurtarması sürer. Bu düzeltme kurulmadan önce lavda yok olmuş ve kayıtta bulunmayan eşyaları kendiliğinden geri getirmez. Son ölüm profili yönetici incelemesi için tutulur; oyuncuya eşya çoğaltabilecek geri alma düğmesi verilmez.

Oyunlar menüsünden tekrar giriş, son kaydedilen **güvenli ve hâlâ izinli** Skyblock konumunu/yönünü geri yükler. Boşluk, lav, engellenmiş veya erişimi bitmiş ada konumu yerine güvenli doğma noktası kullanılır. Konum çanta işlemlerinden ayrı tutulur; normal çıkışta ve düzenli kayıtta korunur.

Ada sahibi `/sb set kar`, `/sb set yagmur`, `/sb set gunes` veya Skyblock içindeyken `/set kar|yagmur|gunes` kullanır; `/sb set` menüyü açar. Yalnız bu adadaki oyuncular aynı havayı görür. Diğer adalar ve dünya genelindeki hava değişmez. Kar için adanın dikey iklimi SNOWY_PLAINS; yağmur/güneş için PLAINS olur. İklim birkaç saniyede parça parça güncellenir. Ada sınırında biyomlar Minecraft'ın 4 blokluk çözünürlüğünü kullanır; komşu adalar 2048 blok uzaktadır. Bu görsel yerel yağıştır: kar biriktirme, buz oluşturma veya küresel fırtına başlatılmaz. Ayar kalıcıdır; adadan ayrılınca kişisel hava geri sıfırlanır.

Tavuklar yumurta bırakır; **Skyblock'ta atılan yumurtalardan civciv çıkmaz**. Skyblock ve ağ spawnında çağırma yumurtaları/çoğalma/dağıtıcı yumurtası kapalıdır; özel adada izinli hayvan çağırma yumurtası kullanılabilir.

## Arkadaşlar, yetkiler ve warp

`/sb davet Oyuncu` → `/sb kabul`: kalıcı takım. `/sb ziyaret davet|kabul|git|ayril|bitir` ve `/sb koop ...`: kişiye özel 30 dakikalık geçici erişim,60 saniyelik davet kabul süresi. En fazla 8 geçici erişim. `/sb ayarlar`: üye, ziyaretçi ve kooperatif için 17 ayrı yetki. Kasa çekme, geliştirme, spawner ve hava ayarı sahibe aittir.

`/warp sb lobi|market|gorev|atolye|muhur|vip|rehber|adalar|siralama|tarla|iskele`. `/spawn` Skyblock meydanına, `/lobi` ağın ana lobisine döner. `/sb ev` kendi adanın doğmasına gider. Sağ panel, hedef çubuğu ve TAB kısayolları vardır; `/sb panel kapat|ac` paneli yönetir.

## VIP, Kredi ve Mühür

Altın Skyblock parasıdır; Akçe ve Kredi ayrı tutulur. Kredi konsoldan `sb kredi ver Oyuncu miktar`; Mühür `sb muhur ver Oyuncu miktar`. VIP paketleri özgündür: Gezgin 120 Kredi/30 gün, Usta 220, Mimar 360; sırasıyla VIP/VIP+/VIP Ultra. Mühürlerle 7 günlük Gezgin ve başka ödüller alınabilir. Gerçek para ödeme sistemi bu paketin parçası değildir; mevcut mağaza başarılı ödeme sonrası konsol komutunu çalıştırabilir.

VIP satış bonusu %5/10/15; uçuş, süreli tamir/doyurma, sanal masalar ve günlük hediyeler. `/sb vip`, `/sb ucus`, `/sb tamir`, `/sb tamir hepsi`, `/sb doyur`, `/sb vipgunluk`. Normal Skyblock/VIP uçuşu sabit vanilla hızındadır; VIP veya Skyblock menüsünde hız seçici yoktur. Eski oyuncu hız tercihleri uygulanmaz. Önceden istenen yönetici aracı `/ucushizi 1–10` yalnız OP/yöneticiye açıktır ve her yerde çalışır; tek başına uçuş hakkı vermez.

Evcil: `/evcil`, `/evcil kapat` veya `/evcil gizle`, `/evcil ac` veya `/evcil goster`. Son sahip olunan seçimi hatırlar; tekrar göstermek satın alma değildir. Hem sunucu çarpışması hem istemci scoreboard çarpışması kapalıdır. Maçlarda gizlenir. Akçe ile evcil satın alma Skyblock Kredisinden ayrıdır.

## Yetkili görüntüleme ve ağaç yıkılması

- `/envanter Oyuncu`: çevrimiçi oyuncunun o anki envanterini canlı görüntüler. Çevrimdışı bilinen oyuncuda son Skyblock envanter kaydı açılır.
- `/chest Oyuncu [1-4]`: oyuncunun Skyblock kişisel sandık sayfasını görüntüler. Normal `/chest 1`…`4` kendi sandığını açmaya devam eder. Başkasını görüntülemek VIP vermez.
- `/sb ada Oyuncu` veya `/sb ada oyuncu Oyuncu`: hedef çevrimdışı olsa da adasına gider. Ağ lobisi/başka oyundan güvenli Skyblock geçişi yapılır. Ada üyeliği değişmez; normal inşaat/ürün alma izni verilmez. `/sb ev` kendi adana döner. Bilerek açtığın yönetici düzenleme modu ayrı kalır.

Bu araçlar yalnız OP/yönetici veya `kasabaskyblock.inspect` yetkisindedir. Envanter/sandık ekranları **salt okunurdur**: tıklama, shift, sürükleme, diğer el ve sayı tuşlarıyla eşya alınamaz veya konamaz. OP/yetki kalkınca görüntüleme kapanır; ziyaret edilen özel adadan kendi adana dönülür.

Ağaç devrilmesi: yaşayan, yapraklı ağacın **en alttaki kütüğünü** kır. %75 ihtimalle kalan ağaç düşme animasyonuyla kırılır, ürünler çantana gelir; %25 ihtimalde tek kütük kırılır. Eğilerek kırmak veya oyuncunun inşa ettiği kütük yapısı tek blok davranışıdır. Normal oyun Survival modundadır. Yaratıcı moddaki yapı işlerini otomatik kesmez; **OP için `/sb test ac` açıkken yaratıcı modda da test edilebilir.**

## OP testi ve bakım

**`/sb test ac`**: kendi adası olan OP için isteğe bağlı test. Normal market alışları, minyon kurma/besleme/yükseltme, spawner ve ada geliştirmeleri ücretsiz; malzeme ve ada seviyesi aranmaz. Tamir/doyurma/günlük hediye beklemeleri test boyunca uygulanmaz ve normal bekleme kaydını tüketmez. En üst VIP kolaylıkları test boyunca açıktır; hesaba gerçek kalıcı VIP paketi yazılmaz. Mühür/Kredi kaynak tezgâhlarında bakiye harcanmaz. Gerçek oyuncu pazarındaki başkasının ilanı bedava alınmaz. Sahiplik, ada erişimi, doğma koruması ve üretim kapasitesi sınırları sürer. Spawn yumurtası yasağı OP testinde de geçerlidir.

`/sb test kapat` normal kuralları geri getirir. Test eşyaları ve yapılan ada geliştirmeleri kalır; bu bir geri alma komutu değildir. OP kaldırılınca ayrıcalıklar anında etkisizdir. Öncü test modu kullanamaz. Ana menüde OP test düğmesi ve panelde açık durumu görünür.

Öncü rolü (`/rol ver Oyuncu oncu`) ve beta destekçisi (`/beta ver Oyuncu`) bakımdaki **çalışır** oyunlara girebilir. Bakım kapatma, rol yönetimi, harita düzenleme veya OP verilmez. Rol/rozet kaldırılınca yeni bakım giriş hakkı da kalkar. İzin düğümü: `kasabahub.maintenance.bypass`.

OP/yönetici ada oluştururken 24 saat beklemez. `/sb OyuncuAdı 24 saatkaldir` yalnız ada kurma beklemesini kaldırır; konsol/OP/yönetici kullanır, çevrimdışı bilinen hedef de olur. `/yonet duzenleme ac` OP'nin bulunduğu Skyblock alanını düzenler; test modu farklı bir ayardır.

## Kurulum, kayıt ve doğrulama

Sunucuyu durdurarak dünya+`plugins/KasabaSkyblock`+Roles+Evcil veri klasörlerini birlikte yedekle. SQLite WAL yan dosyalarını çalışırken ayrı kopyalama. Veri klasörlerini/dünyaları silmeden yeni Skyblock 1.3.0 ve Parkur 1.2.1 JAR'larını değiştir (1.3.0 dağıtım paketinden geliyorsan diğer dört JAR aynıdır); aynı eklentinin eski JAR'ı kalmasın. `/reload` kullanma. `skyblock.db` para, adalar, görevler, minyonlar, sandıklar, profiller ve hava ayarlarını içerir. `ada`/KasabaAdalar ayrı oyundur. Towny/Sikke/Vault/Chunky eklenmez.

Paketin TEST-SONUCLARI.json dosyasında yeni derleme ve yerel Paper testleri, tarihsel testlerden ayrıdır. Özel audit adaptörleri ve test oyuncu verileri dağıtılmaz. Erişilebilen referans video kareleri ve açık kaynak mekanik belgeleri incelendi; Google/YouTube erişimi engelliyken 10 güncel video izlendiği iddia edilmez. Araştırma notları pakettedir.
