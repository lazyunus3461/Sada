# Hasat ve minyon düzenlemesi için araştırma notu

## Kaynağı gerçekten okunan mekanikler

- [NEU Cobblestone Minion I kaydı](https://raw.githubusercontent.com/NotEnoughUpdates/NotEnoughUpdates-REPO/master/items/COBBLESTONE_GENERATOR_1.json): açık alan, blok üretme/kazma, çevrimdışı çalışma, 14 saniyelik örnek eylem aralığı ve sınırlı depo kavramlarını açıklar. HTTP 200 ile okundu.
- [NEU Small Storage kaydı](https://raw.githubusercontent.com/NotEnoughUpdates/NotEnoughUpdates-REPO/master/items/SMALL_ENCHANTED_CHEST.json): minyonun yanına konan sandığa ürün aktarımı ve ayrı depolama alanı tarif edilir. Bu referansta sandık, iç depo dolunca kullanılan üç alanlı ek depodur. HTTP 200 ile okundu.
- [BentoBox Greenhouses](https://raw.githubusercontent.com/BentoBoxWorld/Greenhouses/develop/README.md): ada içindeki sınırlı bölgenin kendi bitki/biyom/yağış davranışını ve bölgesel yönetim fikrini gösterir. HTTP 200 ile okundu. Bu eklenti pakete eklenmez ve kodu alınmaz.

Kasaba'da uygulanan tasarım bunlarla aynı ürün değildir: Taşçı mevcut jeneratörün taş ve cevher çıktısını işler; ürün doğrudan kendi açılabilir sandığında birikir. Ayrı bir “depoyu topla” aşaması kullanılmaz. 4/2,5/1,5 saniyelik Taşçı aralıkları ve 9–54 alanlı sandık Kasaba'nın denge tercihidir; kaynak belgedeki değerler kopyalanmış gibi sunulmaz.

## Kişisel hasat alanı kararı

**15 dakikalık süre kullanıcının isteğidir; araştırmadan bulunan evrensel bir Skyblock kuralı değildir.** Her oyuncuya aynı Skyblock dünyasında kendine özel bir bahçe ve ayrı kayıt verilir. İlk girişte başlayan süre, çıkıp girmekle sıfırlanmaz. Başkasının tarlasına erişim verilmez; olgun buğdayın biçildiği bilgisi ürünle birlikte kalıcı kaydedilir.

Bahçe dönem başına 80 buğday içerir. Normal satış birim fiyatı 4 Altın olduğundan bir tam hasat 320 Altın, dört tam dönem 1.280 Altın eder; gerçek VIP satış bonusu varsa ayrıca uygulanır. Bu bir oyuncu başı gelir sınırıdır. Buğday, kişisel ada tarım görevlerinin yerine sayılmaz. Kullanıcının istediği 15 dakikalık dönem ve oyuncu izolasyonu, sınırsız ortak alanın 20 saniyelik tekrar hasadını değiştirir.

## Erişim sınırları

Hypixel Wiki ve AdvancedPlugins minyon sayfaları bu ortamda 403 erişim hatası verdi; okunmuş veya video izlenmiş sayılmaz. Açık raw GitHub kayıtları okundu ve yerel kopyaları `/workspace/scratch/skyblock130-research` altında saklandı. Paper başlangıç belgesinin denenmiş raw yolu 404 döndü; yazılım gereksinimleri bu notta mevcut POM ve plugin.yml dosyalarından doğrulandı. Üretim oyuncu yükü benchmark'ı yapılmış değildir.
