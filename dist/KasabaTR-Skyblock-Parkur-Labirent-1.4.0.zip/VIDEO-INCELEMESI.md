# 29 Ekim video incelemesi ve uygulanacak kapsam

Kaynak, kullanıcının sağladığı `WhatsApp Video 2026-10-29 at 12.17.21.mp4` dosyasıdır. Yerel dosya 53,272 saniye, 384×848 H.264 görüntü ve AAC ses içerir. Aşağıdaki gözlemler videodan çıkarılan görüntü karelerine dayanır; ses çözümlemesi yapılmadı. Bu not, YouTube'daki başka videoların veya sunucunun bütün sistemlerinin incelendiği anlamına gelmez.

## Karelerde görülenler

Zamanlar videonun başından itibaren geçen süredir; telefondaki saat değildir.

| Zaman | Görüntüde doğrulanan ayrıntı | Kasaba için çıkarım |
| --- | --- | --- |
| 00:04 | Taş blokları yanında küçük bir figür ve “Madenci Minyonu” yazısı bulunuyor. | Üretici figürü, yaptığı işle ve çalıştığı fiziksel alanla ilişkilendirilmeli. Bu görüntü tek başına oduncunun veya çevrimdışı üretimin kurallarını göstermiyor. |
| 00:08–00:12 | “Depolar / Deponu incele” ve “Sıralamalar / Sıralamaları incele” yazılı NPC köşeleri görünüyor. | İşlev isimleri ve etkileşim yönlendirmesi açık olmalı; genel depo veya sıralama sistemi bu yeni dört özelliğin kapsamına kendiliğinden eklenmez. |
| 00:16 | Çok katlı şeker kamışı alanında piston yüzleri ve yetişmiş kamışlar görülüyor. | Otomatik hasat, gerçek yetişmiş bitkiden ürün toplamalı. Videodaki yapı, mekanik fikir için referanstır; aynı yapıyı kopyalama gereği yoktur. |
| 00:20 | Pistonun yanında kamış ve “İşçi pistonla beraber gelmiyo :D” yazısı görülüyor. | Piston ile minyon/işçi ayrı sistemlerdir. Piston satın alındığında görünmez biçimde sınırsız ürün üretilmemeli. |
| 00:24 | Ürün menüsünde “Şeker Kamışı”, “Toplam stok: 5/100000” ve “Sol Tık – Varyantları gör...” yazıları görünüyor. | Depoda ürün türü ve miktarı okunmalı. Videodaki 100.000 kapasite, Kasaba için alınmış bir denge kararı değildir. |
| 00:28 | “Blaze Spawner” üzerinde “Yığın”, “Depo” ve “Tecrübe” sayaçları var. | Spawnerın stok bilgisi dünyada görülebilir olmalı. Yığınlama ve tecrübe sistemi bu güncellemede talep edilmedi. |
| 00:31 | “Blaze Deposu” menüsünde ürün yuvaları ve “Hepsini Sat” düğmesi görülüyor. | Spawner deposundan alma ve satma yolu kısa, açık ve onaylı olmalı. Bu kare, çevrimdışı üretim süresini doğrulamaz. |
| 00:32 | Zindan sahnesi görülüyor. | Kullanıcı kapsamı dört üretim/pazar özelliğiyle sınırladı; zindan eklenmez. |
| 00:36 | “Rafine Makinesi / Hurdaları dönüştür” alanı görülüyor. | Rafine makinesi bu güncellemenin kapsamında değil. |
| 00:40–00:44 | “Oyuncu Pazarı” ve çok sayıda malzeme simgesi içeren “Pazar Kataloğu” açılıyor. | Mevcut oyuncudan oyuncuya ilan sistemi daha anlaşılır bir katalog, filtre ve satın alma akışıyla geliştirilmeli. Ayrı bir ikinci ekonomi kurulmaz. |

## Kullanıcının netleştirdiği dört özellik

1. **Sessiz, depolu spawner:** Dünyaya mob doğurmadan ürün biriktirir. Ada yüklenmeden hesaplanabilir; çevrimdışı süre sınırı başlangıçta **6 saat** olur. Kapasite, üretim süresi ve satış geliri açıkça gösterilir. Dolu depoda geçmiş üretim birikerek boşaltma sonrası anında verilmez. Altı saat sınırı ve üretim değerleri videodan okunmuş kurallar değil, bu paket için belirlenen kurallardır.
2. **Fiziksel oduncu minyonu:** Kendi ayrılmış ağaç alanında ağaç diker ve keser; yetişmiş fiziksel ağaç, depo ve çalışma durumu birbiriyle tutarlı olur. Çevrimdışı hesap aynı ürün kurallarını kullanır; oyuncunun evini veya rastgele çevre bloklarını “ağaç” sayıp kırmaz. Kişisel alan bozulmuşsa güvenli biçimde durur.
3. **Depolu otomatik tarım pistonu:** Ada içindeki gerçek olgun ürünleri toplar ve kendi deposuna yollar. Olgun olmayan ekin, korunan alan veya başka adanın ürünü toplanmaz. Şeker kamışı/kaktüs gibi yeniden büyüyen bitkilerde taban korunur. Depo doluysa ürün kaybı veya yere sınırsız eşya saçılması oluşmaz.
4. **Topluluk pazarı:** Mevcut ilanlar korunarak katalog, anlaşılır eşya/fiyat bilgisi ve işlem onayı eklenir. İlan süresi, kesinti, stok, kendi ilanını geri alma ve yetersiz bakiye/çanta alanı açıkça anlatılır. Aynı ilana iki kişinin tıklaması tek satış doğurmalıdır.

Bu dört sistem özgün Kasaba metinleri, arayüzleri ve denge değerleriyle hazırlanır. Videoda görünen marka, yapı, figür, menü dizilimi, dev depo kapasitesi, yığınlama, tecrübe, zindan veya rafine sistemi otomatik olarak kapsam sayılmaz.

## Donanım etkisi ve doğrulama sınırı

Temel öneri [GEREKSINIM-1.3.0.md](GEREKSINIM-1.3.0.md) dosyasındaki **Java 21 / Paper 1.21.10, 16 GB RAM, güçlü 6 modern vCPU ve 100 GB NVMe** başlangıcıdır. Yeni özellikler için bundan daha kesin bir oyuncu kapasitesi söylenemez; canlı yük testi yapılmış değildir.

Sessiz spawnerlar mob yapay zekâsı yükü eklemez. Çevrimdışı üretim, chunkları sürekli açık tutmak yerine geçen süreden hesaplanmalıdır. Buna karşılık görüntüsü yüklenen oduncu alanları, minyon figürleri, piston taramaları, hologramlar ve pazarın büyük ilan listeleri ana oyun iş parçacığına ek iş getirir. İlk piston uygulaması, bekleyen gerçek hasadı güvenle stoklamak için en fazla 10 saniyelik aralıklarla dünya kayıt kontrolü yapar; hasat varsa disk yazılarının bitmesini bekleyen `World.save(true)` kullanıldığı için geniş yüklü dünyada kayıt süresi ayrıca ölçülmelidir. Üretici sayısı ve tarama aralığı sınırları korunmalı; denemede üretici/ilan sayısı da oyuncu sayısıyla birlikte artırılıp Paper/spark üzerinde TPS, tik süresi, chunk sayısı, dünya kayıt süresi ve SQLite işlem süreleri ölçülmelidir. Bu not kaynak ve kabul kapsamıdır; çalıştırılmış testlerin sonuçları sürümün test raporunda ayrıca yazılır.
