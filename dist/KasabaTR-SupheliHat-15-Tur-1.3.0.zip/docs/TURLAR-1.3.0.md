# 15 mücadele — KasabaTR kuralları

Bu tablo eklentinin **tam kurallarını** anlatır. Kaynak belgedeki belirsiz puan/süre/algoritmalar KasabaTR tasarımıyla tamamlandı; orijinalin doğrulanmış sayıları olarak sunulmaz. Bütün puanlar yalnız maç içindir. Tur kaybı maçtan elemez.

| Kimlik | Mücadele | Seçim ve sonuç |
| --- | --- | --- |
| `kiyafet` | Farklı Kıyafet | Bir mavi, diğerleri beyaz. Herkes başka oyuncunun kıyafetini bilir ve mankenle görür. Telefonla farklı kişiyi bulur; kendini de seçebilir. Doğru +3, diğerleri 0. |
| `ikilem` | Kırmızı mı Yeşil mi? | Gizli seçim: yeşil/yeşil +3/+3; kırmızı/yeşil +5/0; kırmızı/kırmızı +1/+1. Cevap vermeyen kırmızı. Eşsiz veya eşi ayrılmış oyuncu +2. |
| `bomba` | Bomba | Taşıyan alıcıyla telefon görüşmesi kurup görev menüsünden teklif eder. Yalnız alıcı 10 saniye içinde devralabilir. Teklif tek başına devretmez; iptal/timeout/eski düğme geçersizdir. Devir sonrası 3 saniye. Patlama anı gizli. Son taşıyan −4, diğerleri +2. Kablo/kod yoktur. |
| `kelime` | Kelimeyi Bul | Harf konumları oyunculara paylaştırılır; hepsi birlikte elde edilebilir. Ayrılanın bilgisi kalanlara dağıtılır. Türkçe harf büyüklüğü önemsiz. Doğru +3; 3 yanlış ve 5 saniye tekrar beklemesi. |
| `kapilar` | Kapılar | Gizli çık/kal. Çıkan sayısı tekse çıkan +3, çiftse −2. Kalan +1; cevap yok 0. Gerçek odalar arası geçiş açılmaz. |
| `oylama` | Oylama | Kendine oy yok. Tek en çok oy alan −3; en çokta eşit kalanlar −1. Diğer oy kullanan +1; kullanmayan −1. Sonuçta yalnız toplamlar açıklanır. Ayrılan hedefe verilen oy yeniden seçilebilir. |
| `dikenler` | Dikenler | Kendi güvenli sembolünü başka oyuncu bilir. Telefonla öğrenip altı sembolden seç. Görsel tuzak iner. Doğru +3; yanlış/cevapsız −2; gerçek ölüm yok. |
| `rulet` | Rus Ruleti | Sırayla bir atış; kendini veya başkasını hedefleyebilirsin. Her atışta yeniden 1/6 dolu. Boş: kendine +2, başkasına +1. Dolu: hedef −3; başkasını vurana +1. 8 saniye seçmeyen atış yapmadan pas, −1. |
| `casino` | Kumarhane | En çok 3 çevirme, arada 1 saniye. −3/−2/−1/+1/+2/+4; oranlar %5/%15/%25/%30/%20/%5. İstediğinde durabilir. Tur sonunda puana eklenir; en kötü −9. Akçe kullanılmaz. |
| `ortalama` | Ortalama Sayı | 0–100 gizli tam sayı. Geçerli cevapların aritmetik ortalamasına en yakın tek kişi +4, eşit en yakınlar +2; diğerleri 0, yazmayan −1. Katsayı uygulanmaz. |
| `patates` | Sıcak Patates | Doğrudan gönderilir, telefon/onay gerekmez. Devir arası 2 saniye; önceki taşıyana iade 3 saniye. Gizli patlama anında taşıyan −3, diğerleri +1. Bomba'dan ayrı mekanik. |
| `siseler` | Zehirli Şişeler | Her oyuncunun üç şişesinden biri zehirli. O bilgiyi başka oyuncu bilir. Telefonla öğrenip güvenliyi seç. Güvenli +3; zehirli/cevapsız −2. Konserve turuyla birleştirilmez. |
| `cizim` | Çizim Tahtası | Rastgele çizer gizli kelimeyi 7×5 tahta, beş renk ve silgiyle gerçekten çizer. Çizim herkesin odasında canlı görünür. Çizer tahmin yapamaz, diğerleri çizemez. Doğru +3; çizer bilene +1, en çok +4. 3 yanlış, 5 saniye bekleme. Çizer ayrılırsa yeni çizer seçilir; çizim korunur. |
| `kule` | Kule | 1–6 gizli yükseklik odanda kurulur. **En yüksek benzersiz** kule +4; diğer benzersizler +1, tekrarlananlar −1; cevap yok 0. Benzersiz yoksa kazanan yok. Daha yüksekler tekrarlanırsa 1 blok kazanabilir. |
| `para` | Para Turu | O tur için 100 sanal kredi; gizli 0–100 yatırım. Pozitif yatırımcı sayısı en az oyuncuların üçte ikisiyse (yukarı yuvarlanır), yatırım iki kat geri döner ve 100+yatırım kalır; değilse batar, 100−yatırım kalır. Tek en zengin +4, eşit liderler +2, cüzdan 0 ise −3; diğerleri 0. Akçe etkilenmez. |

## Ortak akış

- Varsayılan altı farklı tur etkin havuzdan rastgele seçilir. VIP yalnız kendi bekleme odasının havuzunu ve tur sayısını değiştirir.
- Açıklama 10 sn, görev genellikle 55 sn (çizim/rulet 75), sonuç 8 sn. Herkes bitirirse en erken 10. saniyede sonuç. Bomba/patates gizli bir anda patlar.
- Tek seçimli turlarda karar değişmez. Eski turun düğmesi/çizim ekranı yenisini değiştiremez. Tahmin/Casino ayrı hak ve bekleme süreleri kullanır.
- Farklı telefon çiftleri aynı anda konuşabilir; maçlar arası ses geçmez. Tur bitince görüşmeler kapanır ve dört arama hakkı yenilenir.
- Ayrılanın tehlikeli eşyası kaybolmaz, kalanlara geçer; gerekli ipuçları yeniden paylaşılır. Tek kalan kazanır, kimse kalmazsa oda kapanır.
- Toplam puanda eşit liderler birlikte kazanır. Denemeler liderliğe yazılmaz; normal galibiyetler mevcut ilk-5 tablosuna gider.
- Finalden 5 sn sonra oyun lobisi, `/lobi` ile asıl envanter. Geçici dünya, görev görselleri ve ses grupları temizlenir.
