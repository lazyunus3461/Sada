# Araştırma ve uyarlama sınırı — 27 Ekim 2026

Kullanıcının gönderdiği **Scam-Line-Orijinal-Turlar-Ayrintili.md** (21.844 bayt) tasarım kaynağıdır. Belge özellikle doğrulanmamış kuralları ayırır. Eski dört sabit tur bu kapsama uymuyordu; 15 başlık ayrı mücadele olarak yeniden işlendi.

Aşağıdaki sayfalar, resmî API ve RSS yolları doğrudan denendi. Çalışma ortamının ağ vekili hepsinde **403 Forbidden** verdi. Bu nedenle içerikleri bağımsız olarak yeniden doğrulanamadı; bağlantı listesi başarıyla okunmuş kaynak listesi değildir.

- https://store.steampowered.com/app/2794590/Scam_Line/
- https://steamcommunity.com/app/2794590/allnews/
- https://api.steampowered.com/ISteamNews/GetNewsForApp/v2/?appid=2794590&count=100&maxlength=0&format=json
- https://store.steampowered.com/api/appdetails?appids=2794590&l=english
- https://steamcommunity.com/games/2794590/rss/
- https://truesteamachievements.com/game/scam-line/achievements
- https://gameoverview.ru/games/scam-line
- https://videoblogs.com/videojuegos/auron-han-actualizado-el-juego-de-traicionarnos-scam-line-5

Belge temel amaçları anlatırken tam puan/süre tablolarını, Kule'nin kazanma algoritmasını ve Para'nın işleyişini belirsiz bırakır. [Kurallar tablosundaki](TURLAR-1.3.0.md) sayılar eklentinin kesin kurallarıdır; orijinalin doğrulandığı iddia edilmez.

- **Kule:** “En yüksek benzersiz” KasabaTR tercihidir; 1 blokla kazanmayı sağlar. Orijinal algoritma diye sunulmaz.
- **Para:** 100 sanal kredili, üçte iki katılım eşikli fon KasabaTR tasarımıdır. Orijinal ticaret/bahis/transfer arayüzü olarak sunulmaz ve Akçe'ye bağlanmaz.
- **Oylama:** Anonim toplam ve puan cezası KasabaTR tercihidir; orijinalin her sürümde aynı eleme/cezayı kullandığı söylenmez.
- **İkilem:** Belgedeki 3/3–5/0–1/1 örneği kullanıldı, değişmez resmî tablo olarak ilan edilmedi.
- **Bomba:** Kod/kablo eklenmedi; telefon teklifini kabul ederek devir, Sıcak Patates'in doğrudan devrinden ayrıldı.
- **Kelime/Çizim** ayrı tutuldu. **Zehirli Şişeler** ayrı konserve başlığıyla birleştirilmedi.

Sonuç **15 mücadeleli KasabaTR uyarlamasıdır**; orijinalin birebir veya tüm 22 turunun eksiksiz kopyası değildir. PC oyununun dosya, ses, model veya görselleri kullanılmadı. Mevcut KasabaTR odaları ve Minecraft malzemeleri kullanılır.
