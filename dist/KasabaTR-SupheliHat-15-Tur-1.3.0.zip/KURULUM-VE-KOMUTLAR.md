# KasabaTR Şüpheli Hat 1.3.0

Paper **1.21.10**, Java **21**, KasabaAuth **1.4.0**, KasabaHub **1.9.2** ve sunucu/oyuncularda uyumlu **Simple Voice Chat 2.6.x**.

Gönderilen 15 Scam Line mücadelesini temel alan **KasabaTR uyarlaması**. Kesinleştirilemeyen kurallar açık şekilde tamamlandı; orijinalin birebir kopyası veya tüm 22 turu değildir. [15 turun tam kuralları](docs/TURLAR-1.3.0.md) · [Araştırma sınırı](docs/KAYNAKLAR-1.3.0.md).

Eski dört sabit tur kaldırıldı. Normal **4–8 kişi**, varsayılan **6 farklı rastgele tur**, **3 eşzamanlı maç**. Her tur açıklama → görev → sonuç; maç sonunda **5 saniye** sonra oyun lobisine dönüş. Çizim gerçek 7×5 tahtadır; telefonlarda farklı çiftler eşzamanlı konuşabilir.

## Kurulum

1. Sunucuyu tamamen durdur; `/reload` kullanma.
2. Eski **KasabaHub-…jar** ve **KasabaSupheliHat-…jar** dosyalarını kaldır. Paketteki **KasabaHub-1.9.2.jar** ve **KasabaSupheliHat-1.3.0.jar** dosyalarını `plugins` içine koy. Her eklentinin yalnız bir JAR sürümü kalsın.
3. **Config, dünya ve oyuncu/veri klasörlerini silme.** Mevcut motel/lobi korunur. Yeni config anahtarları eksikse eklenir; kayıtlı dünya adı değiştirilmez. Geçici görev görselleri şablon bloklarına yazılmaz.
4. Simple Voice Chat sunucu JAR'ı ve oyuncu modu kurulu olmalı; bunlar ZIP'e gömülü değildir. Ses **UDP 26338**, oyun portu **28757**. Oyuncu kurulum sayfası `/ses`.
5. Sunucuyu aç; `/hat` veya `/oyunlar` → **Şüpheli Hat**. `/oyunlar ekle` ve `/mv import` gerekmez.

## İki kişiyle test

İkiniz `/hat`, sonra ikiniz `/hat oyna` yazın. OP oyuncu `/hat deneme` yazsın. Yalnız bir mücadele için `/hat deneme cizim`, `/hat deneme bomba` veya `/hat deneme kule` kullanılabilir. Bunlar ayrı maç örnekleridir; mevcut maçtayken yeni deneme açılmaz. Yeni test için ikiniz `/hat lobi` ile dönüp tekrar `/hat oyna` seçin. İkinizin de ses bağlantısı hazır olmalı. Deneme galibiyeti liderliğe yazılmaz.

## Komutlar

| Komut | İşlev |
| --- | --- |
| `/hat` | Lobi/menü; kendiliğinden sıraya sokmaz. |
| `/hat oyna` | Ortak oda. Dört kişi olunca 60 saniye geri sayar. |
| `/hat turlar` | 15 mücadele ve kuralları; maçta mevcut tur. |
| `/hat cevap` | Görev seçimi veya cevap yazma alanı. |
| `/hat telefon`, `/hat ara Oyuncu` | Telefonu aç/oyuncuyu ara. |
| `/hat kabul`, `/hat reddet`, `/hat kapat` | Arama ve görüşme kontrolü. |
| `/hat kelime KALE` | Kelime/çizim cevabı. |
| `/hat sayı 40` | Ortalama cevabı. |
| `/hat yatır 75` | Para turunda yalnız sanal kredi yatırımı. |
| `/hat çiz` | Çizerin boyama tahtası. |
| `/hat durum` | Oda/sıra bilgisi. |
| `/hat lobi` | Oyun lobisi. |
| `/lobi` | Ana spawn ve oyun öncesi envanter. |

Pusula, telefon ve görev kâğıdına sağ tıklamak veya envanterde tıklamak menü açar. Eski `/hat şifre` turu kaldırıldı.

VIP: `/hat oda kur`. Arkadaşlar `/oda` listesinden veya `/hat oda katıl <oda>` ile katılır. Sahibi `/hat havuz` ile yalnız bu odanın turlarını ve tur sayısını seçer; en az bir tur kalır. Dört kişi hazırken `/hat başlat` veya `/oda başlat`. Ortak odayı VIP erken başlatamaz; OP'nin iki kişilik denemesi ayrı araçtır.

Normal aktif maç çıkışı bu oyuna 15 dakika giriş cezasıdır. VIP/OP, deneme, normal bitiş ve 5 saniye süren ses kaybı nedeniyle zorunlu dönüş cezasızdır. Oyuncu çıkışı ve yeniden başlatmada önceki envanterin kurtarma kaydı korunur.

## Ayarlar

`plugins/KasabaSupheliHat/config.yml`: `rounds-per-match: 6` (1–15), `round-pool` (15 tur kimliği), `intro-seconds: 10`, `result-seconds: 8`, `round-times.<kimlik>` (genelde 55, çizim/rulet 75 sn), `words`, `max-concurrent-rooms: 3`. Havuz tekrarsız seçilir. Herkes bitirirse tur en erken 10. saniyede bitebilir; bomba/patates daha önce patlayabilir. Eski `round-seconds` dosyada kalır; yeni süreler `round-times` altındadır.

## Test sınırı

Gerçek Paper sunucusunda protokol istemcileri ve resmî ses API'sine uygun **yalnız test** adaptörü kullanılır. Bu gerçek mikrofon/UDP sesini veya grafik istemcisini doğrulamaz. Test/fake ses JAR'ları dağıtılmaz; canlı kurulumda iki gerçek bilgisayarla ses kontrolü gerekir.
