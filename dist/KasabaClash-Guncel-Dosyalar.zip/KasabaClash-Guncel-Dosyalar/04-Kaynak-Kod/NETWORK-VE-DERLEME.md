# İstemci derlemesi için ortam

Kullanıcı istemci modunu onayladı. Hedef Minecraft Java 1.21.10 / Java 21 ve mevcut KasabaTR Paper sunucusu. Mod kurulumu yalnız bu oyunun özel GUI/kamera/animasyonlarını kullanacak oyuncular için gerekecek; ağdaki diğer oyunlara bir mod zorunluluğu eklenmesi istenmedi.

Resmi Fabric örnek projesinin `1.21.10` dalı okunabildi:

`https://raw.githubusercontent.com/FabricMC/fabric-example-mod/1.21.10/gradle.properties`

Bu dalda Fabric API `0.138.4+1.21.10` belirtiliyor. Dalın Loom/Loader değerleri güncellenebilir; istemci derlemesinde indirilen gerçek sürüm ve checksum ayrıca sabitlenmeli. Resmi Minecraft/Fabric Maven metaverisi okunmadan derlemenin doğru veya çalışır olduğu iddia edilmez.

Ortamın mevcut ağı resmi adreslere HTTP 403 verdi. Taslağa, mevcut alan adları korunarak aşağıdaki adresler eklendi:

- `meta.fabricmc.net`
- `maven.fabricmc.net`
- `piston-meta.mojang.com`
- `resources.download.minecraft.net`
- `supercell.com`
- `www.supercell.com`
- `assets.clashk.ing`

Taslak kaydetmek çalışan ortamın erişimini değiştirmez. Ortam ayarlarından kaydedip yayımlamak gerekiyor. Bundan sonra başarısız indirme yeniden denenmeli; ağ hâlâ kapalıysa sahte veya yalnız stub API ile derlenen mod kullanıma hazır diye teslim edilmemeli.

Java/Maven komutları ortamın mevcut doğrulanmış CA deposunu kullanır: `/workspace/kasaba-cacerts`. TLS veya artifact checksum doğrulaması kapatılmaz. Yalnız sunucu çekirdeği için çalıştırılabilir komut:

```sh
bash /workspace/Sada/kasaba-clash/tools/cloud-build-core.sh
```

Bu komut veriyi ithal edip 11 Java testini çalıştırır ve çekirdek + Paper adaptörünü derler. `server/target/KasabaClash-Server-0.1.0-DEVELOPMENT.jar` gerçek Paper eklentisidir; fakat oyun henüz tamamlanmadığı için geliştirme bağlantısı varsayılan kapalıdır. Minecraft istemcisi, GUI ve tam oyunun uygulanmış olduğu anlamına gelmez. Henüz çalıştırılabilir tam sunucu/istemci paketi yoktur.

2026-11-06 kontrolünde yukarıdaki alan adları kayıtlı taslakta bulunmasına rağmen `meta.fabricmc.net`, `maven.fabricmc.net`, `piston-meta.mojang.com` istekleri çalışan ortamda yine `Tunnel connection failed: 403 Forbidden` döndürdü. TLS veya proxy doğrulaması kapatılmadı; başka adres üzerinden erişim kısıtlaması aşılmadı. Ortamın güncel ağ ayarlarının uygulanması ve gerçek SDK indiriminin başarılı olması gerekiyor. Ağın açılması tek başına tam oyunu tamamlamaz: istemci ekranları, savaşlar, modeller, bütün oyun kuralları ve tam Başkent verileri ayrıca uygulanıp test edilmeli.
