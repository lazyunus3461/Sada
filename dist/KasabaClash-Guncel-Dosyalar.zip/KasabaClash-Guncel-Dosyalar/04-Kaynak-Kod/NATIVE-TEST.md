# Paper bağlantı doğrulaması

Bu, tamamlanmış oyunun veya Minecraft ekranlarının testi değildir. Gerçek Paper 1.21.10, Java 21, KasabaAuth 1.4.2 ve sentetik Minecraft protokol istemcileriyle inşaat adaptörü test edildi. Geliştirme JAR’ı üretim oyun paketi olarak sunulmaz.

`bash tools/cloud-build-core.sh` proje kökünde çekirdek + Paper modülünü derler, 11 Java testi çalıştırır. Ortamın mevcut Java/CA/Maven ayarları kullanılır. Sunucu bağımlılığı gerçek önbellekli Paper API’sidir; istemci SDK’sı veya stub API kullanılmaz.

`python tools/prepare_native_test.py` yalnız `/workspace/scratch/clash-native-20261106` adında yeni bir yerel fixture oluşturur. Dizin varsa durur; mevcut kayıtları veya dünyayı silmez. Önceden kabul edilmiş yerel test EULA dosyası ve Paper runtime dosyalarını kopyalar. KasabaAuth hesapları başka sunucudan taşınmaz. Yalnız CLJ1 sentetik hesabı OP olur. Geliştirme bağlantısı bu ayrı fixture içinde açılır.

Sunucuyu bu ayrı dizinde `/workspace/jdk-21.0.9+10/bin/java -Xms256m -Xmx1g -jar paper.jar --nogui` ile başlat. `Done` ve iki eklentinin etkinleşmesini bekle. Sunucu 127.0.0.1:25616 ile sınırlıdır. Proje kökünde `node tools/native_transport_test.cjs` çalıştır. Bu ilk geçiş yalnız temiz Clash fixture verisiyle çalışır; fixture DB’sini otomatik sıfırlamaz.

Konsoldan `stop` ile düzgün kapat, aynı dizinde yeniden başlat ve `node tools/native_transport_test.cjs restart` çalıştır. Ardından yalnız bu test sunucusunu `stop` ile kapat. İkinci oyuncu ayrı bir loopback kaynak adresi kullanır; üretimdeki hesap/IP politikasına dokunulmaz.

Doğrulananlar: gerçek Kasaba kayıt/giriş formu, OP için de giriş zorunluluğu, yanlış katalog ve eski oturum reddi, eksik Başkent işleminin açık reddi, başkasının hesap/bedel alanını gönderme girişiminin reddi, çakışan binanın geri alınması, gerçek bedel ve kalıcı iş kaydı, idempotent tekrar, eski köy sürümünün reddi, envanter/teleport paketi üretmeden köy konumu taşıma, normal oyuncunun geliştirme bağlantısına girememesi, tam Paper kapanış/açılışında bakiye ve inşaatın korunması.

Sonuçlar `validation/native-initial.json` (12 kontrol), `validation/native-restart.json` (8 kontrol) ve `validation/native-summary.json` içindedir. İlk kurulum denemesinde iki sentetik hesabın aynı IP üzerinden kaydı mevcut KasabaAuth hesap sınırına takıldı; başarısız rapor saklandı, fixture istemcilerinin adresleri ayrıldı ve test temiz Clash verisiyle yeniden çalıştırıldı. Hiçbir başarısız test başarılı diye işaretlenmedi.

İstek eşleştirmesi eklendikten sonra güncel adaptör aynı, durdurulmuş fixture sunucusuna kopyalanıp yeniden başlatıldı. `node tools/native_transport_test.cjs client-common` ile 10 kontrol daha geçti: hello/state yanıt tokenları, başarılı/başarısız mutasyonların tam nonce karşılığı, tekrar ve eski revision hataları. Bu mod mevcut fixture verisini korur; temiz başlangıç bakiyesi varsaymaz. `validation/native-client-common.json` ve `validation/native-current-adapter.json` bu yeni artifact için kanıttır. Eski 12+8 kontroller yeni JAR’a aitmiş gibi işaretlenmez.

Testte yerel offline Paper’ın dış Mojang public-key isteği ağ nedeniyle başarısız olabilir; bu, burada gözlemlenen ortam sınırlamasıdır. Clash eklentisi etkinleşmesi ve native protokol kontrolleri ayrıca doğrulandı. Genel “sunucu logunda hiç hata yok”, görsel Minecraft GUI veya tam oyun uyumluluğu iddiası yapılmaz.
