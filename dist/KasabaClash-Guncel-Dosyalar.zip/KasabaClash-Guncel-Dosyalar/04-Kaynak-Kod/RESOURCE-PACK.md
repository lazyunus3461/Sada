# Minecraft kaynak varlıkları

`python tools/build_resource_pack.py`, SHA-256 ile doğrulanan önizleme varlıklarını Minecraft’ın PNG biçimine dönüştürür ve `dist/KasabaClash-Resources-0.1.0-DEVELOPMENT.zip` üretir. Pillow 12.3.0 ile çalıştırıldı. Çevrimdışı kaynaklar mevcutsa ağ indirmesi yapmaz. RGBA pikselleri dönüşüm öncesi ve sonrası karşılaştırılır. ZIP dosyalarının tarihleri ve sıralaması sabitlenmiştir; aynı girdilerle aynı paket üretilir.

Paket, **2B GUI/kart varlıklarıdır; tam oyun veya 3B model paketi değildir**. Tek başına ekran açmaz. Varsayılan Minecraft kaynaklarını değiştirmez, oyuncuya otomatik gönderilmez. 287 görsel, düz item modeli tanımları, Lilita One başlık fontu, 43 ekranlık manifest ve doğrulanmış içerik kataloğu içerir. Üst kaynak deposunun tamamını veya bütün resmi oyun görsellerini içerdiği iddia edilmez. Henüz hazırlanmayan 3B bina/animasyon/karakterler bu dosyaların varlığıyla tamamlanmış sayılmaz.

Minecraft 1.21.10’un gerçek, önbellekli runtime dosyasındaki `SharedConstants` değerleri kaynak biçiminin **69.0** olduğunu doğruladı. `python tools/verify_pack_native.py`, `pack.mcmeta` dosyasını aynı sürümün gerçek `PackMetadataSection.CLIENT_TYPE` codec’iyle çözdü; destek aralığı `[69.0,69.0]` olarak kabul edildi. Bootstrap gerektiren gerçek kayıt sistemi de başlatıldı; API stub’ı kullanılmadı.

`python tools/verify_pack_contents.py` ZIP içindeki bütün hashleri, 287 PNG/item/model bağlantısını, font yolunu ve ekran manifestini kontrol eder. Sonuçlar `validation/resource-pack-contents.json` ve `research/resource-pack-status.json` içindedir. Metadata codec’i ve dosya bağlantılarının geçmesi, gerçek Minecraft istemcisinde font/doku yükleme veya özel GUI görsel testi değildir. `nativeClientLoadingTested` ve `nativeGuiImplemented` hâlâ `false`.

Kaynak: ClashKingInc / ClashKingAssets, sabit commit `fdac291ae7fbc2901221ff945834be534d0344ae`; görsel izleri paketteki `asset-index.json` içinde. Kaynak depo GPL lisansı ve Lilita One SIL Open Font lisansı ZIP’e eklenir. Bağımsız çalışma Supercell tarafından desteklenmiş veya onaylanmış değildir.
