package tr.kasaba.clash.server;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import tr.kasaba.auth.api.AuthState;
import tr.kasaba.clash.core.*;

/** An actual Paper adapter, kept unavailable as a game until a real client/full gameplay exists. */
public final class ClashPlugin extends JavaPlugin implements Listener, PluginMessageListener {
  public static final String CHANNEL = "kasaba:clash";
  private final Gson gson = new Gson();
  private final Map<UUID, UUID> sessions = new HashMap<>();
  private final Map<UUID, long[]> rates = new HashMap<>();
  private VillageStore store;
  private Catalog catalog;
  private GameService game;
  private AuthState auth;

  @Override public void onEnable() {
    saveDefaultConfig();
    try {
      auth = Objects.requireNonNull(Bukkit.getServicesManager().load(AuthState.class), "KasabaAuth servisi gerekli.");
      catalog = Catalog.bundled();
      Class.forName("org.sqlite.JDBC");
      store = new VillageStore(getDataFolder().toPath().resolve("clash.db"));
      Map<String, Long> initial = new LinkedHashMap<>();
      for (String key : List.of("Gold", "Elixir", "Dark Elixir", "Gems"))
        initial.put(key, getConfig().getLong("starting-resources." + key, 0));
      game = new GameService(store, catalog, initial);
      Bukkit.getMessenger().registerIncomingPluginChannel(this, CHANNEL, this);
      Bukkit.getMessenger().registerOutgoingPluginChannel(this, CHANNEL);
      Bukkit.getPluginManager().registerEvents(this, this);
      Objects.requireNonNull(getCommand("clash")).setExecutor(this::command);
      getLogger().info("İnşaat çekirdeği ve Paper bağlantısı yüklendi. Tam oyun, istemci GUI ve savaşlar henüz tamamlanmadı.");
    } catch (Exception failure) {
      getLogger().log(Level.SEVERE, "Clash başlatılamadı; veri korunuyor.", failure);
      Bukkit.getPluginManager().disablePlugin(this);
    }
  }

  @Override public void onDisable() {
    sessions.clear(); rates.clear();
    Bukkit.getMessenger().unregisterIncomingPluginChannel(this);
    Bukkit.getMessenger().unregisterOutgoingPluginChannel(this);
    if (store != null) try { store.close(); }
    catch (Exception failure) { getLogger().log(Level.SEVERE, "Clash kaydı kapatılamadı.", failure); }
  }

  private boolean command(CommandSender sender, Command cmd, String alias, String[] args) {
    if (sender instanceof Player p && !auth.authenticated(p.getUniqueId())) {
      p.sendMessage("§cÖnce Kasaba hesabına giriş yap."); return true;
    }
    sender.sendMessage("§6KasabaClash §7· Sunucu geliştirme sürümü");
    sender.sendMessage("§eKalıcı köy / bina işlemleri: hazır. §7Tam Minecraft GUI ve savaşlar: tamamlanmadı.");
    sender.sendMessage("§7Bu JAR tek başına 43 ekranlı oyunu çalıştırmaz.");
    return true;
  }

  @EventHandler public void quit(PlayerQuitEvent event) {
    sessions.remove(event.getPlayer().getUniqueId()); rates.remove(event.getPlayer().getUniqueId());
  }

  @Override public void onPluginMessageReceived(String channel, Player player, byte[] bytes) {
    if (!channel.equals(CHANNEL) || game == null || !player.isOnline()) return;
    // Bukkit calls this on the primary server thread; all database mutations stay serialized.
    if (!Bukkit.isPrimaryThread()) return;
    if (!limit(player.getUniqueId(), System.nanoTime())) return;
    JsonObject request = null;
    try {
      if (!auth.authenticated(player.getUniqueId()))
        throw new IllegalArgumentException("Önce Kasaba hesabına giriş yap.");
      if (!getConfig().getBoolean("development-connection-enabled")
          || !player.hasPermission("kasabaclash.gelistirme"))
        throw new IllegalArgumentException("Tam oyun henüz yayımlanmadı; geliştirme bağlantısı kapalı.");
      var parsed = JsonParser.parseString(Wire.command(bytes));
      if (!parsed.isJsonObject()) throw new IllegalArgumentException("İstek nesne olmalı.");
      request = parsed.getAsJsonObject();
      if (GameService.integer(request, "v") != Wire.VERSION)
        throw new IllegalArgumentException("İstemci protokolü uyuşmuyor.");
      String type = GameService.text(request, "type");
      JsonObject result = new JsonObject();
      result.addProperty("ok", true); result.addProperty("type", type);
      result.addProperty("v", Wire.VERSION); result.addProperty("catalog", catalog.snapshot());
      correlate(result, request);
      result.addProperty("completeGame", false);
      if (type.equals("hello")) {
        requireFields(request, Set.of("v", "type", "catalog", "token"));
        if (!GameService.text(request, "catalog").equals(catalog.snapshot()))
          throw new IllegalArgumentException("İstemci içerik kataloğu sunucuyla uyuşmuyor.");
        UUID session = UUID.randomUUID(); sessions.put(player.getUniqueId(), session);
        result.addProperty("session", session.toString());
        JsonArray features = new JsonArray();
        for (String value : List.of("state", "place", "upgrade", "move")) features.add(value);
        result.add("features", features);
      } else {
        UUID session = sessions.get(player.getUniqueId());
        if (session == null || !session.toString().equals(GameService.text(request, "session")))
          throw new IllegalArgumentException("İstemci oturumu yok veya süresi geçmiş.");
        Region region = Region.valueOf(GameService.text(request, "region"));
        long now = System.currentTimeMillis();
        if (type.equals("state")) {
          requireFields(request, Set.of("v", "type", "session", "region", "token"));
        } else {
          var receipt = game.execute(player.getUniqueId(), request, now);
          result.addProperty("replay", receipt.replay());
          result.addProperty("token", GameService.text(request, "token"));
          result.addProperty("revision", receipt.revision());
          result.addProperty("result", receipt.result());
        }
        result.add("state", gson.toJsonTree(game.state(player.getUniqueId(), region, now)));
      }
      send(player, result);
    } catch (IllegalArgumentException | IllegalStateException | JsonParseException badRequest) {
      JsonObject error = new JsonObject(); error.addProperty("ok", false);
      error.addProperty("v", Wire.VERSION); error.addProperty("error", badRequest.getMessage());
      correlate(error, request);
      send(player, error);
    } catch (Exception failure) {
      getLogger().log(Level.SEVERE, "Clash işlemi geri alındı: " + player.getUniqueId(), failure);
      JsonObject error = new JsonObject(); error.addProperty("ok", false);
      error.addProperty("v", Wire.VERSION); correlate(error, request);
      error.addProperty("error", "İşlem kaydedilemedi; köy verisi korundu."); send(player, error);
    }
  }

  private void send(Player player, JsonObject result) {
    for (byte[] frame : Wire.split(UUID.randomUUID(), gson.toJson(result).getBytes(StandardCharsets.UTF_8)))
      player.sendPluginMessage(this, CHANNEL, frame);
  }

  private boolean limit(UUID player, long now) {
    long[] value = rates.computeIfAbsent(player, ignored -> new long[] {now, 0});
    if (now - value[0] >= 1_000_000_000L) { value[0] = now; value[1] = 0; }
    return ++value[1] <= 10;
  }

  private static void requireFields(JsonObject request, Set<String> allowed) {
    if (!allowed.containsAll(request.keySet()))
      throw new IllegalArgumentException("Desteklenmeyen istemci alanı.");
  }

  private static void correlate(JsonObject response, JsonObject request) {
    if (request == null) return;
    for (String key : List.of("type", "token")) {
      var value = request.get(key);
      if (value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()
          && value.getAsString().matches("[a-zA-Z0-9_-]{1,80}"))
        response.addProperty(key, value.getAsString());
    }
  }
}
