# İstemci ortak kodu

Bu modül **Fabric modu değildir**. İçinde Minecraft `Screen`, Fabric giriş noktası, gerçek render/kamera bağlaması veya mod yükleyici metadata’sı yoktur. Üretilen kütüphane JAR’ı `mods` klasörüne atılarak oyun açılmaz. Resmi Minecraft/Fabric SDK erişimi hâlâ 403 ile engellidir.

Hazırlanan, bağımsız Java kodu olarak derlenip test edilen parçalar:

- `ClientSession`: yerel Minecraft hesabının UUID’siyle yanıt sahipliği kontrolü, katalog/protokol/oturum eşleşmesi, parça bütünlüğü, sunucu durumunun kopyalanması ve eski yanıtların ayrılması. Bekleyen istekler aynı nonce ile tekrar gönderilir. Bakiye ve bina konumu yalnız sunucunun doğrulanmış yanıtından sonra değişir.
- `GuiCatalog`: 43 ekranın başlık ve kapsam manifesti; 287 kaynak varlığının PNG texture/item-model kimlikleri. Eksik bina seviyesi görseli için ilk seviye görseli kullanılırsa `levelFallback` açıkça işaretlenir. `SERVER_STATE`, sunucu verisinin bulunabildiğini söyler; Minecraft ekranının uygulanmış olduğunu söylemez. Diğer ekranlar salt katalog veya tasarım durumundadır.
- `GuiModel`: gerçek köy kaydından kaynak/inşaat kartları, kaynak kataloglu geliştirme maliyeti ve süresi, salt okunur birlik/kahraman/kozmetik listeleri. HTML önizlemesinin örnek oyuncusu, bakiyeleri ve savaş sonuçları buraya aktarılmaz.
- `GuiController`: sunucu durumunu değiştirmeyen yerel sürükleme önizlemesi, çakışma gösterimi, onaydan sonra gerçek taşıma isteği, bina seçimi ve geliştirme isteği.
- `IsometricCamera` ve `Viewport`: aynı çizim/tıklama dönüşümü, imleç çevresinde zoom, negatif karo ve pencere kenar boşluğu hesapları.

Sekiz test, gerçek çekirdek `GameService` ve SQLite ile kayıp yanıt/tekrar istek, geciken yanıt, hesap/bölge karışması, salt okunur durum kopyaları, kamera ve sürükleme akışlarını kontrol eder. Bunlar Minecraft görsel istemci testleri değildir.

Mod bağlamasında gerçek oyuncu UUID’si kullanılmalı; `connect()`/`read()`/eylem çıktıları `kasaba:clash` kanalına gönderilmeli, gelen çerçeveler `accept()` ile birleştirilmeli ve ayrılma/sunucu değişiminde `disconnect()` çağrılmalıdır. UI tasarım örnekleri canlı oyun verisine dönüştürülmüş gibi gösterilmemelidir.
