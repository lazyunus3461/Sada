package tr.kasaba.clash.client;

import java.util.*;
import tr.kasaba.clash.core.*;

/** Real command-producing interactions; a Fabric Screen still needs to bind input/rendering. */
public final class GuiController {
  public record Drag(String building,int x,int z,boolean valid) {}
  private final ClientSession session;
  private final GuiModel model;
  private final IsometricCamera camera;
  private Region region=Region.HOME;
  private String route="home",selected;
  private Drag drag;
  public GuiController(ClientSession session,GuiModel model,IsometricCamera camera){this.session=session;this.model=model;this.camera=camera;}
  public void navigate(String id){model.screen(id);route=id;drag=null;}
  public String route(){return route;}
  public Region region(){return region;}
  public Optional<String> selected(){return Optional.ofNullable(selected);}
  public Optional<Drag> drag(){return Optional.ofNullable(drag);}
  public byte[] switchVillage(Region region){byte[] request=session.read(region);this.region=region;selected=null;drag=null;route=region==Region.HOME?"home":"builder";return request;}
  public Optional<String> select(double screenX,double screenY){
    var tile=camera.tile(screenX,screenY);
    var village=session.state(region);
    selected=village.stream().flatMap(v->v.buildings.stream())
        .filter(b->tile.x()>=b.x()&&tile.z()>=b.z()&&tile.x()<b.x()+b.width()&&tile.z()<b.z()+b.width())
        .max(Comparator.comparingInt(b->b.x()+b.z())).map(Village.Building::id).orElse(null);
    return Optional.ofNullable(selected);
  }
  public void beginDrag(){
    if(selected==null||session.waiting())throw new IllegalStateException("Taşınacak bina seçilmedi veya işlem bekleniyor.");
    var b=session.state(region).orElseThrow().building(selected);drag=new Drag(b.id(),b.x(),b.z(),true);
  }
  public Drag dragTo(double screenX,double screenY){
    if(drag==null)throw new IllegalStateException("Taşıma başlamadı.");
    var tile=camera.tile(screenX,screenY);var v=session.state(region).orElseThrow();var b=v.building(drag.building);
    drag=new Drag(b.id(),tile.x(),tile.z(),v.free(tile.x(),tile.z(),b.width(),b.id()));return drag;
  }
  public byte[] confirmDrag(){
    if(drag==null||!drag.valid)throw new IllegalStateException("Bu konuma bina sığmıyor.");
    byte[] request=session.move(region,drag.building,drag.x,drag.z);drag=null;return request;
  }
  public void cancelDrag(){drag=null;}
  public byte[] upgrade(){
    if(selected==null)throw new IllegalStateException("Bina seçilmedi.");
    var quote=model.upgrade(region,selected);
    if(!quote.requestEnabled())throw new IllegalStateException(quote.unavailableReason());
    return session.upgrade(region,selected);
  }
}
