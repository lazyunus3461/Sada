package tr.kasaba.clash.client;

/** Logical viewport math; the final renderer must use these same transforms for hit testing. */
public final class IsometricCamera {
  public record Point(double x, double y) {}
  public record Tile(int x, int z) {}
  private double originX, originY, zoom=1;
  private final double halfWidth, halfHeight;
  public IsometricCamera(double originX,double originY,double halfWidth,double halfHeight) {
    finite(originX,originY,halfWidth,halfHeight);
    if(halfWidth<=0||halfHeight<=0)throw new IllegalArgumentException("Geçersiz karo boyutu.");
    this.originX=originX;this.originY=originY;this.halfWidth=halfWidth;this.halfHeight=halfHeight;
  }
  public Point project(double x,double z) {
    finite(x,z);return new Point(originX+(x-z)*halfWidth*zoom,originY+(x+z)*halfHeight*zoom);
  }
  public Point unproject(double screenX,double screenY) {
    finite(screenX,screenY);
    double u=(screenX-originX)/(halfWidth*zoom),v=(screenY-originY)/(halfHeight*zoom);
    return new Point((u+v)/2,(v-u)/2);
  }
  public Tile tile(double screenX,double screenY) {
    Point p=unproject(screenX,screenY);return new Tile((int)Math.floor(p.x),(int)Math.floor(p.y));
  }
  public void pan(double dx,double dy) {
    finite(dx,dy);originX+=Math.clamp(dx,-10000,10000);originY+=Math.clamp(dy,-10000,10000);
    originX=Math.clamp(originX,-100000,100000);originY=Math.clamp(originY,-100000,100000);
  }
  public void zoomAt(double screenX,double screenY,double multiplier) {
    finite(screenX,screenY,multiplier);
    if(multiplier<=0)throw new IllegalArgumentException("Yakınlaştırma çarpanı pozitif olmalı.");
    Point point=unproject(screenX,screenY);zoom=Math.clamp(zoom*multiplier,.4,2.5);
    originX=screenX-(point.x-point.y)*halfWidth*zoom;
    originY=screenY-(point.x+point.y)*halfHeight*zoom;
  }
  public double zoom(){return zoom;}
  private static void finite(double...values){for(double x:values)if(!Double.isFinite(x))throw new IllegalArgumentException("Geçersiz kamera sayısı.");}
}
