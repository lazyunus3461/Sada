package tr.kasaba.clash.client;

import java.util.Optional;

/** One transform for both drawing and mouse events, including letterbox margins. */
public record Viewport(double scale,double offsetX,double offsetY,int logicalWidth,int logicalHeight) {
  public static Viewport fit(int width,int height,int logicalWidth,int logicalHeight){
    if(width<1||height<1||logicalWidth<1||logicalHeight<1)throw new IllegalArgumentException("Geçersiz görünüm boyutu.");
    double scale=Math.min((double)width/logicalWidth,(double)height/logicalHeight);
    return new Viewport(scale,(width-logicalWidth*scale)/2,(height-logicalHeight*scale)/2,logicalWidth,logicalHeight);
  }
  public Optional<IsometricCamera.Point> logical(double x,double y){
    if(!Double.isFinite(x)||!Double.isFinite(y))return Optional.empty();
    double lx=(x-offsetX)/scale,ly=(y-offsetY)/scale;
    if(lx<0||ly<0||lx>=logicalWidth||ly>=logicalHeight)return Optional.empty();
    return Optional.of(new IsometricCamera.Point(lx,ly));
  }
}
