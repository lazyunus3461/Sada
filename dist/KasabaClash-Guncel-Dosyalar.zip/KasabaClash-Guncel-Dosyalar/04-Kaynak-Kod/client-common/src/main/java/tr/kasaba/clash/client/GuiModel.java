package tr.kasaba.clash.client;

import java.util.*;
import tr.kasaba.clash.core.*;

/** UI projections use authoritative state, not the old HTML preview's sample balances. */
public final class GuiModel {
  public record BuildingCard(String id,String title,int level,int x,int z,int width,Optional<GuiCatalog.Sprite> sprite,boolean constructing) {}
  public record Resource(String id,long amount) {}
  public record VillageView(boolean loaded,Region region,long revision,List<Resource> resources,List<BuildingCard> buildings,int builders,int jobs) {}
  public record ContentCard(String key,String title,String subtitle,Optional<GuiCatalog.Sprite> sprite,boolean readOnly) {}
  public record UpgradeView(String building,String title,int current,int target,String currency,long cost,long seconds,boolean requestEnabled,String unavailableReason) {}
  private final Catalog catalog;
  private final GuiCatalog gui;
  private final ClientSession session;
  private final Locale turkish=Locale.forLanguageTag("tr-TR");
  public GuiModel(Catalog catalog,GuiCatalog gui,ClientSession session){this.catalog=catalog;this.gui=gui;this.session=session;}
  public VillageView village(Region region){
    var state=session.state(region);
    if(state.isEmpty())return new VillageView(false,region,-1,List.of(),List.of(),0,0);
    var v=state.get();
    List<Resource> resources=v.resources.entrySet().stream().map(x->new Resource(x.getKey(),x.getValue())).toList();
    List<BuildingCard> buildings=v.buildings.stream().map(b->{
      var item=catalog.item(b.catalogKey());return new BuildingCard(b.id(),item.displayName(),b.level(),b.x(),b.z(),b.width(),gui.sprite(item,Math.max(1,b.level())),v.jobs.stream().anyMatch(j->j.building().equals(b.id())));
    }).sorted(Comparator.comparingInt(b->b.x()+b.z())).toList();
    return new VillageView(true,region,v.revision,resources,buildings,v.builders,v.jobs.size());
  }
  public List<ContentCard> catalog(String family,String filter,int page){
    if(page<0||page>1000)throw new IllegalArgumentException("Geçersiz sayfa.");
    String search=Objects.requireNonNull(filter).toLowerCase(turkish);
    return catalog.family(family).stream().filter(x->(x.displayName()+" "+x.name()).toLowerCase(turkish).contains(search))
        .skip((long)page*24).limit(24).map(x->new ContentCard(x.key(),x.displayName(),x.name(),gui.sprite(x,1),true)).toList();
  }
  public UpgradeView upgrade(Region region,String id){
    var v=session.state(region).orElseThrow(()->new IllegalStateException("Önce sunucudan köyü yükle."));
    var b=v.building(id);var item=catalog.item(b.catalogKey());
    try{
      var quote=new Construction(catalog).quote(v,id);
      String denied=session.waiting()?"Sunucu yanıtı bekleniyor.":!session.supports("upgrade")?"Sunucu geliştirmeyi desteklemiyor.":v.hall<quote.requiredHall()?"Merkez seviyesi yetersiz.":v.jobs.size()>=v.builders?"Boş inşaatçı yok.":v.resources.getOrDefault(quote.currency(),0L)<quote.cost()?"Kaynak yetersiz.":"";
      return new UpgradeView(id,item.displayName(),quote.current(),quote.target(),quote.currency(),quote.cost(),quote.seconds(),denied.isEmpty(),denied);
    }catch(IllegalArgumentException unavailable){return new UpgradeView(id,item.displayName(),b.level(),b.level(),"",0,0,false,unavailable.getMessage());}
  }
  public GuiCatalog.Screen screen(String id){return gui.screen(id);}
}
