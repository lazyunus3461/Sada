package tr.kasaba.clash.client;

import com.google.gson.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;
import tr.kasaba.clash.core.*;

/** Shared client state/commands, not the still-missing Fabric rendering/SDK binding. */
public final class ClientSession {
  public enum Phase { DISCONNECTED, CONNECTING, READY }
  public enum Event { PART, HELLO, STATE, REJECTED, STALE }
  private final UUID localAccount;
  private final Catalog catalog;
  private final Gson gson = new Gson();
  private final Wire.Assembler assembler = new Wire.Assembler();
  private final Map<Region, Village> states = new EnumMap<>(Region.class);
  private Set<String> capabilities = Set.of();
  private Phase phase = Phase.DISCONNECTED;
  private String session, lastError = "";
  private JsonObject pending;

  public ClientSession(UUID localAccount, Catalog catalog) {
    this.localAccount = Objects.requireNonNull(localAccount);
    this.catalog = Objects.requireNonNull(catalog);
  }

  public synchronized byte[] connect() {
    disconnect(); phase = Phase.CONNECTING;
    var request = new JsonObject(); request.addProperty("v", Wire.VERSION);
    request.addProperty("type", "hello"); request.addProperty("catalog", catalog.snapshot());
    request.addProperty("token", UUID.randomUUID().toString());
    pending = request; return bytes(request);
  }

  public synchronized byte[] read(Region region) {
    requireReady(); requireRegion(region); requireIdle(); requireCapability("state");
    return enqueue(base("state", region));
  }

  public synchronized byte[] place(Region region, String catalogKey, int x, int z) {
    var request = mutation("place", region);
    var item = catalog.item(catalogKey);
    if (!item.family().equals("buildings") || !item.village().equals(region.sourceName()))
      throw new IllegalArgumentException("Bina bu köye ait değil.");
    request.addProperty("key", item.key()); coordinates(request, x, z);
    return enqueue(request);
  }

  public synchronized byte[] upgrade(Region region, String building) {
    var request = mutation("upgrade", region);
    state(region).orElseThrow().building(building);
    request.addProperty("building", building); return enqueue(request);
  }

  public synchronized byte[] move(Region region, String building, int x, int z) {
    var request = mutation("move", region);
    state(region).orElseThrow().building(building);
    request.addProperty("building", building); coordinates(request, x, z);
    return enqueue(request);
  }

  /** Retransmit the original operation/nonce; never generate another purchase after a timeout. */
  public synchronized byte[] retry() {
    if (pending == null) throw new IllegalStateException("Tekrarlanacak bekleyen istek yok.");
    return bytes(pending);
  }

  public synchronized Event accept(byte[] packet, long localMillis) {
    if (phase == Phase.DISCONNECTED) return Event.STALE;
    try {
      var result = assembler.accept(packet, localMillis);
      if (result.isEmpty()) return Event.PART;
      String json = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
          .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(result.get())).toString();
      var parsed = JsonParser.parseString(json);
      if (!parsed.isJsonObject()) throw new IllegalArgumentException("Sunucu yanıtı nesne olmalı.");
      var response = parsed.getAsJsonObject();
      if (GameService.integer(response, "v") != Wire.VERSION)
        throw new IllegalArgumentException("Sunucu protokolü uyuşmuyor.");
      if (pending == null) return Event.STALE;
      if (response.has("ok") && response.get("ok").isJsonPrimitive()
          && response.getAsJsonPrimitive("ok").isBoolean() && !response.get("ok").getAsBoolean()
          && !response.has("type") && !response.has("token")) {
        String error = safeError(response); disconnect(); lastError = error; return Event.REJECTED;
      }
      String expectedType = GameService.text(pending, "type");
      if (response.has("type") && !expectedType.equals(GameService.text(response, "type")))
        return Event.STALE;
      if (pending.has("token") && (!response.has("token")
          || !GameService.text(pending,"token").equals(GameService.text(response,"token"))))
        return Event.STALE;
      if (!response.has("ok") || !response.get("ok").isJsonPrimitive()
          || !response.getAsJsonPrimitive("ok").isBoolean())
        throw new IllegalArgumentException("Sunucu sonuç alanı geçersiz.");
      if (!response.get("ok").getAsBoolean()) {
        lastError = safeError(response);
        pending = null;
        if (phase == Phase.CONNECTING) phase = Phase.DISCONNECTED;
        return Event.REJECTED;
      }
      if (!catalog.snapshot().equals(GameService.text(response, "catalog")))
        throw new IllegalArgumentException("Sunucu içerik kataloğu değişti.");
      if (expectedType.equals("hello")) {
        session = UUID.fromString(GameService.text(response, "session")).toString();
        var features = response.getAsJsonArray("features");
        if (features == null || features.size() > 32)
          throw new IllegalArgumentException("Sunucu özellik listesi geçersiz.");
        Set<String> offered = new HashSet<>();
        for (var value : features) {
          if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("Sunucu özellik kaydı geçersiz.");
          String name = value.getAsString();
          if (Set.of("state","place","upgrade","move").contains(name)) offered.add(name);
        }
        capabilities = Set.copyOf(offered); phase = Phase.READY; pending = null;
        return Event.HELLO;
      }
      var rawState = response.getAsJsonObject("state");
      if (rawState == null || !rawState.has("buildings")
          || rawState.getAsJsonArray("buildings").size() > 2500
          || !rawState.has("jobs") || rawState.getAsJsonArray("jobs").size() > 10
          || !rawState.has("resources") || rawState.getAsJsonObject("resources").size() > 32)
        throw new IllegalArgumentException("Köy yanıtının boyutu geçersiz.");
      var village = gson.fromJson(rawState, Village.class);
      if (!localAccount.toString().equals(village.owner))
        throw new IllegalArgumentException("Yanıt bu Minecraft hesabına ait değil.");
      Region requested = Region.valueOf(GameService.text(pending, "region"));
      if (village.region != requested)
        throw new IllegalArgumentException("Yanıt istenen köye ait değil.");
      village.validate();
      for (var building : village.buildings) {
        var item = catalog.item(building.catalogKey());
        if (!item.family().equals("buildings") || !item.village().equals(village.region.sourceName())
            || building.width() != item.width() || building.level() > item.maximum())
          throw new IllegalArgumentException("Sunucu binası katalogla uyuşmuyor.");
      }
      var previous = states.get(village.region);
      pending = null;
      if (previous != null && village.revision < previous.revision) return Event.STALE;
      states.put(village.region, village); lastError = ""; return Event.STATE;
    } catch (Exception invalid) {
      disconnect(); lastError = "Sunucu durumu doğrulanamadı: " + invalid.getMessage();
      throw new IllegalArgumentException(lastError, invalid);
    }
  }

  public synchronized Optional<Village> state(Region region) {
    var value = states.get(region);
    return value == null ? Optional.empty() : Optional.of(gson.fromJson(gson.toJson(value), Village.class));
  }

  public synchronized void disconnect() {
    phase = Phase.DISCONNECTED; session = null; pending = null; states.clear();
    capabilities = Set.of(); assembler.clear(); lastError = "";
  }
  public synchronized Phase phase() { return phase; }
  public synchronized boolean waiting() { return pending != null; }
  public synchronized String lastError() { return lastError; }
  public synchronized boolean supports(String type) { return capabilities.contains(type); }

  private JsonObject mutation(String type, Region region) {
    requireReady(); requireRegion(region); requireIdle(); requireCapability(type);
    var value = states.get(region);
    if (value == null) throw new IllegalStateException("Önce sunucudan köy durumunu yükle.");
    var request = base(type, region); request.addProperty("revision", value.revision);
    return request;
  }
  private JsonObject base(String type, Region region) {
    var request = new JsonObject(); request.addProperty("v", Wire.VERSION);
    request.addProperty("type", type); request.addProperty("session", session);
    request.addProperty("token", UUID.randomUUID().toString());
    request.addProperty("region", region.name()); return request;
  }
  private byte[] enqueue(JsonObject request) { pending = request.deepCopy(); return bytes(request); }
  private static byte[] bytes(JsonObject request) {
    byte[] data = request.toString().getBytes(StandardCharsets.UTF_8);
    if (data.length > Wire.MAX_COMMAND) throw new IllegalArgumentException("İstek çok uzun.");
    return data;
  }
  private static void coordinates(JsonObject request, int x, int z) {
    if (x < 0 || z < 0 || x > 99 || z > 99) throw new IllegalArgumentException("Konum sınır dışında.");
    request.addProperty("x", x); request.addProperty("z", z);
  }
  private void requireReady() {
    if (phase != Phase.READY) throw new IllegalStateException("Minecraft sunucusu bağlantısı hazır değil.");
  }
  private void requireIdle() {
    if (pending != null) throw new IllegalStateException("Önce bekleyen sunucu işlemini tamamla.");
  }
  private void requireCapability(String type) {
    if (!capabilities.contains(type)) throw new IllegalStateException("Sunucu bu işlemi desteklemiyor.");
  }
  private void requireRegion(Region region) {
    if (!catalog.supports(region)) throw new IllegalArgumentException("Bu bölgenin oyun verisi tamamlanmadı.");
  }
  private static String safeError(JsonObject response) {
    var value = response.get("error");
    String message = value != null && value.isJsonPrimitive() ? value.getAsString() : "Sunucu işlemi reddetti.";
    return message.substring(0, Math.min(message.length(), 512));
  }
}
