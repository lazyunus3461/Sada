package tr.kasaba.clash.client;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import tr.kasaba.clash.core.*;

/** Screen and asset registry for a future real renderer. No declaration of working native GUIs. */
public final class GuiCatalog {
  public enum Mode { SERVER_STATE, CATALOG_READ_ONLY, DESIGN_ONLY }
  public record Screen(String id,String title,String group,Mode mode) {}
  public record Sprite(String source,String texture,String itemModel,int width,int height,boolean levelFallback) {}
  private final Map<String,Screen> screens=new LinkedHashMap<>();
  private final Map<String,Sprite> sprites=new HashMap<>();

  public GuiCatalog() throws IOException {
    var data=read("/gui/screens.json");
    if(data.get("schema").getAsInt()!=1||data.get("nativeMinecraftGuiImplemented").getAsBoolean())
      throw new IOException("GUI manifesti mevcut uygulama kapsamını yanlış bildiriyor.");
    for(var raw:data.getAsJsonArray("screens")){
      var x=raw.getAsJsonObject();String id=x.get("id").getAsString();
      if(!id.matches("[a-z0-9-]{1,40}"))throw new IOException("Geçersiz ekran kodu.");
      var screen=new Screen(id,x.get("title").getAsString(),x.get("group").getAsString(),Mode.valueOf(x.get("mode").getAsString().toUpperCase(Locale.ROOT)));
      if(screens.put(id,screen)!=null)throw new IOException("Yinelenen ekran.");
    }
    if(screens.size()!=43)throw new IOException("Ekran manifesti eksik.");
    var assets=read("/gui/asset-index.json");
    for(var raw:assets.getAsJsonArray("assets")){
      var x=raw.getAsJsonObject();String source=x.get("source").getAsString(),texture=x.get("texture").getAsString(),model=x.get("itemModel").getAsString();
      if(!texture.matches("kasabaclash:textures/gui/[a-z0-9_./-]+\\.png")||texture.contains("..")
          ||!model.matches("kasabaclash:[a-z0-9_./-]+")||model.contains(".."))throw new IOException("Geçersiz varlık kimliği.");
      int width=x.get("width").getAsInt(),height=x.get("height").getAsInt();
      if(width<1||height<1||width>8192||height>8192)throw new IOException("Görsel boyutu geçersiz.");
      var sprite=new Sprite(source,texture,model,width,height,false);
      if(sprites.put(source,sprite)!=null)throw new IOException("Yinelenen varlık.");
    }
  }
  public Collection<Screen> screens(){return List.copyOf(screens.values());}
  public Screen screen(String id){var value=screens.get(id);if(value==null)throw new IllegalArgumentException("Ekran bulunamadı.");return value;}
  public int assetCount(){return sprites.size();}
  public Optional<Sprite> sprite(Catalog.Item item,int level){
    String slug=slug(item.name()),path;
    switch(item.family()){
      case "buildings" -> path="buildings/"+(item.village().equals("builderBase")?"builder-base":"home-village")+"/"+slug+"/level_"+level+".webp";
      case "spells","equipment" -> path=item.family()+"/"+slug+".webp";
      case "sceneries" -> path="sceneries/"+slug+"/thumbnail.webp";
      default -> path=item.family()+"/"+slug+"/icon.webp";
    }
    var sprite=sprites.get(path);
    if(sprite!=null)return Optional.of(sprite);
    if(item.family().equals("buildings")&&level!=1){
      var first=sprites.get("buildings/"+(item.village().equals("builderBase")?"builder-base":"home-village")+"/"+slug+"/level_1.webp");
      if(first!=null)return Optional.of(new Sprite(first.source,first.texture,first.itemModel,first.width,first.height,true));
    }
    return Optional.empty();
  }
  public Optional<Sprite> resource(String name){return Optional.ofNullable(sprites.get("resources/"+name+".webp"));}
  private static String slug(String name){return name.toLowerCase(Locale.ROOT).replace(' ','_').replace(".","").replace("?","").replace("’","").replace("\\q","");}
  private static JsonObject read(String path)throws IOException{
    try(var stream=GuiCatalog.class.getResourceAsStream(path)){
      if(stream==null)throw new IOException("GUI manifesti eksik: "+path);
      try(var reader=new InputStreamReader(stream,StandardCharsets.UTF_8)){return JsonParser.parseReader(reader).getAsJsonObject();}
    }
  }
}
