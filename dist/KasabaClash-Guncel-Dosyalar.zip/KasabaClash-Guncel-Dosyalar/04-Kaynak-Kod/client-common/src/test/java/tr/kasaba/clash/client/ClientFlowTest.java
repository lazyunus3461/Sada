package tr.kasaba.clash.client;

import static org.junit.jupiter.api.Assertions.*;
import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import tr.kasaba.clash.core.*;

class ClientFlowTest {
  @TempDir Path temporary;
  private final UUID owner=UUID.fromString("b0000000-0000-4000-8000-000000000001");
  private Catalog catalog;
  private GuiCatalog gui;
  private ClientSession client;
  private final Gson gson=new Gson();
  @BeforeEach void init()throws Exception{catalog=Catalog.bundled();gui=new GuiCatalog();client=new ClientSession(owner,catalog);}
  private JsonObject parse(byte[] data){return JsonParser.parseString(new String(data,StandardCharsets.UTF_8)).getAsJsonObject();}
  private JsonObject reply(JsonObject request){
    var response=new JsonObject();response.addProperty("v",Wire.VERSION);response.addProperty("ok",true);
    response.addProperty("catalog",catalog.snapshot());response.add("type",request.get("type"));
    if(request.has("token"))response.add("token",request.get("token"));return response;
  }
  private ClientSession.Event accept(JsonObject response){
    var frames=Wire.split(UUID.randomUUID(),gson.toJson(response).getBytes(StandardCharsets.UTF_8));
    ClientSession.Event event=ClientSession.Event.PART;
    for(byte[] frame:frames)event=client.accept(frame,1000);return event;
  }
  private void connect(){
    var request=parse(client.connect());var response=reply(request);
    response.addProperty("session",UUID.randomUUID().toString());var features=new JsonArray();
    for(String x:List.of("state","place","move","upgrade"))features.add(x);response.add("features",features);
    assertEquals(ClientSession.Event.HELLO,accept(response));
  }
  private GameService game(VillageStore db){return new GameService(db,catalog,Map.of("Gold",100000L,"Elixir",100000L));}
  private JsonObject snapshot(JsonObject request,Village village){var response=reply(request);response.add("state",gson.toJsonTree(village));return response;}
  private void load(GameService game)throws Exception{var request=parse(client.read(Region.HOME));assertEquals(ClientSession.Event.STATE,accept(snapshot(request,game.state(owner,Region.HOME,1000))));}

  @Test void handshakeRejectsDifferentCatalogAndCannotCreateAnOfflineVillage(){
    assertThrows(IllegalStateException.class,()->client.upgrade(Region.HOME,"hall"));
    var model=new GuiModel(catalog,gui,client);assertFalse(model.village(Region.HOME).loaded());
    assertTrue(model.village(Region.HOME).resources().isEmpty());
    var request=parse(client.connect());var response=reply(request);response.addProperty("catalog","0".repeat(64));
    assertThrows(IllegalArgumentException.class,()->accept(response));
    assertEquals(ClientSession.Phase.DISCONNECTED,client.phase());
    assertTrue(client.state(Region.HOME).isEmpty());
  }

  @Test void uncorrelatedAuthenticationErrorClosesConnectionInsteadOfLeavingAStuckPurchase(){
    client.connect();var response=new JsonObject();response.addProperty("v",Wire.VERSION);
    response.addProperty("ok",false);response.addProperty("error","Önce giriş yap.");
    assertEquals(ClientSession.Event.REJECTED,accept(response));
    assertEquals(ClientSession.Phase.DISCONNECTED,client.phase());assertFalse(client.waiting());
    assertEquals("Önce giriş yap.",client.lastError());
  }

  @Test void lostAcknowledgementRetriesSameNonceAndChangesUiOnlyAfterRealServerResult()throws Exception{
    try(var db=new VillageStore(temporary.resolve("roundtrip.db"))){
      var game=game(db);connect();load(game);
      var requestBytes=client.place(Region.HOME,catalog.building(Region.HOME,"Cannon").key(),2,2);
      var request=parse(requestBytes);var first=game.execute(owner,request,1000);
      assertFalse(first.replay());assertEquals(100000L,client.state(Region.HOME).orElseThrow().resources.get("Gold"));
      assertArrayEquals(requestBytes,client.retry());assertThrows(IllegalStateException.class,()->client.upgrade(Region.HOME,"hall"));
      assertTrue(game.execute(owner,parse(client.retry()),1001).replay());
      var state=game.state(owner,Region.HOME,1001);assertEquals(ClientSession.Event.STATE,accept(snapshot(request,state)));
      assertEquals(state.resources.get("Gold"),client.state(Region.HOME).orElseThrow().resources.get("Gold"));
      assertEquals(state.buildings.size(),new GuiModel(catalog,gui,client).village(Region.HOME).buildings().size());
      var copy=client.state(Region.HOME).orElseThrow();copy.resources.put("Gold",Long.MAX_VALUE);
      assertNotEquals(Long.MAX_VALUE,client.state(Region.HOME).orElseThrow().resources.get("Gold"));
    }
  }

  @Test void delayedReadResponseCannotConsumeNewRequestOrRestoreOldResources()throws Exception{
    try(var db=new VillageStore(temporary.resolve("order.db"))){
      var game=game(db);connect();var oldRequest=parse(client.read(Region.HOME));
      var oldResponse=snapshot(oldRequest,game.state(owner,Region.HOME,1000));accept(oldResponse);
      var place=parse(client.place(Region.HOME,catalog.building(Region.HOME,"Cannon").key(),2,2));
      game.execute(owner,place,1000);accept(snapshot(place,game.state(owner,Region.HOME,1000)));
      var fresh=parse(client.read(Region.HOME));long balance=client.state(Region.HOME).orElseThrow().resources.get("Gold");
      assertEquals(ClientSession.Event.STALE,accept(oldResponse));assertTrue(client.waiting());
      assertEquals(balance,client.state(Region.HOME).orElseThrow().resources.get("Gold"));
      assertEquals(ClientSession.Event.STATE,accept(snapshot(fresh,game.state(owner,Region.HOME,1001))));assertFalse(client.waiting());
    }
  }

  @Test void foreignAccountOrRegionResponsesCannotEnterTheClientState()throws Exception{
    try(var db=new VillageStore(temporary.resolve("identity.db"))){
      var game=game(db);connect();var request=parse(client.read(Region.HOME));
      var foreign=game.state(UUID.randomUUID(),Region.HOME,1000);
      var foreignResponse=snapshot(request,foreign);
      assertThrows(IllegalArgumentException.class,()->accept(foreignResponse));
      assertEquals(ClientSession.Phase.DISCONNECTED,client.phase());assertTrue(client.state(Region.HOME).isEmpty());
      connect();request=parse(client.read(Region.HOME));
      var other=game.state(owner,Region.BUILDER,1000);var response=snapshot(request,other);
      assertThrows(IllegalArgumentException.class,()->accept(response));
    }
  }

  @Test void resourceRegistryPreservesSpecificLevelArtAndLabelsAnyFirstLevelFallback(){
    assertEquals(43,gui.screens().size());assertEquals(287,gui.assetCount());
    assertEquals(GuiCatalog.Mode.DESIGN_ONLY,gui.screen("battle").mode());
    assertEquals(GuiCatalog.Mode.CATALOG_READ_ONLY,gui.screen("skins").mode());
    var hall=gui.sprite(catalog.building(Region.HOME,"Town Hall"),18).orElseThrow();
    assertTrue(hall.source().endsWith("/level_18.webp"));assertFalse(hall.levelFallback());
    var cannon=gui.sprite(catalog.building(Region.HOME,"Cannon"),7).orElseThrow();
    assertTrue(cannon.levelFallback());assertTrue(cannon.source().endsWith("/level_1.webp"));
    var cards=new GuiModel(catalog,gui,client).catalog("heroes","kraliçe",0);
    assertTrue(cards.stream().anyMatch(x->x.title().equals("Okçu Kraliçe")));assertTrue(cards.stream().allMatch(GuiModel.ContentCard::readOnly));
    assertThrows(IllegalArgumentException.class,()->gui.screen("not-a-screen"));
  }

  @Test void cameraInverseZoomAnchorAndLetterboxHitTestingStayConsistent(){
    var camera=new IsometricCamera(640,80,20,12);
    for(var p:List.of(new IsometricCamera.Point(0,0),new IsometricCamera.Point(17.25,9.75),new IsometricCamera.Point(-.1,3))){
      var image=camera.project(p.x(),p.y());var inverse=camera.unproject(image.x(),image.y());
      assertEquals(p.x(),inverse.x(),1e-9);assertEquals(p.y(),inverse.y(),1e-9);
    }
    var anchor=camera.unproject(352,401);camera.zoomAt(352,401,1.8);
    assertEquals(anchor.x(),camera.unproject(352,401).x(),1e-9);assertEquals(anchor.y(),camera.unproject(352,401).y(),1e-9);
    var image=camera.project(-.1,3);assertEquals(-1,camera.tile(image.x(),image.y()).x());
    assertThrows(IllegalArgumentException.class,()->camera.pan(Double.NaN,0));
    var view=Viewport.fit(1000,1000,1280,720);
    assertTrue(view.logical(500,0).isEmpty());assertEquals(640,view.logical(500,500).orElseThrow().x());
    assertTrue(view.logical(1000,500).isEmpty());assertTrue(view.logical(Double.NaN,500).isEmpty());
  }

  @Test void draggingIsOnlyALocalPreviewUntilServerAcknowledgesTheMove()throws Exception{
    try(var db=new VillageStore(temporary.resolve("drag.db"))){
      var game=game(db);connect();load(game);var camera=new IsometricCamera(640,80,20,12);
      var controller=new GuiController(client,new GuiModel(catalog,gui,client),camera);
      var center=camera.project(21,21);assertEquals("hall",controller.select(center.x(),center.y()).orElseThrow());
      controller.beginDrag();var bad=camera.project(15.5,20.5);assertFalse(controller.dragTo(bad.x(),bad.y()).valid());
      assertThrows(IllegalStateException.class,controller::confirmDrag);assertFalse(client.waiting());
      var good=camera.project(25.5,25.5);assertTrue(controller.dragTo(good.x(),good.y()).valid());
      var request=parse(controller.confirmDrag());assertEquals(25,request.get("x").getAsInt());
      assertEquals(20,client.state(Region.HOME).orElseThrow().building("hall").x());
      game.execute(owner,request,1000);accept(snapshot(request,game.state(owner,Region.HOME,1000)));
      assertEquals(25,client.state(Region.HOME).orElseThrow().building("hall").x());
    }
  }
}
