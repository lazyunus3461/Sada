Bu gerçek KasabaAuth 1.4.0 JAR'ı, Maven kaynak derlemesinin provided bağımlılığıdır.
Oyuncu hesabı veya ayar verisi içermez. Hazır sunucudaki KasabaAuth kurulumunu değiştirmez.
Maven için aşağıdaki komutla yerel depoya eklenebilir; bu dosya istemci modu değildir.
