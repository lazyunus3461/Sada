package tr.kasaba.clash.core;

import static org.junit.jupiter.api.Assertions.*;
import com.google.gson.*;
import java.nio.file.Path;
import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

class GameServiceTest {
  @TempDir Path temporary;
  private final UUID first = UUID.fromString("a0000000-0000-4000-8000-000000000001");
  private final UUID second = UUID.fromString("a0000000-0000-4000-8000-000000000002");
  private Catalog catalog;
  @BeforeEach void init() throws Exception { catalog = Catalog.bundled(); }
  private GameService service(VillageStore db) {
    return new GameService(db, catalog, Map.of("Gold", 100000L, "Elixir", 100000L, "Gems", 0L));
  }
  private JsonObject request(String type, long revision) {
    var x = new JsonObject(); x.addProperty("v", Wire.VERSION); x.addProperty("type", type);
    x.addProperty("session", "session"); x.addProperty("region", "HOME");
    x.addProperty("token", UUID.randomUUID().toString()); x.addProperty("revision", revision);
    return x;
  }
  private JsonObject place(long revision, int x, int z) {
    var r = request("place", revision);
    r.addProperty("key", catalog.building(Region.HOME, "Cannon").key());
    r.addProperty("x", x); r.addProperty("z", z); return r;
  }

  @Test void genuinePlacementChargesOnceAndFinishesAfterOfflineRestart() throws Exception {
    Path path = temporary.resolve("game.db");
    String building; long finishes, paid;
    JsonObject request = place(0, 2, 2);
    try (var db = new VillageStore(path)) {
      var game = service(db); var before = game.state(first, Region.HOME, 1000);
      assertEquals(2, before.buildings.size());
      var receipt = game.execute(first, request, 1000); building = receipt.result();
      var current = db.load(first.toString(), Region.HOME);
      long cost = catalog.building(Region.HOME, "Cannon").level(1).get("build_cost").getAsLong();
      paid = 100000 - cost;
      assertEquals(paid, current.resources.get("Gold"));
      assertEquals(0, current.building(building).level());
      finishes = current.jobs.getFirst().finishes();
      assertTrue(finishes > 1000);
      assertTrue(game.execute(first, request.deepCopy(), 1001).replay());
      assertEquals(paid, db.load(first.toString(), Region.HOME).resources.get("Gold"));
    }
    try (var db = new VillageStore(path)) {
      var game = service(db); var current = game.state(first, Region.HOME, finishes);
      assertEquals(1, current.building(building).level());
      assertTrue(current.jobs.isEmpty());
      assertEquals(paid, current.resources.get("Gold"));
      assertEquals(current.revision, game.state(first, Region.HOME, finishes+1).revision);
      assertTrue(game.execute(first, request, finishes+2).replay());
    }
  }

  @Test void failedPlacementDoesNotReserveLandOrSpendAndLimitsRemainEnforced() throws Exception {
    try (var db = new VillageStore(temporary.resolve("limits.db"))) {
      var game = service(db); game.state(first, Region.HOME, 1000);
      assertThrows(IllegalArgumentException.class, () -> game.execute(first, place(0, 20, 20), 1000));
      var clean = db.load(first.toString(), Region.HOME);
      assertEquals(0, clean.revision); assertEquals(2, clean.buildings.size());
      assertEquals(100000L, clean.resources.get("Gold"));
      game.execute(first, place(0, 2, 2), 1000);
      long end = db.load(first.toString(), Region.HOME).jobs.getFirst().finishes();
      var ready = game.state(first, Region.HOME, end);
      long balance = ready.resources.get("Gold"), revision = ready.revision;
      assertThrows(IllegalArgumentException.class,
          () -> game.execute(first, place(revision, 8, 8), end));
      assertEquals(balance, db.load(first.toString(), Region.HOME).resources.get("Gold"));
      assertEquals(revision, db.load(first.toString(), Region.HOME).revision);
    }
  }

  @Test void actorIdentityAndIndependentVillagesCannotBeOverriddenByClientFields() throws Exception {
    try (var db = new VillageStore(temporary.resolve("owners.db"))) {
      var game = service(db);
      game.state(first, Region.HOME, 1000); game.state(second, Region.HOME, 1000);
      var builder = game.state(first, Region.BUILDER, 1000);
      assertEquals("Builder Hall", catalog.item(builder.building("hall").catalogKey()).name());
      var forged = place(0, 2, 2); forged.addProperty("owner", second.toString());
      assertThrows(IllegalArgumentException.class, () -> game.execute(first, forged, 1000));
      forged.remove("owner"); forged.addProperty("cost", 0);
      assertThrows(IllegalArgumentException.class, () -> game.execute(first, forged, 1000));
      assertEquals(0, db.load(first.toString(), Region.HOME).revision);
      assertEquals(0, db.load(second.toString(), Region.HOME).revision);
      assertEquals(0, db.load(first.toString(), Region.BUILDER).revision);
      assertThrows(IllegalArgumentException.class, () -> game.state(first, Region.CAPITAL, 1000));
      assertTrue(db.find(first.toString(), Region.CAPITAL).isEmpty());
    }
  }

  @Test void fractionalCoordinatesAndUnimplementedBattleRequestsCannotMutateState() throws Exception {
    try (var db = new VillageStore(temporary.resolve("requests.db"))) {
      var game = service(db); game.state(first, Region.HOME, 1000);
      var fractional = place(0, 2, 2); fractional.addProperty("x", 2.5);
      assertThrows(IllegalArgumentException.class, () -> game.execute(first, fractional, 1000));
      var huge = place(0, 2, 2); huge.addProperty("x", Long.MAX_VALUE);
      assertThrows(IllegalArgumentException.class, () -> game.execute(first, huge, 1000));
      assertThrows(IllegalArgumentException.class, () -> game.execute(first, request("win", 0), 1000));
      assertEquals(0, db.load(first.toString(), Region.HOME).revision);
      assertEquals(100000L, db.load(first.toString(), Region.HOME).resources.get("Gold"));
    }
  }

  @Test void upgradesAndMovesRemainServerAuthoritativeAcrossRevisions() throws Exception {
    try (var db = new VillageStore(temporary.resolve("upgrade.db"))) {
      var game = service(db); var v = game.state(first, Region.HOME, 1000);
      var upgrade = request("upgrade", v.revision); upgrade.addProperty("building", "hall");
      var quote = game.quote(v, "hall");
      game.execute(first, upgrade, 1000);
      var paid = db.load(first.toString(), Region.HOME);
      assertEquals(100000-quote.cost(), paid.resources.get(quote.currency()));
      assertThrows(IllegalArgumentException.class, () -> game.execute(first, place(0, 2, 2), 1001));
      v = game.state(first, Region.HOME, paid.jobs.getFirst().finishes());
      assertEquals(2, v.hall); assertEquals(2, v.building("hall").level());
      var move = request("move", v.revision); move.addProperty("building", "hall");
      move.addProperty("x", 25); move.addProperty("z", 25);
      game.execute(first, move, 1000+quote.seconds()*1000);
      assertEquals(25, db.load(first.toString(), Region.HOME).building("hall").x());
    }
  }
}
