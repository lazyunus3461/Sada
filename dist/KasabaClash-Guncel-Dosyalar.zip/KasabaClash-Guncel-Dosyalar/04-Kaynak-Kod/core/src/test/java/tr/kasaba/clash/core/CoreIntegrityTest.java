package tr.kasaba.clash.core;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Path;
import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

class CoreIntegrityTest {
  @TempDir Path temporary;
  Catalog catalog;

  @BeforeEach
  void load() throws Exception {
    catalog = Catalog.bundled();
  }

  Village fixture() {
    var v = Village.create("account-A", Region.HOME);
    v.hall = 2;
    v.resources.put("Elixir", 10000L);
    var camp = catalog.building(Region.HOME, "Army Camp");
    v.buildings.add(new Village.Building("camp", camp.key(), 4, 4, camp.width(), 1));
    return v;
  }

  @Test
  void sourceCatalogKeepsEveryLevelAndDoesNotPretendCapitalIsPresent() {
    assertEquals(76, catalog.family("buildings").size());
    assertEquals(18, catalog.building(Region.HOME, "Town Hall").maximum());
    assertEquals(10, catalog.building(Region.BUILDER, "Builder Hall").maximum());
    assertFalse(catalog.supports(Region.CAPITAL));
    assertThrows(
        IllegalArgumentException.class, () -> catalog.building(Region.CAPITAL, "Capital Hall"));
    var camp = catalog.building(Region.HOME, "Army Camp");
    var row = camp.level(2);
    row.addProperty("build_cost", 0);
    assertEquals(2000, camp.level(2).get("build_cost").getAsLong());
    var accountSafety =
        catalog.family("achievements").stream()
            .filter(x -> x.name().equals("Keep Your Account Safe!"))
            .findFirst()
            .orElseThrow();
    assertTrue(accountSafety.levels().isEmpty());
    assertEquals(2, accountSafety.properties().getAsJsonArray("levels").size());
  }

  @Test
  void realSourceUpgradeChargesOnceAndCompletesOnceAcrossReopen() throws Exception {
    Path path = temporary.resolve("village.db");
    var construction = new Construction(catalog);
    long ends;
    try (var db = new VillageStore(path)) {
      db.create(fixture());
      var quote = construction.quote(db.load("account-A", Region.HOME), "camp");
      assertEquals(2000, quote.cost());
      assertEquals(300, quote.seconds());
      var receipt =
          db.transact(
              "account-A",
              Region.HOME,
              0,
              "upgrade-0001",
              "upgrade camp",
              v -> {
                construction.start(v, quote, 1000, "job1");
                return "started";
              });
      assertFalse(receipt.replay());
      var replay =
          db.transact(
              "account-A",
              Region.HOME,
              0,
              "upgrade-0001",
              "upgrade camp",
              v -> {
                fail("Replay must not invoke mutation");
                return "bad";
              });
      assertTrue(replay.replay());
      var v = db.load("account-A", Region.HOME);
      assertEquals(8000, v.resources.get("Elixir"));
      ends = v.jobs.getFirst().finishes();
      assertEquals(301000, ends);
    }
    try (var db = new VillageStore(path)) {
      db.transact(
          "account-A",
          Region.HOME,
          1,
          "settle-00001",
          "settle",
          v -> {
            assertEquals(0, construction.finish(v, 300999));
            assertEquals(1, construction.finish(v, 301000));
            assertEquals(0, construction.finish(v, 301001));
            return "done";
          });
      var after = db.load("account-A", Region.HOME);
      assertEquals(2, after.building("camp").level());
      assertEquals(8000, after.resources.get("Elixir"));
      assertTrue(after.jobs.isEmpty());
    }
  }

  @Test
  void failedOrStaleRequestsCannotSpendResourcesOrChangeAnotherVillage() throws Exception {
    try (var db = new VillageStore(temporary.resolve("rollback.db"))) {
      db.create(fixture());
      assertThrows(
          IllegalArgumentException.class,
          () ->
              db.transact(
                  "account-A",
                  Region.HOME,
                  0,
                  "failed-0001",
                  "buy",
                  v -> {
                    v.debit("Elixir", 500);
                    throw new IllegalArgumentException("injected failure");
                  }));
      assertEquals(10000, db.load("account-A", Region.HOME).resources.get("Elixir"));
      assertThrows(
          IllegalArgumentException.class,
          () -> db.transact("account-A", Region.HOME, 9, "stale-0001", "buy", v -> "never"));
      db.transact(
          "account-A",
          Region.HOME,
          0,
          "valid-0001",
          "buy",
          v -> {
            v.debit("Elixir", 500);
            return "paid";
          });
      assertThrows(
          IllegalArgumentException.class,
          () ->
              db.transact(
                  "account-A", Region.HOME, 1, "valid-0001", "different payload", v -> "never"));
      assertThrows(
          IllegalStateException.class,
          () ->
              db.transact(
                  "account-A",
                  Region.HOME,
                  1,
                  "owner-0001",
                  "change",
                  v -> {
                    v.owner = "account-B";
                    return "changed";
                  }));
      assertEquals(9500, db.load("account-A", Region.HOME).resources.get("Elixir"));
    }
  }

  @Test
  void constructionRejectsOccupiedOrOutOfBoundsTilesAndBusyBuilder() {
    var v = fixture();
    var service = new Construction(catalog);
    assertThrows(IllegalArgumentException.class, () -> service.move(v, "camp", 43, 43));
    v.buildings.add(new Village.Building("second", v.building("camp").catalogKey(), 12, 12, 4, 1));
    assertThrows(IllegalArgumentException.class, () -> service.move(v, "second", 5, 5));
    service.start(v, service.quote(v, "camp"), 1000, "work-A");
    var quote = service.quote(v, "second");
    assertThrows(IllegalArgumentException.class, () -> service.start(v, quote, 1000, "work-B"));
    assertEquals(8000, v.resources.get("Elixir"));
  }

  @Test
  void hallUnlocksUseActualIncrementalCountsInsteadOfInventedGlobalLimits() {
    var rules = new HallRules(catalog);
    var cannon = catalog.building(Region.HOME, "Cannon");
    assertEquals(1, rules.limits(Region.HOME, 1).get(cannon.sourceId()));
    assertEquals(2, rules.limits(Region.HOME, 2).get(cannon.sourceId()));
    assertEquals(7, rules.limits(Region.HOME, 18).get(cannon.sourceId()));
    var v = fixture();
    var camp = catalog.building(Region.HOME, "Army Camp");
    assertThrows(IllegalArgumentException.class, () -> rules.requirePlacement(v, camp));
    assertThrows(IllegalArgumentException.class, () -> rules.limits(Region.CAPITAL, 1));
    assertThrows(IllegalArgumentException.class, () -> rules.limits(Region.HOME, 19));
  }

  @Test
  void chunkedStateReordersSafelyAndRejectsCorruptionAndMixing() {
    byte[] source = new byte[70000];
    new Random(17).nextBytes(source);
    var frames = Wire.split(UUID.randomUUID(), source);
    var assembler = new Wire.Assembler();
    assertTrue(assembler.accept(frames.get(2), 100).isEmpty());
    assertTrue(assembler.accept(frames.get(0), 101).isEmpty());
    assertTrue(assembler.accept(frames.get(0), 102).isEmpty());
    assertArrayEquals(source, assembler.accept(frames.get(1), 103).orElseThrow());
    byte[] corrupt = frames.get(0).clone();
    corrupt[corrupt.length - 1] ^= 1;
    assembler.accept(corrupt, 200);
    assembler.accept(frames.get(1), 201);
    assertThrows(IllegalArgumentException.class, () -> assembler.accept(frames.get(2), 202));
    var other = Wire.split(UUID.randomUUID(), source);
    assembler.accept(frames.get(0), 300);
    assertThrows(IllegalArgumentException.class, () -> assembler.accept(other.get(1), 301));
    assertThrows(IllegalArgumentException.class, () -> Wire.command(new byte[8193]));
    assertThrows(
        IllegalArgumentException.class, () -> Wire.command(new byte[] {(byte) 0xc3, 0x28}));
  }
}
