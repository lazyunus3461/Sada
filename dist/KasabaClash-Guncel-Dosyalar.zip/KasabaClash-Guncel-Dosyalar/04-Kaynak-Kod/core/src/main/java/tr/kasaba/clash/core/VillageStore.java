package tr.kasaba.clash.core;

import com.google.gson.Gson;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.sql.*;
import java.util.*;
import java.util.function.Function;

/** One durable SQLite transaction joins state, resources, revision and command replay receipt. */
public final class VillageStore implements AutoCloseable {
  private final Connection db;
  private final Gson gson = new Gson();
  private boolean transaction;

  public record Receipt(boolean replay, long revision, String result) {}

  public VillageStore(Path file) throws Exception {
    Files.createDirectories(file.toAbsolutePath().getParent());
    db = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
    try (var s = db.createStatement()) {
      s.execute("PRAGMA journal_mode=WAL");
      s.execute("PRAGMA synchronous=FULL");
      s.execute("PRAGMA busy_timeout=5000");
      s.execute(
          "CREATE TABLE IF NOT EXISTS villages (owner TEXT NOT NULL, region TEXT NOT NULL, revision"
              + " INTEGER NOT NULL, data TEXT NOT NULL, PRIMARY KEY(owner,region))");
      s.execute(
          "CREATE TABLE IF NOT EXISTS receipts (owner TEXT NOT NULL, region TEXT NOT NULL, token"
              + " TEXT NOT NULL, payload TEXT NOT NULL, revision INTEGER NOT NULL, response TEXT"
              + " NOT NULL, PRIMARY KEY(owner,region,token))");
      try (var check = s.executeQuery("PRAGMA quick_check")) {
        if (!check.next() || !check.getString(1).equals("ok"))
          throw new SQLException("Köy veritabanı bütünlüğü doğrulanamadı.");
      }
    }
  }

  public synchronized void create(Village value) throws SQLException {
    if (transaction) throw new IllegalStateException("Create inside mutation");
    value.validate();
    if (value.revision != 0) throw new IllegalArgumentException("Yeni köy sürümü sıfır olmalı.");
    try (var s = db.prepareStatement("INSERT INTO villages VALUES(?,?,?,?)")) {
      s.setString(1, value.owner);
      s.setString(2, value.region.name());
      s.setLong(3, 0);
      s.setString(4, gson.toJson(value));
      s.executeUpdate();
    }
  }

  public synchronized Village load(String owner, Region region) throws SQLException {
    return find(owner, region)
        .orElseThrow(() -> new IllegalArgumentException("Köy kaydı yok."));
  }

  public synchronized Optional<Village> find(String owner, Region region) throws SQLException {
    try (var s =
        db.prepareStatement("SELECT revision,data FROM villages WHERE owner=? AND region=?")) {
      s.setString(1, owner);
      s.setString(2, region.name());
      try (var rows = s.executeQuery()) {
        if (!rows.next()) return Optional.empty();
        var value = gson.fromJson(rows.getString(2), Village.class);
        value.validate();
        if (!owner.equals(value.owner)
            || region != value.region
            || value.revision != rows.getLong(1))
          throw new IllegalStateException("Köy kimliği veya sürümü bozuk; veri korundu.");
        return Optional.of(value);
      }
    }
  }

  public synchronized Receipt transact(
      String owner,
      Region region,
      long expectedRevision,
      String token,
      String payload,
      Function<Village, String> action)
      throws Exception {
    if (transaction) throw new IllegalStateException("Nested transaction");
    if (token == null
        || !token.matches("[A-Za-z0-9_-]{8,80}")
        || payload == null
        || payload.getBytes(StandardCharsets.UTF_8).length > 8192)
      throw new IllegalArgumentException("Geçersiz işlem çerçevesi.");
    String digest =
        HexFormat.of()
            .formatHex(
                MessageDigest.getInstance("SHA-256")
                    .digest(payload.getBytes(StandardCharsets.UTF_8)));
    db.setAutoCommit(false);
    transaction = true;
    try {
      try (var s =
          db.prepareStatement(
              "SELECT payload,revision,response FROM receipts WHERE owner=? AND region=? AND"
                  + " token=?")) {
        s.setString(1, owner);
        s.setString(2, region.name());
        s.setString(3, token);
        try (var old = s.executeQuery()) {
          if (old.next()) {
            if (!digest.equals(old.getString(1)))
              throw new IllegalArgumentException("İşlem kodu farklı içerikle kullanılmış.");
            var receipt = new Receipt(true, old.getLong(2), old.getString(3));
            db.commit();
            return receipt;
          }
        }
      }
      var state = load(owner, region);
      if (state.revision != expectedRevision)
        throw new IllegalArgumentException("Köy değişti; son durumu yeniden yükle.");
      String result = Objects.requireNonNull(action.apply(state));
      state.validate();
      if (!owner.equals(state.owner)
          || region != state.region
          || state.revision != expectedRevision)
        throw new IllegalStateException("İşlem köy kimliğini değiştiremez.");
      state.revision = Math.addExact(state.revision, 1);
      try (var s =
          db.prepareStatement(
              "UPDATE villages SET revision=?,data=? WHERE owner=? AND region=? AND revision=?")) {
        s.setLong(1, state.revision);
        s.setString(2, gson.toJson(state));
        s.setString(3, owner);
        s.setString(4, region.name());
        s.setLong(5, expectedRevision);
        if (s.executeUpdate() != 1) throw new IllegalStateException("Köy eşzamanlı değişti.");
      }
      try (var s = db.prepareStatement("INSERT INTO receipts VALUES(?,?,?,?,?,?)")) {
        s.setString(1, owner);
        s.setString(2, region.name());
        s.setString(3, token);
        s.setString(4, digest);
        s.setLong(5, state.revision);
        s.setString(6, result);
        s.executeUpdate();
      }
      db.commit();
      return new Receipt(false, state.revision, result);
    } catch (Exception failure) {
      try {
        db.rollback();
      } catch (SQLException rollback) {
        failure.addSuppressed(rollback);
      }
      throw failure;
    } finally {
      transaction = false;
      db.setAutoCommit(true);
    }
  }

  @Override
  public synchronized void close() throws SQLException {
    db.close();
  }
}
