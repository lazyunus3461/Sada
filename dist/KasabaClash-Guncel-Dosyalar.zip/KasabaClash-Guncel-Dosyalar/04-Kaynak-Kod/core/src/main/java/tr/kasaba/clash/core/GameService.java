package tr.kasaba.clash.core;

import com.google.gson.*;
import java.util.*;

/** Real construction operations; deliberately does not fabricate battles or missing Capital data. */
public final class GameService {
  private final VillageStore store;
  private final Catalog catalog;
  private final Construction construction;
  private final HallRules halls;
  private final Map<String, Long> initial;

  public GameService(VillageStore store, Catalog catalog, Map<String, Long> initial) {
    this.store = Objects.requireNonNull(store);
    this.catalog = Objects.requireNonNull(catalog);
    this.construction = new Construction(catalog);
    this.halls = new HallRules(catalog);
    this.initial = Map.copyOf(initial);
    if (initial.values().stream().anyMatch(v -> v == null || v < 0 || v > 1_000_000_000L))
      throw new IllegalArgumentException("Başlangıç kaynakları geçersiz.");
  }

  public synchronized Village state(UUID account, Region region, long now) throws Exception {
    if (now < 0) throw new IllegalArgumentException("Geçersiz sunucu zamanı.");
    if (!catalog.supports(region))
      throw new IllegalArgumentException("Bu bölgenin oyun verisi henüz tamamlanmadı.");
    String owner = Objects.requireNonNull(account).toString();
    var found = store.find(owner, region);
    if (found.isEmpty()) {
      var v = Village.create(owner, region);
      v.resources.putAll(initial);
      var hall = catalog.building(region, region == Region.HOME ? "Town Hall" : "Builder Hall");
      v.buildings.add(new Village.Building("hall", hall.key(), 20, 20, hall.width(), 1));
      if (region == Region.HOME) {
        var hut = catalog.building(region, "Builder's Hut");
        v.buildings.add(new Village.Building("builder", hut.key(), 15, 20, hut.width(), 1));
      }
      store.create(v);
      return store.load(owner, region);
    }
    var v = found.get();
    if (v.jobs.stream().anyMatch(j -> now >= j.finishes())) {
      store.transact(owner, region, v.revision, token(), "settle", current -> {
        settle(current, now);
        return "completed";
      });
      v = store.load(owner, region);
    }
    return v;
  }

  /** Session, authentication and request-rate checks belong to the real Paper connection adapter. */
  public synchronized VillageStore.Receipt execute(UUID account, JsonObject request, long now)
      throws Exception {
    String type = text(request, "type");
    Set<String> allowed = new HashSet<>(Set.of("v", "type", "session", "region", "token", "revision"));
    switch (type) {
      case "place" -> allowed.addAll(Set.of("key", "x", "z"));
      case "move" -> allowed.addAll(Set.of("building", "x", "z"));
      case "upgrade" -> allowed.add("building");
      default -> throw new IllegalArgumentException("Bu oyun işlemi henüz uygulanmadı: " + type);
    }
    if (!allowed.containsAll(request.keySet()))
      throw new IllegalArgumentException("İstemci isteğinde desteklenmeyen alan var.");
    if (integer(request, "v") != Wire.VERSION)
      throw new IllegalArgumentException("İstemci protokolü uyuşmuyor.");
    Region region = Region.valueOf(text(request, "region"));
    var before = state(account, region, now);
    long expected = integer(request, "revision");
    String nonce = text(request, "token");
    String payload = request.toString();
    return store.transact(account.toString(), region, expected, nonce, payload, v -> {
      switch (type) {
        case "place" -> {
          var item = catalog.item(text(request, "key"));
          halls.requirePlacement(v, item);
          int x = coordinate(request, "x"), z = coordinate(request, "z");
          if (!v.free(x, z, item.width(), null))
            throw new IllegalArgumentException("Bina bu konuma sığmıyor.");
          String id = "b_" + UUID.randomUUID().toString().replace("-", "");
          v.buildings.add(new Village.Building(id, item.key(), x, z, item.width(), 0));
          construction.start(v, construction.quote(v, id), now, token());
          settle(v, now);
          return id;
        }
        case "upgrade" -> {
          String id = text(request, "building");
          construction.start(v, construction.quote(v, id), now, token());
          settle(v, now);
          return id;
        }
        case "move" -> {
          String id = text(request, "building");
          construction.move(v, id, coordinate(request, "x"), coordinate(request, "z"));
          return id;
        }
        default -> throw new IllegalArgumentException("Desteklenmeyen işlem.");
      }
    });
  }

  private void settle(Village v, long now) {
    construction.finish(v, now);
    if (v.region == Region.HOME) {
      long built = v.buildings.stream().filter(b -> b.level() > 0
          && catalog.item(b.catalogKey()).name().equals("Builder's Hut")).count();
      v.builders = Math.max(1, Math.min(10, Math.toIntExact(built)));
      v.validate();
    }
  }

  public Construction.Quote quote(Village v, String building) {
    return construction.quote(v, building);
  }

  public static String text(JsonObject request, String key) {
    var x = request.get(key);
    if (x == null || !x.isJsonPrimitive() || !x.getAsJsonPrimitive().isString()
        || x.getAsString().isBlank() || x.getAsString().length() > 128)
      throw new IllegalArgumentException("Geçersiz alan: " + key);
    return x.getAsString();
  }

  public static long integer(JsonObject request, String key) {
    var x = request.get(key);
    if (x == null || !x.isJsonPrimitive() || !x.getAsJsonPrimitive().isNumber())
      throw new IllegalArgumentException("Sayısal alan gerekli: " + key);
    try { return x.getAsBigDecimal().longValueExact(); }
    catch (ArithmeticException ex) { throw new IllegalArgumentException("Tam sayı gerekli: " + key); }
  }

  private static int coordinate(JsonObject request, String key) {
    long x = integer(request, key);
    if (x < 0 || x > 99) throw new IllegalArgumentException("Konum sınır dışında.");
    return (int) x;
  }

  private static String token() { return UUID.randomUUID().toString(); }
}
