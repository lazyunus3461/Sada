package tr.kasaba.clash.core;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** A pinned factual catalog, not a declaration that every listed feature is implemented. */
public final class Catalog {
  public record Item(
      String key,
      String family,
      long sourceId,
      String name,
      String displayName,
      String village,
      String resource,
      int width,
      SortedMap<Integer, JsonObject> levels,
      JsonObject properties) {
    public Item {
      if (key == null || name == null || name.isBlank() || width < 1 || width > 12)
        throw new IllegalArgumentException("Invalid catalog item");
      TreeMap<Integer, JsonObject> copy = new TreeMap<>();
      levels.forEach((k, v) -> copy.put(k, v.deepCopy()));
      levels = Collections.unmodifiableSortedMap(copy);
      properties = properties.deepCopy();
    }

    @Override
    public SortedMap<Integer, JsonObject> levels() {
      TreeMap<Integer, JsonObject> copy = new TreeMap<>();
      levels.forEach((k, v) -> copy.put(k, v.deepCopy()));
      return Collections.unmodifiableSortedMap(copy);
    }

    @Override
    public JsonObject properties() {
      return properties.deepCopy();
    }

    public JsonObject level(int level) {
      var row = levels.get(level);
      if (row == null)
        throw new IllegalArgumentException("Seviye kaydı doğrulanmamış: " + name + " / " + level);
      return row.deepCopy();
    }

    public int maximum() {
      return levels.isEmpty() ? 0 : levels.lastKey();
    }
  }

  private final Map<String, Item> entries;
  private final String snapshot;

  public Catalog(InputStream input) throws IOException {
    Objects.requireNonNull(input, "Catalog missing");
    JsonObject data;
    try (var reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
      data = JsonParser.parseReader(reader).getAsJsonObject();
    }
    if (data.get("schema").getAsInt() != 1) throw new IOException("Unsupported catalog schema");
    snapshot = data.get("snapshotSha256").getAsString();
    if (!snapshot.matches("[a-f0-9]{64}")) throw new IOException("Invalid catalog digest");
    Map<String, Item> result = new LinkedHashMap<>();
    for (var raw : data.getAsJsonArray("items")) {
      var row = raw.getAsJsonObject();
      String family = row.get("family").getAsString(), key = row.get("key").getAsString();
      var source = row.getAsJsonObject("data");
      TreeMap<Integer, JsonObject> levels = new TreeMap<>();
      // Achievement milestones may intentionally share a source level. Keep them in properties;
      // they are criteria, not construction/research upgrades keyed by a unique target level.
      if (!family.equals("achievements") && source.has("levels"))
        for (var l : source.getAsJsonArray("levels")) {
          var level = l.getAsJsonObject();
          if (!level.has("level")) continue;
          int n = level.get("level").getAsInt();
          if (n < 1 || n > 1000 || levels.put(n, level) != null)
            throw new IOException("Invalid or duplicate level: " + key);
        }
      long id = source.has("_id") ? source.get("_id").getAsLong() : -1;
      var item =
          new Item(
              key,
              family,
              id,
              row.get("name").getAsString(),
              row.get("displayName").getAsString(),
              text(source, "village", ""),
              text(source, "upgrade_resource", ""),
              source.has("width") ? source.get("width").getAsInt() : 1,
              levels,
              source);
      if (result.put(key, item) != null) throw new IOException("Duplicate catalog key: " + key);
    }
    entries = Collections.unmodifiableMap(result);
  }

  public static Catalog bundled() throws IOException {
    return new Catalog(Catalog.class.getResourceAsStream("/catalog/catalog.json"));
  }

  public String snapshot() {
    return snapshot;
  }

  public Collection<Item> all() {
    return entries.values();
  }

  public Item item(String key) {
    var item = entries.get(key);
    if (item == null) throw new IllegalArgumentException("İçerik kaydı bulunamadı: " + key);
    return item;
  }

  public List<Item> family(String kind) {
    return entries.values().stream().filter(x -> x.family.equals(kind)).toList();
  }

  public List<Item> buildings(Region region) {
    return family("buildings").stream()
        .filter(x -> x.village.equals(region.sourceName()) && !x.levels.isEmpty())
        .toList();
  }

  public Item building(Region region, String name) {
    return buildings(region).stream()
        .filter(x -> x.name.equals(name))
        .findFirst()
        .orElseThrow(
            () ->
                new IllegalArgumentException(
                    "Bu bölge için bina istatistikleri doğrulanmamış: " + name));
  }

  public boolean supports(Region region) {
    return !buildings(region).isEmpty();
  }

  private static String text(JsonObject o, String key, String fallback) {
    return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : fallback;
  }
}
