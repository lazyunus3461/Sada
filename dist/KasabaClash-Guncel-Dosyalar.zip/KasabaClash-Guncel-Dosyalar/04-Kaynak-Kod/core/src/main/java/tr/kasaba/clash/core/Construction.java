package tr.kasaba.clash.core;

import java.util.*;

/** Cost and time always come from server-side catalog rows, never a client quote. */
public final class Construction {
  private final Catalog catalog;

  public record Quote(
      String building,
      String item,
      int current,
      int target,
      String currency,
      long cost,
      long seconds,
      int requiredHall,
      long revision) {}

  public Construction(Catalog catalog) {
    this.catalog = Objects.requireNonNull(catalog);
  }

  public Quote quote(Village village, String buildingId) {
    var b = village.building(buildingId);
    var item = catalog.item(b.catalogKey());
    if (!item.family().equals("buildings") || !item.village().equals(village.region.sourceName()))
      throw new IllegalArgumentException("Bina bu bölgeye ait değil.");
    if (village.jobs.stream().anyMatch(j -> j.building().equals(buildingId)))
      throw new IllegalArgumentException("Bu bina zaten geliştiriliyor.");
    var next = item.level(Math.addExact(b.level(), 1));
    for (String field : List.of("build_cost", "build_time", "required_townhall"))
      if (!next.has(field) || next.get(field).isJsonNull())
        throw new IllegalArgumentException("Geliştirme verisi eksik: " + field);
    long cost = next.get("build_cost").getAsLong(), seconds = next.get("build_time").getAsLong();
    int hall = next.get("required_townhall").getAsInt();
    if (cost < 0 || seconds < 0 || seconds > 366L * 86400 || item.resource().isBlank())
      throw new IllegalArgumentException("Geliştirme bedeli doğrulanmamış.");
    return new Quote(
        b.id(),
        item.key(),
        b.level(),
        b.level() + 1,
        item.resource(),
        cost,
        seconds,
        hall,
        village.revision);
  }

  public void start(Village v, Quote quote, long now, String jobId) {
    if (!quote(v, quote.building()).equals(quote))
      throw new IllegalArgumentException("Teklif değişti; tekrar incele.");
    if (v.hall < quote.requiredHall())
      throw new IllegalArgumentException("Gerekli belediye seviyesi: " + quote.requiredHall());
    Set<Integer> busy = new HashSet<>();
    v.jobs.forEach(j -> busy.add(j.worker()));
    int worker = 0;
    while (busy.contains(worker)) worker++;
    if (worker >= v.builders) throw new IllegalArgumentException("Boş inşaatçı yok.");
    long until = Math.addExact(now, Math.multiplyExact(quote.seconds(), 1000));
    if (v.jobs.stream().anyMatch(j -> j.id().equals(jobId)))
      throw new IllegalArgumentException("Geliştirme işlem kodu kullanılmış.");
    var job = new Village.Job(jobId, quote.building(), quote.target(), now, until, worker);
    v.debit(quote.currency(), quote.cost());
    v.jobs.add(job);
    v.validate();
  }

  public int finish(Village v, long now) {
    int completed = 0;
    for (var job : List.copyOf(v.jobs))
      if (now >= job.finishes()) {
        var b = v.building(job.building());
        var item = catalog.item(b.catalogKey());
        item.level(job.target());
        if (b.level() + 1 != job.target())
          throw new IllegalStateException("Geliştirme kaydı tutarsız; korundu.");
        v.buildings.set(v.buildings.indexOf(b), b.level(job.target()));
        v.jobs.remove(job);
        if (item.name().equals("Town Hall") || item.name().equals("Builder Hall"))
          v.hall = job.target();
        completed++;
      }
    v.validate();
    return completed;
  }

  public void move(Village v, String building, int x, int z) {
    var b = v.building(building);
    if (!v.free(x, z, b.width(), b.id()))
      throw new IllegalArgumentException("Bu alana bina sığmıyor.");
    v.buildings.set(
        v.buildings.indexOf(b),
        new Village.Building(b.id(), b.catalogKey(), x, z, b.width(), b.level()));
    v.validate();
  }
}
