package tr.kasaba.clash.core;

public enum Region {
  HOME,
  BUILDER,
  CAPITAL;

  public String sourceName() {
    return switch (this) {
      case HOME -> "home";
      case BUILDER -> "builderBase";
      case CAPITAL -> "clanCapital";
    };
  }
}
