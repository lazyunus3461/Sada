package tr.kasaba.clash.core;

import java.util.*;

/** Persistent game state. Construction jobs reserve their footprint immediately. */
public final class Village {
  public int schema = 1;
  public long revision;
  public String owner;
  public Region region;
  public int stage = 1;
  public int hall = 1;
  public int builders = 1;
  public int size = 44;
  public Map<String, Long> resources = new TreeMap<>();
  public List<Building> buildings = new ArrayList<>();
  public List<Job> jobs = new ArrayList<>();
  public Set<String> claimed = new TreeSet<>();

  public record Building(String id, String catalogKey, int x, int z, int width, int level) {
    public Building {
      if (id == null
          || !id.matches("[a-zA-Z0-9_-]{1,64}")
          || catalogKey == null
          || width < 1
          || width > 12
          || level < 0) throw new IllegalArgumentException("Geçersiz bina kaydı.");
    }

    public Building level(int value) {
      return new Building(id, catalogKey, x, z, width, value);
    }
  }

  public record Job(
      String id, String building, int target, long starts, long finishes, int worker) {
    public Job {
      if (id == null
          || building == null
          || target < 1
          || starts < 0
          || finishes < starts
          || worker < 0) throw new IllegalArgumentException("Geçersiz geliştirme kaydı.");
    }
  }

  public static Village create(String owner, Region region) {
    if (owner == null || owner.isBlank() || owner.length() > 128)
      throw new IllegalArgumentException("Geçersiz köy sahibi.");
    var v = new Village();
    v.owner = owner;
    v.region = Objects.requireNonNull(region);
    return v;
  }

  public Building building(String id) {
    return buildings.stream()
        .filter(x -> x.id.equals(id))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Bina yok."));
  }

  public void debit(String resource, long amount) {
    if (amount < 0) throw new IllegalArgumentException("Negatif maliyet.");
    long old = resources.getOrDefault(resource, 0L);
    if (old < amount) throw new IllegalArgumentException("Yeterli " + resource + " yok.");
    resources.put(resource, old - amount);
  }

  public boolean free(int x, int z, int width, String except) {
    if (x < 0 || z < 0 || width < 1 || x + width > size || z + width > size) return false;
    return buildings.stream()
        .noneMatch(
            b ->
                !b.id.equals(except)
                    && x < b.x + b.width
                    && x + width > b.x
                    && z < b.z + b.width
                    && z + width > b.z);
  }

  public void validate() {
    if (schema != 1
        || owner == null
        || owner.isBlank()
        || region == null
        || revision < 0
        || hall < 1
        || hall > 100
        || builders < 1
        || builders > 10
        || size < 10
        || size > 100) throw new IllegalArgumentException("Köy kaydı geçersiz.");
    if (resources == null
        || buildings == null
        || jobs == null
        || claimed == null
        || resources.values().stream().anyMatch(x -> x == null || x < 0))
      throw new IllegalArgumentException("Köy bakiyesi geçersiz.");
    Set<String> ids = new HashSet<>();
    for (var b : buildings)
      if (!ids.add(b.id) || !free(b.x, b.z, b.width, b.id))
        throw new IllegalArgumentException("Binalar çakışıyor.");
    Set<String> jobIds = new HashSet<>(), targets = new HashSet<>();
    Set<Integer> workers = new HashSet<>();
    for (var j : jobs) {
      var b = building(j.building);
      if (!jobIds.add(j.id)
          || !targets.add(j.building)
          || !workers.add(j.worker)
          || j.worker >= builders
          || j.target != b.level + 1)
        throw new IllegalArgumentException("Geliştirme kuyruğu geçersiz.");
    }
  }
}
