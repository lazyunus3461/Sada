package tr.kasaba.clash.core;

import java.util.*;

/** Unlock quantities are cumulative deltas in the verified hall-level source rows. */
public final class HallRules {
  private final Catalog catalog;

  public HallRules(Catalog catalog) {
    this.catalog = Objects.requireNonNull(catalog);
  }

  public Map<Long, Integer> limits(Region region, int hallLevel) {
    if (region == Region.CAPITAL)
      throw new IllegalArgumentException("Klan Başkenti açılma verileri doğrulanmamış.");
    var hall = catalog.building(region, region == Region.HOME ? "Town Hall" : "Builder Hall");
    if (hallLevel < 1 || hallLevel > hall.maximum())
      throw new IllegalArgumentException("Belediye seviyesi kaydı yok.");
    Map<Long, Integer> result = new LinkedHashMap<>();
    for (int level = 1; level <= hallLevel; level++) {
      var row = hall.level(level);
      if (!row.has("unlocks")) continue;
      for (var entry : row.getAsJsonArray("unlocks")) {
        var unlock = entry.getAsJsonObject();
        long id = unlock.get("_id").getAsLong();
        int quantity = unlock.get("quantity").getAsInt();
        if (quantity < 1) throw new IllegalStateException("Bina açılma miktarı geçersiz.");
        result.merge(id, quantity, Math::addExact);
      }
    }
    return Collections.unmodifiableMap(result);
  }

  public void requirePlacement(Village village, Catalog.Item building) {
    if (!building.family().equals("buildings")
        || !building.village().equals(village.region.sourceName()))
      throw new IllegalArgumentException("Bina bu bölgeye ait değil.");
    int limit = limits(village.region, village.hall).getOrDefault(building.sourceId(), 0);
    long existing =
        village.buildings.stream().filter(b -> b.catalogKey().equals(building.key())).count();
    if (existing >= limit)
      throw new IllegalArgumentException(
          limit == 0
              ? "Bina bu belediye seviyesinde açılmamış."
              : "Bu binanın adet sınırı dolu: " + limit);
  }
}
