package tr.kasaba.clash.core;

import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.security.*;
import java.util.*;

/** Bounded plugin-message framing shared by the server and the approved client mod. */
public final class Wire {
  private Wire() {}

  public static final int VERSION = 1,
      MAX_COMMAND = 8192,
      MAX_SNAPSHOT = 2 * 1024 * 1024,
      CHUNK = 24000;
  private static final int HEADER = 4 + 4 + 16 + 4 + 4 + 4 + 32;
  private static final int MAGIC = 0x4b434c48;

  public record Frame(UUID transfer, int part, int parts, int total, byte[] hash, byte[] payload) {
    public Frame {
      hash = hash.clone();
      payload = payload.clone();
    }

    @Override
    public byte[] hash() {
      return hash.clone();
    }

    @Override
    public byte[] payload() {
      return payload.clone();
    }
  }

  public static String command(byte[] bytes) {
    if (bytes.length < 2 || bytes.length > MAX_COMMAND)
      throw new IllegalArgumentException("Komut boyutu geçersiz.");
    try {
      return StandardCharsets.UTF_8
          .newDecoder()
          .onMalformedInput(CodingErrorAction.REPORT)
          .decode(ByteBuffer.wrap(bytes))
          .toString();
    } catch (CharacterCodingException e) {
      throw new IllegalArgumentException("Geçersiz UTF-8.", e);
    }
  }

  public static List<byte[]> split(UUID id, byte[] snapshot) {
    if (snapshot.length < 1 || snapshot.length > MAX_SNAPSHOT)
      throw new IllegalArgumentException("Durum boyutu geçersiz.");
    byte[] hash = hash(snapshot);
    int count = (snapshot.length + CHUNK - 1) / CHUNK;
    List<byte[]> result = new ArrayList<>();
    for (int part = 0; part < count; part++) {
      byte[] payload =
          Arrays.copyOfRange(snapshot, part * CHUNK, Math.min(snapshot.length, (part + 1) * CHUNK));
      ByteBuffer b = ByteBuffer.allocate(HEADER + payload.length);
      b.putInt(MAGIC)
          .putInt(VERSION)
          .putLong(id.getMostSignificantBits())
          .putLong(id.getLeastSignificantBits())
          .putInt(part)
          .putInt(count)
          .putInt(snapshot.length)
          .put(hash)
          .put(payload);
      result.add(b.array());
    }
    return List.copyOf(result);
  }

  public static Frame decode(byte[] packet) {
    if (packet.length < HEADER + 1 || packet.length > HEADER + CHUNK)
      throw new IllegalArgumentException("Çerçeve boyutu geçersiz.");
    var b = ByteBuffer.wrap(packet);
    if (b.getInt() != MAGIC || b.getInt() != VERSION)
      throw new IllegalArgumentException("İstemci protokolü uyuşmuyor.");
    UUID id = new UUID(b.getLong(), b.getLong());
    int part = b.getInt(), parts = b.getInt(), total = b.getInt();
    byte[] hash = new byte[32];
    b.get(hash);
    byte[] payload = new byte[b.remaining()];
    b.get(payload);
    if (total < 1
        || total > MAX_SNAPSHOT
        || parts != (total + CHUNK - 1) / CHUNK
        || part < 0
        || part >= parts
        || payload.length != Math.min(CHUNK, total - part * CHUNK))
      throw new IllegalArgumentException("Parça sınırları geçersiz.");
    return new Frame(id, part, parts, total, hash, payload);
  }

  public static final class Assembler {
    private UUID transfer;
    private int total;
    private long expires;
    private byte[] expected;
    private byte[][] data;

    public synchronized Optional<byte[]> accept(byte[] packet, long now) {
      Frame f = decode(packet);
      if (transfer == null || now >= expires) {
        transfer = f.transfer;
        total = f.total;
        expected = f.hash;
        data = new byte[f.parts][];
        expires = Math.addExact(now, 10000);
      }
      if (!transfer.equals(f.transfer)
          || total != f.total
          || !Arrays.equals(expected, f.hash)
          || data.length != f.parts)
        throw new IllegalArgumentException("Parçalar farklı durumlara ait.");
      if (data[f.part] != null && !Arrays.equals(data[f.part], f.payload))
        throw new IllegalArgumentException("Çakışan tekrar parçası.");
      data[f.part] = f.payload;
      for (byte[] part : data) if (part == null) return Optional.empty();
      byte[] merged = new byte[total];
      int pos = 0;
      for (byte[] part : data) {
        System.arraycopy(part, 0, merged, pos, part.length);
        pos += part.length;
      }
      if (!MessageDigest.isEqual(expected, hash(merged))) {
        clear();
        throw new IllegalArgumentException("Durum bütünlüğü doğrulanamadı.");
      }
      clear();
      return Optional.of(merged);
    }

    public synchronized void clear() {
      transfer = null;
      data = null;
      expected = null;
      total = 0;
      expires = 0;
    }
  }

  private static byte[] hash(byte[] value) {
    try {
      return MessageDigest.getInstance("SHA-256").digest(value);
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException(e);
    }
  }
}
