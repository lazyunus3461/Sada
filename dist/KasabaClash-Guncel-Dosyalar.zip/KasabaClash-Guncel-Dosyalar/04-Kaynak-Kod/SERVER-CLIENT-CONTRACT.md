# Onaylanan mimari ve kalan geliştirme

Hedef, Paper 1.21.10 / Java 21 sunucu eklentisi, Minecraft istemci modu ve kaynak paketidir. Üç bölge, bütün bina/asker gelişimleri, savaşlar, GUI ve kozmetikler isteniyor. Henüz tamamlanmış oyun veya üretim paketi yoktur.

## Veri otoritesi

Kaynak bakiyesi, geliştirme süresi, bina seviyesi, açılma koşulu, konum, birlik ve savaş sonucu sunucuda doğrulanır. İstemci yalnız eylem ister; maliyet, zaman, hasar, kazanç veya oyuncu/klan sahipliği bildiremez. Tekrarlanan bir işlem ikinci kez kaynak harcamaz. Çakışan işlem kodu ve eski köy sürümü reddedilir.

Köy/klan kimliği, kimliği doğrulanmış Minecraft hesabından ve ağın ortak klan servisinden çıkarılır. Müşterinin gönderdiği UUID ya da klan etiketine güvenilmez. Paper giriş/çıkış adaptörü envanter, oyun modu, deneyim, hareket ve önceki konum kurtarmasını yapmalıdır. Mevcut Skyblock ve ağ para kayıtlarına yazılmaz.

## Uygulanmış çekirdek

- `Catalog`: 30 dosyalık, SHA256 ve kaynak Git blob kimliği doğrulanan sabit veri kataloğu. Yapılandırılmış gerçekler ve Türkçe adlar uygulama kaynağına alınır; uzun kaynak açıklamaları alınmaz.
- `VillageStore`: SQLite FULL/WAL, atomik köy/bakiye/sürüm/istek kaydı, hata halinde geri alma, aynı işlemin yeniden uygulanmaması.
- `Construction`: gerçek katalog bedeli/süresiyle geliştirme teklifi, inşaatçı doluluğu, kalıcı zamanlayıcı ve tek kez tamamlanma, bina taşıma/çakışma denetimi.
- `HallRules`: belediye seviyelerindeki doğrulanmış açılma miktarlarını birleştirir; hayali global adet sınırı kullanmaz. Eksik Klan Başkenti verisi varsa bu özellik kullanılabilir kabul edilmez.
- `Wire`: boyut sınırlı UTF-8 komut, parçalara ayrılmış durum, protokol sürümü ve SHA256 bütünlük denetimi. Bu sınıfın varlığı Paper–Fabric bağlantısının bitmiş olduğu anlamına gelmez.
- `GameService`: kimliği Paper hesabından gelen iki bağımsız köy, katalog sınırlarıyla atomik yerleştirme, gerçek maliyet/süre, geliştirme ve konum taşıma; oyuncu çevrimdışıyken biten inşaatın ilk durum okumasında tamamlanması. Eksik Başkent ve savaş işlemleri açık hata verir.
- `server/ClashPlugin`: gerçek Paper 1.21.10 / Java 21 eklentisi. KasabaAuth doğrulaması, protokol/katalog eşleşmesi, bağlantıya özel oturum, saniyede on istek sınırı ve gerçek plugin-message yanıtları. Oturum çıkış/kapanışta temizlenir. Geliştirme bağlantısı varsayılan kapalıdır ve OP/yetki gerektirir. Bu adaptörün test istemcisiyle çalışması, Fabric istemci modu veya gerçek GUI’nin var olduğu anlamına gelmez.
- `client-common`: bağımsız derlenen istemci oturum/durum modeli, salt okunur UI izdüşümü, sürükleme/onay komutları ve kamera/viewport hesapları. Gerçek Fabric `Screen` ve render/ağ event bağlaması henüz yoktur. İstemci kaynak/maliyet/başarı üretmez; yalnız doğrulanmış sunucu yanıtını gösterir.

## Yanıt eşleştirmesi

`hello` ve `state` istekleri de `token` taşıyabilir; ortak istemci her isteğe UUID token ekler. Sunucu, başarılı ve nesne olarak ayrıştırılabilen başarısız yanıtlara `type` ve `token` döndürür. Mutasyonlarda token aynı zamanda kalıcı idempotency anahtarıdır; okumalarda yalnız yanıt eşleştirmesidir. Eski bir okuma yanıtı yeni isteği kapatamaz. Ayrıştırma/giriş kontrolünden önce reddedilen genel hata yanıtı istemci bağlantısını temizler. Başka hesap/bölge/katalog durumu reddedilir. Bu protokolün test edilmesi, istemci modunun render bileşeninin hazır olduğu anlamına gelmez.

## İstemci ve sunucu adaptöründe yapılacaklar

1. Gerçek Fabric/Minecraft SDK ile derlenen mod, oturum/sürüm/katalog eşleşmesi ve ağ kanalı.
2. Köy görünümü, yakınlaştırma/kamera, sürükle-bırak yerleşim, geliştirme ve inşaatçı ekranları.
3. Ordu, araştırma, kahraman/ekipman/evcil, kaynak toplama ve kapasite kuralları.
4. Savaş motoru, birliklerin gerçek hedef/rota/yetenek davranışı, iki aşamalı İnşaatçı savaşları, saldırı/sonuç kayıtları.
5. Ortak klan kimliğiyle Klan Başkenti, ilçe gelişimi/bağış ve baskın akışları. Mevcut ortak klan sağlayıcısı için güvenilir servis API'si gerekir.
6. Bina seviyelerinin görselleri, hareketli karakter modelleri, bütün GUI varlıkları ve kozmetikler. Bir ikonun bulunması karakter modelinin ya da animasyonunun hazır olduğu anlamına gelmez.
7. Envanter kurtarma, kimlik/erişim/bakım/izleme denetimleri, durum yenileme ve kötüye kullanım sınırları.
8. Gerçek istemciyle görsel/etkileşim kontrolleri, sunucuda çok oyunculu akışlar ve kapanış/kurtarma testleri. Ardından kaynak + iki JAR + kaynak paketi + kurulum belgesi.

## Teslim koşulu

Yalnız çekirdek testleri, açılan bir GUI veya bina ikonları bu hedefi tamamlamaz. Tamamlanmayan bir pakete “birebir, her şeyi hazır” denmez. Şimdiki `core/target` çıktısı kurulum eklentisi değildir ve kullanıcıya tam oyun diye teslim edilmez.
