#!/usr/bin/env bash
set -euo pipefail
cd /workspace/Sada
export JAVA_HOME=/workspace/jdk-21.0.9+10
export MAVEN_OPTS="${MAVEN_OPTS:-} -Djavax.net.ssl.trustStore=/workspace/kasaba-cacerts"
python3 kasaba-clash/tools/import_catalog.py
/workspace/apache-maven-3.9.11/bin/mvn \
  -s /workspace/kasaba-maven-settings.xml \
  -Dmaven.repo.local=/workspace/.m2/repository -B -ntp \
  -f kasaba-clash/pom.xml verify
