#!/usr/bin/env python3
"""Create the game-data resource from verified facts; prose and vendor UI text are omitted."""
from pathlib import Path
import hashlib,json

root=Path(__file__).resolve().parents[1]
research=root/'research'
sources=json.loads((research/'sources.json').read_text())
for source in sources:
    if 'error' in source:
        raise RuntimeError(source)
    if hashlib.sha256((research/source['path']).read_bytes()).hexdigest()!=source['sha256']:
        raise RuntimeError('Source integrity failure: '+source['path'])
translations=json.loads((research/'translations/TR.json').read_text())
omitted={'info','description','completed_message','TID'}
def facts(value):
    if isinstance(value,dict):
        return {k:facts(v)for k,v in value.items()if k not in omitted}
    if isinstance(value,list):
        return [facts(v)for v in value]
    return value
entries=[]
for path in sorted((research/'static_data').glob('*.json')):
    for item in json.loads(path.read_text())['items']:
        name=item.get('name',item.get('locale',''))
        if not name:
            raise RuntimeError('No stable item name: '+path.name)
        identity=str(item['_id'])if '_id'in item else hashlib.sha256(name.encode()).hexdigest()[:24]
        tid=item.get('TID',{}).get('name','')
        entries.append({'key':path.stem+'/'+identity,'family':path.stem,'name':name,
                        'displayName':translations.get(tid,name),'data':facts(item)})
keys=[r['key']for r in entries]
if len(keys)!=len(set(keys)):
    raise RuntimeError('Duplicate catalog keys')
source_hash=hashlib.sha256(json.dumps(sources,sort_keys=True).encode()).hexdigest()
result={'schema':1,'snapshotSha256':source_hash,'source':'ClashKing Assets public data snapshot',
        'officialPatchVerified':False,'capitalStatisticsComplete':False,'items':entries}
target=root/'core/src/main/resources/catalog/catalog.json'
target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n')
licenses=root/'core/src/main/resources/META-INF/licenses'
licenses.mkdir(parents=True,exist_ok=True)
(licenses/'ClashKing-Assets-GPL-3.0.txt').write_bytes((research/'CLASHKING-LICENSE.txt').read_bytes())
credits={'upstream':'ClashKingInc/ClashKingAssets','attribution':'ClashKing Assets contributors',
         'license':'GPL-3.0','sourceFiles':sources,'snapshotSha256':source_hash,
         'notice':'Community data snapshot; not an official Supercell release or a claim of complete game coverage.'}
(licenses/'ClashKing-Assets-sources.json').write_text(json.dumps(credits,indent=2)+'\n')
print('Imported factual entries:',len(entries),'bytes:',target.stat().st_size,'snapshot:',source_hash)
