"""Package the reviewed design, images, provenance and the editable GUI sources."""
from pathlib import Path
import json
import hashlib
import html
import shutil
import zipfile
import sys

root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1] if len(sys.argv)>1 else root/'dist/gui-preview').resolve()
routes=json.loads((out/'routes-verified.json').read_text())['screens']
checks=json.loads((out/'interaction-checks.json').read_text())
assert len(routes)==43 and all(x['passed'] for x in checks['checks'])
font='data:font/ttf;base64,'
common='''*{box-sizing:border-box}body{margin:0;background:#14242c;color:#d3dfe2;font-family:Arial,sans-serif}a{color:inherit;text-decoration:none}header{padding:40px 45px 30px;border-bottom:1px solid #a9cbd122}header small{color:#d5be7d;letter-spacing:3px;font-size:10px}h1{font-size:38px;margin:12px 0;color:#f7e2ac}header p{max-width:900px;font-size:14px;line-height:1.7;color:#a1b5bd}.tag{display:inline-block;border:1px solid #aab78477;background:#5a73402b;color:#dfebc7;font-size:11px;padding:9px 14px;border-radius:6px;margin:8px 10px 0 0}main{padding:30px 40px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}.card{background:#20343e;border:1px solid #799baa38;border-radius:10px;overflow:hidden;cursor:pointer;transition:.15s}.card:hover{border-color:#c5cc86;transform:translateY(-2px)}.crop{aspect-ratio:1352/894;position:relative;overflow:hidden;background:#12241d}.crop img{position:absolute;max-width:none;width:118.3432%;left:-18.3432%;top:-5.3691%}.caption{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 15px;color:#e9ddb8;font-size:13px}.caption small{font-size:10px;color:#7e9aa6}.filter{border:1px solid #708c9b;background:#233c48;color:#deeaee;padding:12px 15px;border-radius:7px;max-width:100%;width:340px;margin:0 0 25px}.section-title{font-size:20px;margin:10px 0 20px;color:#b8ced5}.dialog{position:fixed;inset:0;background:#07131bef;z-index:3;display:none;align-items:center;justify-content:center;padding:35px}.dialog.open{display:flex}.dialog img{max-width:94vw;max-height:90vh;object-fit:contain}.close{position:absolute;right:20px;top:10px;background:#324b58;color:white;font-size:32px;border:1px solid #8a9c9b;border-radius:8px;cursor:pointer;width:45px;height:45px}footer{padding:25px 45px;color:#7c98a4;font-size:11px;border-top:1px solid #728b992a;line-height:1.7}@media(max-width:900px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}header,main{padding:25px}h1{font-size:28px}}@media(max-width:550px){.grid{grid-template-columns:1fr}.dialog{padding:10px}}'''

def card(r):
    return f'''<a class="card" href="{html.escape(r['file'])}" data-title="{html.escape(r['title'])}"><div class="crop"><img src="{r['file']}" alt="{html.escape(r['title'])}" loading="lazy"></div><div class="caption"><span>{html.escape(r['title'])}</span><small>{routes.index(r)+1:02d} / 43</small></div></a>'''

gallery='''<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KasabaClash · 43 ekran görüntüsü</title><style>'''+common+'''</style><header><small>KASABA CLASH · ARAYÜZ GALERİSİ</small><h1>Bütün ekranlar, tek yerde.</h1><p>Ana Köy, İnşaatçı Üssü, Klan Başkenti ve 40 menü / araç ekranı. Bunlar HTML tasarım önizlemesinden alınmış görüntülerdir. Çalışan Minecraft istemcisinden alınmadı; tam oyun veya birebir resmi arayüz eşitliği değildir.</p><a class="tag" href="KasabaClash-GUI.html">Tıklanabilir önizlemeyi aç ↗</a><span class="tag">43 ekran · 26 etkileşim kontrolü</span></header><main><input class="filter" placeholder="Görüntülerde ara…" aria-label="Ekranlarda ara"><div class="grid">'''+''.join(card(r) for r in routes)+'''</div></main><footer>Görseller: ClashKingInc / ClashKingAssets. Kapsam ve lisanslar için README.txt dosyasını incele.<br>Hesap, bakiye, savaş ve klan bilgileri örnektir; işlemler oyuna uygulanmaz.</footer><div class="dialog" role="dialog" aria-modal="true" aria-label="Ekran görüntüsü"><button class="close" aria-label="Kapat">×</button><img alt=""></div><script>const d=document.querySelector('.dialog');document.querySelectorAll('.card').forEach(c=>c.onclick=e=>{e.preventDefault();d.querySelector('img').src=c.href;d.querySelector('img').alt=c.dataset.title;d.classList.add('open');d.querySelector('button').focus()});document.querySelector('.close').onclick=()=>d.classList.remove('open');d.onclick=e=>{if(e.target===d)d.classList.remove('open')};document.onkeydown=e=>{if(e.key==='Escape')d.classList.remove('open')};document.querySelector('.filter').oninput=e=>{let q=e.target.value.toLocaleLowerCase('tr');document.querySelectorAll('.card').forEach(c=>c.hidden=!c.dataset.title.toLocaleLowerCase('tr').includes(q))};</script></html>'''
(out/'Galeri.html').write_text(gallery)
selected=['home','builder','capital','upgrade','army','heroes','war','skins']
overview='''<!doctype html><html lang="tr"><meta charset="utf-8"><title>KasabaClash · Genel görünüm</title><style>'''+common+'''body{width:1600px}header{padding:30px 40px 20px}h1{font-size:34px}header p{font-size:13px;margin:7px 0}main{padding:25px 35px}.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:22px}.caption{font-size:18px}.caption small{font-size:11px}.crop{aspect-ratio:1352/894}footer{font-size:12px}</style><header><small>KASABA CLASH · TASARIM ÖNİZLEMESİ</small><h1>Köylerden savaş ekranına.</h1><p>43 ekranlık etkileşimli HTML galerisi · oyun sunucusuna bağlı değil · örnek hesap verileri</p></header><main><div class="grid">'''+''.join(card(next(r for r in routes if r['id']==i))for i in selected)+'''</div></main><footer>Tüm ekranlar: Galeri.html · Tıklanabilir dosya: KasabaClash-GUI.html<br>Bu görseller çalışan Minecraft GUI’si veya tamamlanmış oyun paketi değildir.</footer></html>'''
(out/'Genel-Gorunum.html').write_text(overview)
readme=f'''KASABA CLASH — GUI TASARIM GALERİSİ

Başlamak için KasabaClash-GUI.html dosyasını modern bir masaüstü tarayıcısında aç.
Tek dosyadır; görseller ve yazı tipi içindedir. İnternet gerekmez.
Galeri.html: 43 ekran görüntüsünü topluca incele; resme tıklayarak büyüt.
screenshots/: 43 ana ekran + geliştirme onayı + dar ekran örneği.

BU TESLİMİN KAPSAMI
Bu, tasarım incelemesi için hazırlanmış HTML arayüz önizlemesidir.
Çalışan Minecraft GUI’si, Paper eklentisi, istemci modu, kaynak paketi veya tam oyun değildir.
Resmi oyunun bütün ekranlarının eksiksiz / piksel piksel aynısı olduğu iddia edilmez.
Binalar ve karakterler 2B kaynak görselleridir; Minecraft 3B modelleri değildir.
Hesaplar, bakiyeler, savaşlar, sıralamalar ve görevler açıkça işaretlenmiş örnek verilerdir.
Yükseltme, bağış, ödül ve kozmetik seçimi sunucuya uygulanmaz; ödeme yapılmaz.
Kaynak kataloğunun güncel resmi yamayla tam eşitliği henüz doğrulanmadı.
Başkent istatistikleri, dekorasyon görselleri ve bütün oyun kuralları tamamlanmadı.

KONTROLLER
Sol galeri menüsünden ekran seç. Üstteki oklarla 43 ekran arasında gez.
Geniş görünüm: galeri menüsünü gizler. Kırmızı × veya Esc: pencereyi kapatır.
Kartları seç, kategori sekmelerini kullan, isimle ara, bina seviyesini değiştir.
Ordu seçimi, bağış miktarı, kozmetik seçimi ve ayar anahtarları yerel örnektir.
Köy düzenleyicide oklar yalnızca örnek belediye binasını taşır; gerçek kayıt yok.

DOĞRULAMA
Chromium 154 ile 1600×1000 görünümde {len(routes)} ekran açıldı.
Bozuk yüklenmiş görsel: 0. Tarayıcı JavaScript istisnası: 0.
{len(checks['checks'])} etkileşim kontrolü geçti. Dar ekran mağazası 390×844 görünümde kontrol edildi.
Bu kontroller oyunun tamamlandığını veya Minecraft entegrasyonunun çalıştığını göstermez.
Ayrıntı: routes-verified.json ve interaction-checks.json.

KAYNAKLAR
ClashKingInc / ClashKingAssets: https://github.com/ClashKingInc/ClashKingAssets
Sabit commit: fdac291ae7fbc2901221ff945834be534d0344ae
287 gömülü görselin SHA-256 doğrulaması yapıldı; asset-sources.json içinde izlenebilir.
2 indirilemeyen görsel gömülmedi; önizleme bu dosyalara bağımlı değildir.
Depo lisansı CLASHKING-GPL-3.0.txt içinde. Varlık sahipliği ilgili hak sahiplerindedir.
Lilita One yazı tipi: Google Fonts, SIL Open Font License; LilitaOne-OFL.txt.
Bu bağımsız hayran önizlemesi Supercell tarafından onaylanmış veya desteklenmiş değildir.
Clash of Clans ve ilgili görseller ilgili hak sahiplerine aittir.

DÜZENLENEBİLİR KAYNAK
source/ altında HTML şablonu, CSS, JavaScript, kaynak varlıkları ve derleme aracı var.
Python 3 ile source dizininde: python tools/build_gui_preview.py ./cikti
Bu komut yalnızca çevrimdışı GUI HTML dosyasını üretir; sunucu JAR’ı üretmez.
'''
(out/'README.txt').write_text(readme)
source=out/'source'
source.mkdir(exist_ok=True)
shutil.copytree(root/'preview',source/'preview',dirs_exist_ok=True)
for path in ['tools/build_gui_preview.py','tools/gui_browser.mjs','tools/package_gui_preview.py','research/CLASHKING-LICENSE.txt','core/src/main/resources/catalog/catalog.json']:
    dest=source/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/path,dest)
status={'kind':'offline-html-design-preview','workingMinecraftGui':False,'completeGame':False,'pixelPerfectParityVerified':False,'screensRendered':len(routes),'interactionChecksPassed':len(checks['checks']),'browserExceptions':0,'imagesEmbedded':287,'officialPatchVerified':False}
(root/'research/gui-preview-status.json').write_text(json.dumps(status,indent=2)+'\n')
(out/'preview-status.json').write_text(json.dumps(status,indent=2)+'\n')
files=[p for p in out.rglob('*')if p.is_file()and p.name!='SHA256SUMS.txt']
(out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out))+'\n'for p in sorted(files)))
archive=out.parent/'KasabaClash-GUI.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for p in sorted(out.rglob('*')):
        if p.is_file():z.write(p,Path('KasabaClash-GUI')/p.relative_to(out))
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'screens':len(routes),'checks':len(checks['checks'])}))
