"""Deliver the current, explicitly incomplete project without runtime/account/cache files."""
from pathlib import Path
import hashlib
import json
import os
import tempfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = Path('/workspace/outputs/KasabaClash-Guncel-Dosyalar.zip')
PREVIEW = Path('/workspace/outputs/KasabaClash-GUI')
PREFIX = 'KasabaClash-Guncel-Dosyalar'
files = {}
digest = lambda value: hashlib.sha256(value).hexdigest()

def add(name, value):
    assert name not in files and not name.startswith('/') and '..' not in Path(name).parts, name
    if isinstance(value, Path):
        assert value.is_file() and not value.is_symlink(), value
    files[name] = value

status = json.loads((ROOT/'research/development-status.json').read_text())
pack_status = json.loads((ROOT/'research/resource-pack-status.json').read_text())
assert not status['release_eligible'] and status['complete_game'] == 'not complete'
server = ROOT/status['paper_adapter']['artifact']
resources = ROOT/pack_status['artifact']
assert digest(server.read_bytes()) == status['paper_adapter']['sha256']
assert digest(resources.read_bytes()) == pack_status['sha256']
assert pack_status['nativeMetadataCodecVerified'] and not pack_status['nativeGuiImplemented']

add('01-Sunucu/KasabaClash-Server-0.1.0-DEVELOPMENT.jar', server)
add('02-Kaynak-Paketi/KasabaClash-Resources-0.1.0-DEVELOPMENT.zip', resources)

excluded = {'target','dist','logs','__pycache__','.git','.idea','.pytest_cache'}
for base in ['core','client-common','server','preview','research','tools','validation']:
    for path in sorted((ROOT/base).rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(part in excluded for part in relative.parts):
            continue
        if relative.as_posix() == 'validation/native-before-restart.json':
            continue  # Ephemeral test connection nonce; not part of the delivered project.
        add('04-Kaynak-Kod/'+relative.as_posix(), path)
for path in sorted(ROOT.glob('*')):
    if path.is_file() and (path.suffix == '.md' or path.name == 'pom.xml'):
        add('04-Kaynak-Kod/'+path.name, path)

for path in sorted(PREVIEW.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(PREVIEW)
    if relative.parts[0] == 'source' or relative.name in {'SHA256SUMS.txt','README.txt'}:
        continue
    add('03-GUI-Onizleme/'+relative.as_posix(), path)
assert '03-GUI-Onizleme/KasabaClash-GUI.html' in files
assert '03-GUI-Onizleme/Galeri.html' in files
assert len([n for n in files if n.startswith('03-GUI-Onizleme/screenshots/') and n.endswith('.png')]) == 45

test_count = 0
for module in ['core','client-common']:
    for path in sorted((ROOT/module/'target/surefire-reports').glob('TEST-*.xml')):
        report = ET.parse(path).getroot()
        assert int(report.attrib['failures']) == 0 and int(report.attrib['errors']) == 0
        assert int(report.attrib['skipped']) == 0
        test_count += int(report.attrib['tests'])
        add('05-Test-Raporlari/Java/'+path.name, path)
assert test_count == 19
for name in ['current-build-summary.json','native-client-common.json','native-current-adapter.json','resource-pack-contents.json']:
    add('05-Test-Raporlari/'+name, ROOT/'validation'/name)
gui_checks = json.loads((PREVIEW/'interaction-checks.json').read_text())
assert len(gui_checks['checks']) == 26 and all(x['passed'] for x in gui_checks['checks'])

# Actual provided dependency used by the verified Maven build; never package player records.
auth = Path('/workspace/.m2/repository/tr/kasaba/kasaba-auth/1.4.0/kasaba-auth-1.4.0.jar')
with zipfile.ZipFile(auth) as z:
    assert 'tr/kasaba/auth/api/AuthState.class' in z.namelist()
    assert not any(n.endswith(('.db','.properties')) and 'account' in n.lower() for n in z.namelist())
add('04-Kaynak-Kod/build-dependencies/kasaba-auth-1.4.0.jar', auth)
add('04-Kaynak-Kod/build-dependencies/README.txt', '''Bu gerçek KasabaAuth 1.4.0 JAR'ı, Maven kaynak derlemesinin provided bağımlılığıdır.
Oyuncu hesabı veya ayar verisi içermez. Hazır sunucudaki KasabaAuth kurulumunu değiştirmez.
Maven için aşağıdaki komutla yerel depoya eklenebilir; bu dosya istemci modu değildir.
'''.encode())
add('04-Kaynak-Kod/DERLEME.txt', '''Kaynak kod derlemesi: Java 21 + Maven 3.9 gerekir.
Bu dizinde terminal aç. Önce mevcut gerçek provided bağımlılığı yerel Maven deposuna ekle:

mvn install:install-file -Dfile=build-dependencies/kasaba-auth-1.4.0.jar -DgroupId=tr.kasaba -DartifactId=kasaba-auth -Dversion=1.4.0 -Dpackaging=jar -DgeneratePom=true

Ardından:
mvn verify

Bu komut core, client-common ve server modüllerini derler. 19 Java testi vardır.
Paper API ve Maven bağımlılıkları için normal internet erişimi gerekir.
client-common bir kütüphanedir; Fabric modu olarak yüklenmez.

2B kaynak paketini yeniden üretmek için Python 3 ve tools/requirements-assets.txt içindeki Pillow gerekir:
python -m pip install -r tools/requirements-assets.txt
python tools/build_resource_pack.py
python tools/verify_pack_contents.py

tools/cloud-build-core.sh ve native test yardımcıları mevcut Codex çalışma ortamına özel yollar içerir.
tools/verify_pack_native.py ayrıca önbellekte gerçek Paper/Minecraft 1.21.10 runtime'ı gerektirir.
GUI önizlemesi için tools/build_gui_preview.py ./gui-cikti kullanılabilir.

Bu kaynakları derlemek, henüz uygulanmamış istemci GUI'sini, savaş motorunu veya bütün oyunu oluşturmaz.
'''.encode())
add('03-GUI-Onizleme/BURADAN-BASLA.txt', '''KasabaClash-GUI.html dosyasını tarayıcıda aç: 43 tasarım ekranını tıklayarak gezebilirsin.
Galeri.html: ekran görüntülerini topluca incele ve büyüt.
Genel-Gorunum.png: sekiz ana görünümün toplu görseli.
Bu HTML tasarımıdır; Minecraft'ta çalışan GUI değildir.
Düzenlenebilir kaynaklar ana paketin 04-Kaynak-Kod/preview dizininde.
'''.encode())
add('00-ONCE-OKU.txt', '''KASABA CLASH — ŞU ANA KADAR HAZIRLANAN DOSYALAR

DURUM: GELİŞTİRME ÇALIŞMASI. TAM OYNANABİLİR OYUN PAKETİ HENÜZ YOK.

Bu ZIP, şu ana kadar hazırlanan gerçek kaynakları ve çıktıları bir araya getirir.
Minecraft içinde gösterilen 43 GUI'yi açan Fabric istemci modu henüz uygulanmadı.
Tam savaş sistemi, 3B binalar/animasyonlar ve eksiksiz Klan Başkenti oyunu tamamlanmadı.

İÇİNDEKİLER
01-Sunucu: gerçek Paper 1.21.10 / Java 21 geliştirme adaptörü JAR'ı.
02-Kaynak-Paketi: 287 PNG görsel, düz item modeli, font ve menü manifesti içeren 2B kaynak paketi.
03-GUI-Onizleme: tarayıcıda açılan 43 ekranlık HTML tasarımı, galeri ve 45 PNG görüntüsü.
04-Kaynak-Kod: core, client-common, server kaynakları, testler, veri kataloğu, görseller ve yardımcılar.
05-Test-Raporlari: 19 Java testi, güncel JAR için 10 Paper protokol kontrolü ve kaynak paketi kontrolleri.

SUNUCU JAR'I HAKKINDA
KasabaAuth servisi gerekir; mevcut KasabaAuth 1.4.2 ile doğrulandı.
JAR kalıcı köy, bina yerleştirme/geliştirme/taşıma ve bağlantı kontrolü içerir.
Varsayılan geliştirme bağlantısı kapalıdır. /clash mevcut geliştirme durumunu bildirir.
Bu JAR'ı yüklemek özel GUI'yi veya tamamlanmış oyunu açmaz.
client-common istemci modülü kaynak kütüphanesidir; mods klasörüne kurulacak Fabric modu değildir.

KAYNAK PAKETİ HAKKINDA
Minecraft 1.21.10 kaynak biçimi 69.0, gerçek Minecraft metadata codec'iyle doğrulandı.
Paket tek başına oyun/menü açmaz. Modeller düz görsellerdir; 3B oyun binaları değildir.
Gerçek Minecraft istemcisinde görsel yükleme testi henüz yapılamadı.

TESTLERİN KAPSAMI
19 Java testi geçti. Güncel adaptör için 10 gerçek Paper protokol kontrolü geçti.
Önceki adaptörün 12+8 kontrolleri kaynaklarda ayrı tarihsel kanıttır; güncel JAR'a aitmiş gibi sunulmaz.
HTML tasarımında 43 ekran / 26 etkileşim kontrolü geçti. Bunlar native Minecraft GUI testi değildir.
Kaynak varlık hashleri, PNG pikselleri, model/font bağlantıları ve ZIP bütünlüğü kontrol edildi.

EKSİKLER / DERLEME ENGELİ
Resmi Fabric/Mojang SDK indirmesi son kontrolde HTTP 403 ile engelliydi.
Ağın açılması yalnız SDK çalışmasını mümkün kılar; eksik oyun sistemlerini kendiliğinden tamamlamaz.
Mevcut durumun ayrıntıları PAKET-DURUMU.json ve 04-Kaynak-Kod/research/development-status.json içinde.

LİSANSLAR
Görseller ClashKingInc/ClashKingAssets kaynağından; lisans ve kaynak izleri pakette.
Lilita One SIL Open Font License kapsamındadır.
Bu bağımsız çalışma Supercell tarafından onaylanmış veya desteklenmiş değildir.

Gerçek oyuncu hesapları, canlı veritabanları, ortam kimlik bilgileri ve test oturumları bu ZIP'e alınmadı.
'''.encode())
manifest = {
    'kind':'current-incomplete-project-bundle',
    'completeGame':False,'readyForGameplay':False,'fabricModIncluded':False,'nativeMinecraftGui':False,
    'serverJar':{'path':'01-Sunucu/'+server.name,'sha256':digest(server.read_bytes()),'type':'development-adapter'},
    'resources':{'path':'02-Kaynak-Paketi/'+resources.name,'sha256':digest(resources.read_bytes()),'textures':287,'models3D':False},
    'sourceIncluded':True,'guiDesignScreens':43,'guiDesignInteractionChecks':26,'javaTests':test_count,'currentPaperProtocolChecks':10,
    'buildDependency':{'artifact':'tr.kasaba:kasaba-auth:1.4.0','sha256':digest(auth.read_bytes()),'scope':'build-only provided dependency'},
}
add('PAKET-DURUMU.json',(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())

hashes=[]
for name,value in sorted(files.items()):
    raw=value.read_bytes() if isinstance(value,Path) else value
    hashes.append(digest(raw)+'  '+name+'\n')
add('SHA256SUMS.txt',''.join(hashes).encode())

OUTPUT.parent.mkdir(parents=True,exist_ok=True)
handle,temporary=tempfile.mkstemp(prefix='clash-current-',suffix='.zip',dir=OUTPUT.parent)
os.close(handle)
try:
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,value in sorted(files.items()):
            info=zipfile.ZipInfo(PREFIX+'/'+name,date_time=(2026,11,6,0,0,0))
            info.compress_type=zipfile.ZIP_STORED if name.endswith(('.zip','.jar','.png','.webp','.ttf')) else zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            z.writestr(info,value.read_bytes() if isinstance(value,Path) else value)
    with zipfile.ZipFile(temporary) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(files)
        for line in z.read(PREFIX+'/SHA256SUMS.txt').decode().splitlines():
            expected,name=line.split('  ',1)
            assert digest(z.read(PREFIX+'/'+name))==expected,name
        with zipfile.ZipFile(Path(server)) as jar:
            assert 'plugin.yml' in jar.namelist() and 'tr/kasaba/clash/server/ClashPlugin.class' in jar.namelist()
        assert z.read(PREFIX+'/01-Sunucu/'+server.name)==server.read_bytes()
        assert z.read(PREFIX+'/02-Kaynak-Paketi/'+resources.name)==resources.read_bytes()
        assert not any('/target/'in n or '/logs/'in n or n.endswith(('.db','.db-wal','.db-shm','native-before-restart.json'))for n in z.namelist())
    Path(temporary).replace(OUTPUT)
finally:
    Path(temporary).unlink(missing_ok=True)
checksum=digest(OUTPUT.read_bytes())
OUTPUT.with_suffix('.sha256.txt').write_text(checksum+'  '+OUTPUT.name+'\n')
print(json.dumps({'path':str(OUTPUT),'bytes':OUTPUT.stat().st_size,'files':len(files),'sha256':checksum,'zipIntegrity':'passed','completeGame':False},ensure_ascii=False))
