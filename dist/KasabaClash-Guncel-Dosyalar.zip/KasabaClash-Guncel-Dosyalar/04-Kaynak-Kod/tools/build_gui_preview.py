"""Build an offline GUI design review, never a playable game distribution."""
from pathlib import Path
import base64
import hashlib
import json
import mimetypes
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
PREVIEW = ROOT / 'preview'
OUTPUT = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT / 'dist' / 'gui-preview'
OUTPUT.mkdir(parents=True, exist_ok=True)
sources = json.loads((PREVIEW / 'asset-sources.json').read_text())
assets = {}
for row in sources['files']:
    if 'error' in row:
        continue
    path = PREVIEW / 'assets' / row['path']
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
    assets[row['path']] = 'data:' + (mimetypes.guess_type(path.name)[0] or 'application/octet-stream') + ';base64,' + base64.b64encode(raw).decode()
font = base64.b64encode((PREVIEW / 'assets/fonts/LilitaOne-Regular.ttf').read_bytes()).decode()
catalog = json.loads((ROOT / 'core/src/main/resources/catalog/catalog.json').read_text())
template = (PREVIEW / 'index.template.html').read_text()
safe_json = lambda value: json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
html = template.replace('/*__STYLE__*/', (PREVIEW / 'style.css').read_text().replace('__FONT__', font))
html = html.replace('/*__DATA__*/', 'const ASSETS=' + safe_json(assets) + '; const CATALOG=' + safe_json(catalog) + ';')
html = html.replace('/*__APP__*/', (PREVIEW / 'app.js').read_text())
assert '/*__' not in html
target = OUTPUT / 'KasabaClash-GUI.html'
target.write_text(html)
shutil.copyfile(ROOT / 'research/CLASHKING-LICENSE.txt', OUTPUT / 'CLASHKING-GPL-3.0.txt')
shutil.copyfile(PREVIEW / 'assets/fonts/OFL-LilitaOne.txt', OUTPUT / 'LilitaOne-OFL.txt')
shutil.copyfile(PREVIEW / 'asset-sources.json', OUTPUT / 'asset-sources.json')
print(json.dumps({'html': str(target), 'bytes': target.stat().st_size, 'embedded_assets': len(assets), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
