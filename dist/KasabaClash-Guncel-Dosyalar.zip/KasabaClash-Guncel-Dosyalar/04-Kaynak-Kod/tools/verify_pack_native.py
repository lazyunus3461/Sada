"""Decode generated pack.mcmeta with the actual cached Minecraft 1.21.10 codec."""
from pathlib import Path
import subprocess,zipfile,json
ROOT=Path(__file__).resolve().parents[1]
runtime=Path('/workspace/kasaba-test-server')
work=Path('/workspace/scratch/clash-pack-native');work.mkdir(parents=True,exist_ok=True)
java=Path('/workspace/jdk-21.0.9+10/bin')
cp=':'.join(str(p)for p in [runtime/'versions/1.21.10/paper-1.21.10.jar',*sorted((runtime/'libraries').rglob('*.jar'))])
source='''import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import java.nio.file.*;
import net.minecraft.SharedConstants;
import net.minecraft.server.packs.metadata.pack.PackMetadataSection;
public class CheckPack {
 public static void main(String[] args) throws Exception {
  SharedConstants.tryDetectVersion();
  net.minecraft.server.Bootstrap.bootStrap();
  var raw=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject().get("pack");
  var result=PackMetadataSection.CLIENT_TYPE.codec().parse(JsonOps.INSTANCE,raw).getOrThrow();
  if(SharedConstants.RESOURCE_PACK_FORMAT_MAJOR!=69||SharedConstants.RESOURCE_PACK_FORMAT_MINOR!=0)throw new AssertionError("Wrong runtime");
  var min=result.supportedFormats().minInclusive();var max=result.supportedFormats().maxInclusive();
  if(min.major()!=69||min.minor()!=0||max.major()!=69||max.minor()!=0)throw new AssertionError("Wrong supported format range");
  var proof=new JsonObject();proof.addProperty("nativeMetadataCodecVerified",true);
  proof.addProperty("min",min.toString());proof.addProperty("max",max.toString());
  Files.writeString(Path.of(args[1]),proof.toString());
 }
}'''
(work/'CheckPack.java').write_text(source)
with zipfile.ZipFile(ROOT/'dist/KasabaClash-Resources-0.1.0-DEVELOPMENT.zip')as z:
 (work/'pack.mcmeta').write_bytes(z.read('pack.mcmeta'))
subprocess.run([str(java/'javac'),'-cp',cp,'-d',str(work),str(work/'CheckPack.java')],check=True)
proof=work/'result.json';proof.unlink(missing_ok=True)
result=subprocess.run([str(java/'java'),'-cp',str(work)+':'+cp,'CheckPack',str(work/'pack.mcmeta'),str(proof)],text=True,capture_output=True)
if result.returncode:
 print(result.stdout[-4000:]);print(result.stderr[-4000:]);raise SystemExit(result.returncode)
verified=json.loads(proof.read_text());assert verified=={'nativeMetadataCodecVerified':True,'min':'69.0','max':'69.0'}
print(json.dumps(verified))
status_path=ROOT/'research/resource-pack-status.json'
status=json.loads(status_path.read_text());status['nativeMetadataCodecVerified']=True;status['nativeClientLoadingTested']=False
status_path.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
