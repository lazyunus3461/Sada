import fs from 'node:fs/promises';
const output='/workspace/outputs/KasabaClash-GUI';
const origin='http://127.0.0.1:9238';
const tabs=await (await fetch(origin+'/json/list')).json();
const page=tabs.find(x=>x.type==='page');
const socket=new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
let counter=0;const pending=new Map(),errors=[];
socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails);};
const cdp=(method,params={})=>new Promise((resolve,reject)=>{const id=++counter;const timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},20000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});
const evaluate=async expression=>{const r=await cdp('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const ready=()=>evaluate(`(async()=>{await document.fonts.ready;await Promise.all([...document.images].filter(i=>i.getAttribute('src')&&(i.loading!=='lazy'||i.complete)).map(i=>i.decode().catch(()=>{})));await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return document.title})()`);
await cdp('Runtime.enable');await cdp('Page.enable');await cdp('Network.enable');await cdp('Network.setCacheDisabled',{cacheDisabled:true});
await cdp('Emulation.setDeviceMetricsOverride',{width:1600,height:1000,deviceScaleFactor:1,mobile:false});
const mode=process.argv[2]||'initial';
await cdp('Page.navigate',{url:'http://127.0.0.1:8778/KasabaClash-GUI.html?review='+Date.now()+'#home'});await wait(500);await ready();
async function shot(name){await ready();const r=await cdp('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});await fs.mkdir(output+'/screenshots',{recursive:true});await fs.writeFile(output+'/screenshots/'+name+'.png',Buffer.from(r.data,'base64'));}
if(mode==='initial'){await shot('01-home');console.log(await evaluate(`JSON.stringify({title:document.title,images:document.images.length,broken:[...document.images].filter(i=>!i.naturalWidth).length,routes:__preview.routes.length,bodyWidth:document.body.scrollWidth,viewport:innerWidth})`));}
if(mode==='all'){
 const results=[];const routes=await evaluate('__preview.routes');
 for(let i=0;i<routes.length;i++){
  const [id,title]=routes[i];
  await evaluate(`__preview.state.region=${JSON.stringify(['builder'].includes(id)?'builder':['capital','districts','district','capital-donate','raid'].includes(id)?'capital':'home')};__preview.navigate(${JSON.stringify(id)});`);
  await wait(40);await ready();
  const metrics=await evaluate(`({title:document.title,route:__preview.state.route,broken:[...document.images].filter(i=>!i.naturalWidth).map(i=>i.alt),pageOverflow:document.body.scrollWidth>innerWidth,content:document.querySelector('#view').textContent.length,buttons:document.querySelectorAll('#view button').length})`);
  if(metrics.route!==id||metrics.broken.length||metrics.pageOverflow||metrics.content<15)throw Error('Bad route '+id+' '+JSON.stringify(metrics));
  const file=String(i+1).padStart(2,'0')+'-'+id;await shot(file);results.push({...metrics,id,title,file:'screenshots/'+file+'.png'});
 }
 await fs.writeFile(output+'/routes-verified.json',JSON.stringify({screens:results,exceptions:errors},null,2));
 console.log(JSON.stringify({screens:results.length,exceptions:errors.length,buttons:results.reduce((n,x)=>n+x.buttons,0)}));
}
if(mode==='test'){
 const checks=[];const assert=(ok,name)=>{checks.push({name,passed:!!ok});if(!ok)throw Error(name);};
 const nav=async id=>{await evaluate(`__preview.navigate(${JSON.stringify(id)})`);await wait(50);await ready();};
 const click=async selector=>{await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)throw Error('missing '+${JSON.stringify(selector)});e.click()})()`);await wait(40);await ready();};
 await nav('shop');await click('[data-tab="Resource"]');assert(await evaluate(`document.querySelectorAll('#catalog-grid .card').length>0`),'Resource shop tab has cards');
 await click('[data-tab="Defense"]');assert(await evaluate(`document.querySelectorAll('#catalog-grid .card').length>0`),'Defense shop tab has cards');
 await evaluate(`(()=>{const e=document.querySelector('#catalog-search');e.value='Top';e.dispatchEvent(new Event('input',{bubbles:true}))})()`);assert(await evaluate(`document.querySelector('#catalog-count').textContent!=='0 kart'`),'Turkish catalog search');
 await evaluate(`(()=>{const e=document.querySelector('#catalog-search');e.value='xxyyz';e.dispatchEvent(new Event('input',{bubbles:true}))})()`);assert(await evaluate(`!document.querySelector('#no-results').hidden`),'Empty search message');
 await evaluate(`__preview.state.building=CATALOG.items.find(x=>x.name==='Town Hall'&&x.family==='buildings');__preview.state.level=12;`);await nav('building');
 await evaluate(`(()=>{const e=document.querySelector('#building-level');e.value='18';e.dispatchEvent(new Event('change',{bubbles:true}))})()`);await ready();assert(await evaluate(`__preview.state.level===18&&document.querySelector('.feature-art img').src===ASSETS['buildings/home-village/town_hall/level_18.webp']`),'Town Hall 18 uses its correct source image');
 await evaluate('__preview.state.level=12');await nav('upgrade');await click('[data-action="upgrade-confirm"]');assert(await evaluate(`!!document.querySelector('[role="dialog"]')`),'Upgrade confirmation opens');
 await shot('44-upgrade-confirmation');await click('[data-action="confirm-local"]');assert(await evaluate(`!document.querySelector('[role="dialog"]')&&document.querySelector('#toast').textContent.includes('oyun kaydı değişmedi')`),'Confirmation cannot pretend to execute an upgrade');
 await nav('train');const before=await evaluate(`__preview.state.army.Barbarian||0`);await click('[data-action="add-unit"][data-item-key="troops/4000000"]');assert(await evaluate(`__preview.state.army.Barbarian===${before+1}`),'Army card increments local sample selection');
 await click('[data-action="remove-unit"][data-unit="Barbarian"]');assert(await evaluate(`__preview.state.army.Barbarian===${before}`),'Army tray decrements sample selection');
 await nav('heroes');await click('[data-item="heroes/28000001"]');assert(await evaluate(`__preview.state.route==='hero'`),'Hero card opens its own detail');
 await nav('equipment');await click('.card');assert(await evaluate(`__preview.state.route==='equipment-detail'`),'Equipment card opens detail');
 await nav('pets');await click('.card');assert(await evaluate(`__preview.state.route==='pet-detail'`),'Pet card opens detail');await click('[data-action="pair-pet"]');assert(await evaluate(`document.querySelector('#toast').textContent.includes('örnek eşleştirme')`),'Pet pairing identifies sample status');
 await nav('skins');await click('.card');await click('[data-action="confirm-skin"]');assert(await evaluate(`!!__preview.state.selectedSkin&&document.querySelector('.selected-info').textContent.includes(__preview.state.selectedSkin.displayName)`),'Skin preview selected badge updates');
 await nav('sceneries');await click('.card');await click('[data-action="confirm-scenery"]');assert(await evaluate(`!!__preview.state.selectedScenery`),'Scenery thumbnail selection works');
 await nav('capital-donate');await click('[data-action="capital-contribute"]');await evaluate(`document.querySelector('#donate-amount').value='20000'`);await click('[data-action="confirm-capital"]');assert(await evaluate(`!!document.querySelector('.dialog')`),'Invalid contribution rejected');await evaluate(`document.querySelector('#donate-amount').value='1000'`);await click('[data-action="confirm-capital"]');assert(await evaluate(`!document.querySelector('.dialog')`),'Valid sample contribution closes confirmation');
 await nav('settings');await click('[role="switch"]');assert(await evaluate(`document.querySelector('[role="switch"]').getAttribute('aria-checked')==='false'`),'Settings toggle reports accessible state');
 await nav('editor');await click('[data-action="move-right"]');assert(await evaluate(`__preview.state.editorOffset.x===20`),'Editor moves selected sample building');await click('[data-action="editor-reset"]');assert(await evaluate(`__preview.state.editorOffset.x===0`),'Editor reset works');
 await nav('districts');await click('[data-district="2"]');assert(await evaluate(`__preview.state.route==='district'&&__preview.state.district===2`),'District selection preserves selected district');
 await nav('connection');await click('[data-action="credits"]');assert(await evaluate(`document.querySelector('.dialog').textContent.includes('oynanabilir oyun değildir')`),'Scope dialog plainly identifies incomplete game');await click('[data-action="close-dialog"]');
 await nav('home');await click('#next-screen');assert(await evaluate(`__preview.state.route==='builder'`),'Next-screen navigation');await click('#prev-screen');assert(await evaluate(`__preview.state.route==='home'`),'Previous-screen navigation');
 await cdp('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:false});await nav('shop');assert(await evaluate(`document.body.scrollWidth<=innerWidth`),'Mobile viewport has no page horizontal overflow');await shot('45-mobile-shop');
 await cdp('Emulation.setDeviceMetricsOverride',{width:1600,height:1000,deviceScaleFactor:1,mobile:false});await nav('home');
 assert(errors.length===0,'No browser JavaScript exceptions');
 await fs.writeFile(output+'/interaction-checks.json',JSON.stringify({checks,exceptions:errors},null,2));console.log(JSON.stringify({passed:checks.length,exceptions:errors.length}));
}
if(mode==='gallery'){
 await cdp('Page.navigate',{url:'http://127.0.0.1:8778/Genel-Gorunum.html'});await wait(300);await ready();
 const size=await evaluate('({width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight})');
 const r=await cdp('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:size.width,height:size.height,scale:1}});
 await fs.writeFile(output+'/Genel-Gorunum.png',Buffer.from(r.data,'base64'));
 await cdp('Page.navigate',{url:'http://127.0.0.1:8778/Galeri.html'});await wait(200);await evaluate(`document.querySelectorAll('img[loading]').forEach(i=>i.loading='eager')`);await ready();
 const gallery=await evaluate(`({cards:document.querySelectorAll('.card').length,missing:[...document.images].filter(i=>i.getAttribute('src')&&i.complete&&!i.naturalWidth).length})`);
 if(gallery.cards!==43||gallery.missing)throw Error('Gallery invalid '+JSON.stringify(gallery));
 await evaluate(`document.querySelector('.card').click()`);await ready();
 if(!await evaluate(`document.querySelector('.dialog').classList.contains('open')&&document.querySelector('.dialog img').naturalWidth>0`))throw Error('Gallery lightbox invalid');
 console.log(JSON.stringify({overview:size,gallery,lightbox:true}));
}
socket.close();
