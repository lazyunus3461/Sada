"""Build verified 2D Minecraft assets. This does not create the missing 3D game or client mod."""
from pathlib import Path
from io import BytesIO
import ast, hashlib, json, re, shutil, tempfile, zipfile
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist'
OUT.mkdir(exist_ok=True)
NAMESPACE = 'kasabaclash'
sha = lambda b: hashlib.sha256(b).hexdigest()
encode = lambda x: (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
sources = json.loads((ROOT/'preview/asset-sources.json').read_text())
catalog = json.loads((ROOT/'core/src/main/resources/catalog/catalog.json').read_text())
route_source=(ROOT/'preview/app.js').read_text().split('const ROUTES = ',1)[1].split('];',1)[0]+']'
routes=ast.literal_eval(route_source)
assert len(routes)==43 and len({r[0]for r in routes})==43
state_routes={'home','builder','editor','building','upgrade','builders','shop','profile','connection'}
catalog_routes={'army','train','spells','lab','heroes','hero','equipment','equipment-detail','pets','pet-detail','skins','sceneries'}
screens={'schema':1,'nativeMinecraftGuiImplemented':False,'completeGame':False,'screens':[
 {'id':r[0],'title':r[1],'group':r[2],'mode':'server_state'if r[0]in state_routes else'catalog_read_only'if r[0]in catalog_routes else'design_only'}for r in routes]}
payload={};indexed=[];used=set();translations={}
for row in sources['files']:
 if 'error'in row:continue
 source=ROOT/'preview/assets'/row['path'];raw=source.read_bytes()
 assert sha(raw)==row['sha256'],f'Source changed: {source}'
 clean=re.sub('[^a-z0-9_./-]','_',str(Path(row['path']).with_suffix('')).lower())
 assert clean not in used,f'Resource identifier collision: {clean}'
 used.add(clean)
 with Image.open(BytesIO(raw))as im:
  rgba=im.convert('RGBA');buf=BytesIO();rgba.save(buf,format='PNG');png=buf.getvalue()
  with Image.open(BytesIO(png))as converted:
   assert converted.mode=='RGBA'and converted.size==rgba.size and converted.tobytes()==rgba.tobytes()
  width,height=rgba.size
 texture=f'assets/{NAMESPACE}/textures/gui/{clean}.png';payload[texture]=png
 model_id=f'{NAMESPACE}:{clean}'
 payload[f'assets/{NAMESPACE}/models/item/{clean}.json']=encode({'parent':'minecraft:item/generated','textures':{'layer0':f'{NAMESPACE}:gui/{clean}'}})
 payload[f'assets/{NAMESPACE}/items/{clean}.json']=encode({'model':{'type':'minecraft:model','model':f'{NAMESPACE}:item/{clean}'}})
 title=Path(row['path']).parent.name.replace('_',' ').title()if Path(row['path']).stem in ['icon','thumbnail']else Path(row['path']).stem.replace('_',' ').title()
 translations['item.'+NAMESPACE+'.'+clean.replace('/','.')]=title
 indexed.append({'source':row['path'],'sourceSha256':row['sha256'],'texture':f'{NAMESPACE}:textures/gui/{clean}.png','itemModel':model_id,'pngSha256':sha(png),'width':width,'height':height,'modelKind':'flat_generated_item'})
assert len(indexed)==287
payload['pack.mcmeta']=encode({'pack':{'pack_format':69,'min_format':[69,0],'max_format':[69,0],'description':'KasabaClash geliştirme varlıkları · 2B GUI · tam oyun değildir'}})
pack_icon=next(x for x in indexed if x['source']=='buildings/home-village/town_hall/level_12.webp')
payload['pack.png']=payload['assets/'+NAMESPACE+'/'+pack_icon['texture'].split(':',1)[1]]
payload[f'assets/{NAMESPACE}/font/lilita.ttf']=(ROOT/'preview/assets/fonts/LilitaOne-Regular.ttf').read_bytes()
payload[f'assets/{NAMESPACE}/font/title.json']=encode({'providers':[{'type':'ttf','file':f'{NAMESPACE}:lilita.ttf','shift':[0,0],'size':21,'oversample':2}]})
payload[f'assets/{NAMESPACE}/lang/tr_tr.json']=encode(translations)
payload[f'assets/{NAMESPACE}/clash/asset-index.json']=encode({'schema':1,'upstreamCommit':sources['upstream_commit'],'assets':indexed})
payload[f'assets/{NAMESPACE}/clash/catalog.json']=(ROOT/'core/src/main/resources/catalog/catalog.json').read_bytes()
payload[f'assets/{NAMESPACE}/clash/screens.json']=encode(screens)
payload['LICENSES/ClashKing-GPL-3.0.txt']=(ROOT/'research/CLASHKING-LICENSE.txt').read_bytes()
payload['LICENSES/LilitaOne-OFL.txt']=(ROOT/'preview/assets/fonts/OFL-LilitaOne.txt').read_bytes()
payload['README.txt']=('''KASABA CLASH — 2B KAYNAK VARLIKLARI
Minecraft Java 1.21.10 için kaynak paketi biçimi 69.0.
287 görselin orijinal SHA-256 değeri kontrol edildi, PNG dönüşümünde RGBA pikselleri karşılaştırıldı.
Kaynak: https://github.com/ClashKingInc/ClashKingAssets
Sabit commit: fdac291ae7fbc2901221ff945834be534d0344ae
Lilita One: SIL Open Font License. İlgili lisanslar LICENSES dizininde.
Bu kaynak paketi tek başına özel ekran açmaz ve oyun kurmaz. Native Minecraft GUI henüz yok.
Item modelleri düz görsel modelleridir; 3B binalar, animasyonlu birlikler ve tam kozmetik değildir.
43 ekranın menü manifesti ve içerik kataloğu istemci bağlaması için gömülüdür.
Varsayılan Minecraft dokuları, itemleri, yazı tipi ve ekranlar değiştirilmez.
Bu bağımsız çalışma Supercell tarafından onaylanmış veya desteklenmiş değildir.
''').encode()
payload['SHA256SUMS.txt']=''.join(sha(data)+'  '+path+'\n'for path,data in sorted(payload.items())).encode()
destination=OUT/'KasabaClash-Resources-0.1.0-DEVELOPMENT.zip'
with tempfile.NamedTemporaryFile(dir=OUT,suffix='.zip',delete=False)as temporary:
 temp=Path(temporary.name)
try:
 with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for path,data in sorted(payload.items()):
   info=zipfile.ZipInfo(path,date_time=(2020,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,data)
 with zipfile.ZipFile(temp)as z:
  assert z.testzip()is None
  assert len(z.namelist())==len(payload)
 temp.replace(destination)
finally:
 if temp.exists():temp.unlink()
client_resources=ROOT/'client-common/src/main/resources/gui'
client_resources.mkdir(parents=True,exist_ok=True)
(client_resources/'screens.json').write_bytes(encode(screens))
(client_resources/'asset-index.json').write_bytes(encode({'schema':1,'upstreamCommit':sources['upstream_commit'],'assets':indexed}))
status={'artifact':str(destination.relative_to(ROOT)),'sha256':sha(destination.read_bytes()),'resourcePackFormat':[69,0],'textures':len(indexed),'sourceHashesVerified':True,'pngPixelsVerified':True,'screens':len(routes),'nativeClientLoadingTested':False,'nativeGuiImplemented':False,'models3D':False,'completeGame':False}
(ROOT/'research/resource-pack-status.json').write_bytes(encode(status))
print(json.dumps(status))
