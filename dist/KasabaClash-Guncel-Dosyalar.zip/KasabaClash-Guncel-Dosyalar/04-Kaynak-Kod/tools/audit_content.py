#!/usr/bin/env python3
"""Audit the pinned upstream snapshot; this never labels a catalog as a finished game."""
from pathlib import Path
from collections import Counter
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
research=ROOT/'research'
manifest_path=research/'asset-manifest.json'
manifest=json.loads(manifest_path.read_text())
sources=json.loads((research/'sources.json').read_text())
for source in sources:
 if 'error'in source:raise RuntimeError(source)
 data=(research/source['path']).read_bytes()
 if hashlib.sha256(data).hexdigest()!=source['sha256']:raise RuntimeError('Changed source: '+source['path'])
summary={}
all_fields={}
for path in sorted((research/'static_data').glob('*.json')):
 rows=json.loads(path.read_text())['items']
 ids=[r['_id']for r in rows if '_id'in r]
 if len(set(ids))!=len(ids):raise RuntimeError('Duplicate catalog IDs: '+path.name)
 summary[path.stem]={'entries':len(rows),'entries_with_id':len(ids),'levels':sum(len(r.get('levels',[]))for r in rows),'villages':dict(Counter(r.get('village',r.get('type','unspecified'))for r in rows))}
 all_fields[path.stem]=sorted({k for r in rows for k in r})
buildings=json.loads((research/'static_data/buildings.json').read_text())['items']
halls={r['name']:max(x['level']for x in r['levels'])for r in buildings if r['name']in {'Town Hall','Builder Hall','Capital Hall','District Hall'}}
asset_counts={k:len(v)for k,v in manifest['assets'].items()}
levels=[l for b in buildings for l in b.get('levels',[])]
fields={k for level in levels for k in level}
report={
 'snapshot_date':'2026-11-06 Europe/Istanbul',
 'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
 'verified_files':len(sources), 'catalog':summary,'hall_levels_present':halls,'assets':asset_counts,
 'source_is_official':False,'official_latest_patch_verified':False,
 'evidence_limits':{
  'capital_building_statistics_present':any(b.get('village')in {'capital','clanCapital'}for b in buildings),
  'production_rates_in_building_levels':any(k in fields for k in ['production_rate','production_per_hour','resource_per_hour']),
  'storage_capacity_in_building_levels':any(k in fields for k in ['storage_capacity','resource_capacity','gold_capacity']),
  'complete_gui_assets_in_manifest':any(k in asset_counts for k in ['gui','menus','interface']),
  'three_dimensional_character_models_in_manifest':any(r['path'].endswith(('.gltf','.glb','.obj','.fbx'))for rows in manifest['assets'].values()for r in rows),
 },
 'implemented_kernel':['catalog loader','transactional village persistence','construction queue','footprint and builder checks','hall unlock limits','bounded message framing'],
 'implemented_playable_game':False, 'production_release_eligible':False,
 'client_mod_approved':True, 'pending_user_decision':None,
 'environment_blocker':'Official Fabric/Mojang download endpoints returned HTTP 403. Required domains were added to a saved draft; publication and a successful retry are still required.',
 'release_blockers':[
  'No playable integrated plugin, client renderer or battle engine has been completed yet.',
  'The requested complete Clan Capital rules/statistics are absent from this snapshot.',
  'The asset list contains images/icons, not a complete set of GUI screens or animated 3D character models.',
  'Exact production/storage/army capacities need independently verified data. Hall unlock quantity tables were found and implemented separately.',
  'A resource pack and server plugin alone do not provide an identical mobile-game interface and control model.',
  'The official latest patch could not be checked because the official domain is blocked in this environment.',
 ]
}
(research/'coverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verified_files':len(sources),'hall_levels':halls,'building_entries':summary['buildings']['entries'],'building_levels':summary['buildings']['levels'],'troop_entries':summary['troops']['entries'],'troop_levels':summary['troops']['levels'],'release_eligible':False},ensure_ascii=False))
