from pathlib import Path
import hashlib,json,zipfile
from PIL import Image
from io import BytesIO
root=Path(__file__).resolve().parents[1]
path=root/'dist/KasabaClash-Resources-0.1.0-DEVELOPMENT.zip'
with zipfile.ZipFile(path)as z:
 names=set(z.namelist());assert len(names)==len(z.namelist())
 for name in names:assert not name.startswith('/')and'..'not in Path(name).parts
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 index=json.loads(z.read('assets/kasabaclash/clash/asset-index.json'))
 for item in index['assets']:
  namespace,texture=item['texture'].split(':',1);assert namespace=='kasabaclash'
  raw=z.read('assets/'+namespace+'/'+texture)
  assert hashlib.sha256(raw).hexdigest()==item['pngSha256']
  with Image.open(BytesIO(raw))as im:assert im.size==(item['width'],item['height'])and im.mode=='RGBA'
  namespace,model=item['itemModel'].split(':',1)
  definition=json.loads(z.read(f'assets/{namespace}/items/{model}.json'))
  assert definition['model']['type']=='minecraft:model'
  target=definition['model']['model'].split(':',1)[1]
  legacy=json.loads(z.read(f'assets/{namespace}/models/{target}.json'))
  assert legacy['parent']=='minecraft:item/generated'
  layer=legacy['textures']['layer0'].split(':',1)[1]
  assert 'assets/kasabaclash/textures/'+layer+'.png'in names
 font=json.loads(z.read('assets/kasabaclash/font/title.json'))
 assert font['providers'][0]['file']=='kasabaclash:lilita.ttf'
 assert 'assets/kasabaclash/font/lilita.ttf'in names
 screens=json.loads(z.read('assets/kasabaclash/clash/screens.json'))
 assert len(screens['screens'])==43 and not screens['nativeMinecraftGuiImplemented']
 assert not any(name.startswith('assets/minecraft/')for name in names)
report={'sourceIntegrity':True,'pngTextureLinks':len(index['assets']),'itemModelLinks':len(index['assets']),'fontLink':True,'screenDefinitions':43,'vanillaOverrides':0,'nativeClientRenderingTested':False}
(root/'validation/resource-pack-contents.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
