"""Isolated local server fixture; never copies account data or alters another server."""
from pathlib import Path
import json,shutil,hashlib,uuid
root=Path(__file__).resolve().parents[1]
target=Path('/workspace/scratch/clash-native-20261106')
assert not target.exists(), 'Keep existing fixture data; choose a new directory for a fresh run.'
target.mkdir(parents=True)
base=Path('/workspace/kasaba-test-server')
for name in ['paper.jar','eula.txt']:
 shutil.copyfile(base/name,target/name)
for name in ['libraries','versions','cache']:
 if (base/name).exists():shutil.copytree(base/name,target/name)
(target/'plugins/KasabaClash').mkdir(parents=True)
shutil.copyfile('/workspace/Sada/target/KasabaAuth-1.4.2.jar',target/'plugins/KasabaAuth.jar')
shutil.copyfile(root/'server/target/KasabaClash-Server-0.1.0-DEVELOPMENT.jar',target/'plugins/KasabaClash.jar')
config=(root/'server/src/main/resources/config.yml').read_text().replace('development-connection-enabled: false','development-connection-enabled: true')
(target/'plugins/KasabaClash/config.yml').write_text(config)
(target/'server.properties').write_text('''server-ip=127.0.0.1
server-port=25616
online-mode=false
enforce-secure-profile=false
motd=Isolated Clash adapter verification
level-name=clash_test
level-type=minecraft:flat
generate-structures=false
view-distance=2
simulation-distance=2
spawn-protection=0
spawn-monsters=false
spawn-animals=false
max-players=4
network-compression-threshold=-1
enable-rcon=false
sync-chunk-writes=false
''')
def offline(name):
 raw=bytearray(hashlib.md5(('OfflinePlayer:'+name).encode()).digest());raw[6]=(raw[6]&15)|48;raw[8]=(raw[8]&63)|128
 return str(uuid.UUID(bytes=bytes(raw)))
(target/'ops.json').write_text(json.dumps([{'uuid':offline('CLJ1'),'name':'CLJ1','level':4,'bypassesPlayerLimit':False}]))
print(target)
