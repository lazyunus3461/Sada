/* Uses genuine native protocol clients, not a Minecraft rendering / GUI test. */
const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto'),net=require('node:net');
const {createRequire}=require('node:module');
const requireTest=createRequire('/workspace/Sada/scripts/integration/package.json');
const mc=requireTest('minecraft-protocol'),nbt=requireTest('prismarine-nbt');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const root='/workspace/Sada/kasaba-clash';
const catalog=JSON.parse(fs.readFileSync(root+'/core/src/main/resources/catalog/catalog.json'));
const password='Clash-Native-123';
const customPackets={'1.21':{types:{packet_common_custom_click_action:['container',[{name:'id',type:'string'},{name:'payload',type:['buffer',{countType:'varint'}]}]]}}};
const clients=[],checks=[];
const pass=name=>{checks.push(name);console.log('PASS '+name);};
async function player(username){
 const c=mc.createClient({host:'127.0.0.1',port:25616,version:'1.21.10',username,auth:'offline',customPackets,
  connect:client=>client.setSocket(net.connect({host:'127.0.0.1',port:25616,localAddress:username==='CLJ2'?'127.0.0.2':'127.0.0.1'}))});clients.push(c);
 let form,error;const packets=[],responses=[],transfers=new Map();
 c.on('error',e=>error=e);
 c.on('packet',(p,m)=>{
  packets.push({p,name:m.name});
  if(m.name==='position'){c.write('teleport_confirm',{teleportId:p.teleportId});c.write('player_loaded',{});}
  if(m.name==='chunk_batch_finished')c.write('chunk_batch_received',{chunksPerTick:20});
  if(m.name==='show_dialog')form=p.dialog.data;
  if(m.name==='custom_payload'&&p.channel==='kasaba:clash'){
   const b=p.data;assert.equal(b.readInt32BE(0),0x4b434c48);assert.equal(b.readInt32BE(4),1);
   const id=b.subarray(8,24).toString('hex'),part=b.readInt32BE(24),count=b.readInt32BE(28),total=b.readInt32BE(32),hash=b.subarray(36,68);
   let t=transfers.get(id);if(!t){t={parts:new Array(count),total,hash};transfers.set(id,t);}t.parts[part]=b.subarray(68);
   if(t.parts.filter(Boolean).length===count){const data=Buffer.concat(t.parts);assert.equal(data.length,total);assert(crypto.createHash('sha256').update(data).digest().equals(hash));responses.push(JSON.parse(data.toString()));transfers.delete(id);}
  }
 });
 async function until(f){const end=Date.now()+20000;while(Date.now()<end){if(error)throw error;const kick=packets.find(x=>x.name==='kick_disconnect');if(kick)throw Error(JSON.stringify(kick));const value=f();if(value)return value;await delay(30);}throw Error('Native wait timeout '+username);}
 await until(()=>form);
 c.write('custom_payload',{channel:'minecraft:register',data:Buffer.from('kasaba:clash')});
 async function rpc(request){const mark=responses.length;await delay(130);c.write('custom_payload',{channel:'kasaba:clash',data:Buffer.from(JSON.stringify(request))});return until(()=>responses[mark]);}
 return {c,rpc,packets,async login(){const inputs=nbt.simplify(form).inputs;const action=structuredClone(form.value.actions.value.value[0].action.value);const additions=structuredClone(action.additions);additions.value.password={type:'string',value:password};if(inputs.some(x=>x.key==='confirm'))additions.value.confirm={type:'string',value:password};const mark=packets.length;c.write('custom_click_action',{id:action.id.value,payload:nbt.proto.createPacketBuffer('anonymousNbt',additions)});await until(()=>packets.slice(mark).some(x=>x.name==='clear_dialog'));},async hello(){const token=crypto.randomUUID();const r=await rpc({v:1,type:'hello',catalog:catalog.snapshotSha256,token});assert(r.ok,JSON.stringify(r));assert.equal(r.token,token);return r.session;}};
}
const proof={started:new Date().toISOString(),scope:'Actual isolated Paper 1.21.10 + KasabaAuth 1.4.2, native protocol clients and production plugin channel. No client renderer, GUI or full gameplay validation.',checks};
(async()=>{
 const a=await player('CLJ1');let r=await a.rpc({v:1,type:'hello',catalog:catalog.snapshotSha256});assert.equal(r.ok,false);assert(r.error.includes('giriş'));pass('OP client remains blocked before actual Kasaba authentication');
 await a.login();
 r=await a.rpc({v:1,type:'hello',catalog:'bad'});assert.equal(r.ok,false);pass('Mismatched client catalog rejected');
 const session=await a.hello();
 const state=async()=>{const token=crypto.randomUUID();const r=await a.rpc({v:1,type:'state',session,region:'HOME',token});assert.equal(r.token,token);return r;};
 let s=(await state()).state;assert(s.owner);if(!process.argv[2]){assert.equal(s.resources.Gold,1000);assert.equal(s.buildings.length,2);}pass('Authenticated client negotiates real session and receives its persisted village');
 r=await a.rpc({v:1,type:'state',session:'stale',region:'HOME'});assert.equal(r.ok,false);pass('Stale session rejected');
 r=await a.rpc({v:1,type:'state',session,region:'CAPITAL'});assert.equal(r.ok,false);assert(r.error.includes('tamamlanmadı'));pass('Missing Capital gameplay is reported as unavailable');
 if(process.argv[2]==='restart'){
  const previous=JSON.parse(fs.readFileSync(root+'/validation/native-before-restart.json'));
  assert.equal(s.owner,previous.owner);assert.equal(s.resources.Gold,previous.gold);assert(s.buildings.some(x=>x.id===previous.building&&x.level===1));assert.deepEqual(s.jobs,[]);pass('Village, resources and completed construction survive a full Paper restart');
  assert.notEqual(session,previous.session);pass('A new connection cannot reuse the previous plugin session');
 }else if(process.argv[2]==='client-common'){
  const token=crypto.randomUUID(),invalid={v:1,type:'move',session,region:'HOME',token,revision:s.revision,building:'hall',x:26,z:25,owner:crypto.randomUUID()};
  r=await a.rpc(invalid);assert.equal(r.ok,false);assert.equal(r.type,'move');assert.equal(r.token,token);pass('Native rejected command echoes the exact operation nonce to release the matching client UI request');
  s=(await state()).state;const before=s.resources.Gold;
  const move={v:1,type:'move',session,region:'HOME',token:crypto.randomUUID(),revision:s.revision,building:'hall',x:26,z:25};
  r=await a.rpc(move);assert(r.ok,JSON.stringify(r));assert.equal(r.token,move.token);assert.equal(r.type,'move');assert.equal(r.state.buildings.find(x=>x.id==='hall').x,26);assert.equal(r.state.resources.Gold,before);pass('Native success acknowledges its exact nonce with authoritative village state');
  r=await a.rpc(move);assert(r.ok&&r.replay);assert.equal(r.token,move.token);assert.equal(r.state.resources.Gold,before);pass('Retrying a command preserves both nonce and original resource debit semantics');
  const stale={...move,token:crypto.randomUUID()};r=await a.rpc(stale);assert.equal(r.ok,false);assert.equal(r.token,stale.token);assert(r.error.includes('değişti'));pass('Native stale-revision error remains correlated to its own request');
 }else{
  const cannon=catalog.items.find(x=>x.family==='buildings'&&x.name==='Cannon'&&x.data.village==='home');
  const place={v:1,type:'place',session,region:'HOME',token:crypto.randomUUID(),revision:s.revision,key:cannon.key,x:2,z:2};
  r=await a.rpc({...place,owner:crypto.randomUUID(),cost:0});assert.equal(r.ok,false);assert.equal((await state()).state.revision,s.revision);pass('Forged owner and price fields cannot mutate or charge the village');
  r=await a.rpc({...place,x:20,z:20});assert.equal(r.ok,false);assert.equal((await state()).state.buildings.length,2);pass('Colliding placement rolls back without leaving an orphan building');
  r=await a.rpc(place);assert(r.ok,JSON.stringify(r));const building=r.result;const gold=1000-cannon.data.levels[0].build_cost;assert.equal(r.state.resources.Gold,gold);assert(r.state.jobs.length===1);assert.equal(r.state.buildings.find(x=>x.id===building).level,0);pass('Real placement reserves its footprint, spends source-defined gold and starts a persisted job');
  r=await a.rpc(place);assert(r.ok&&r.replay);assert.equal(r.state.resources.Gold,gold);pass('Replayed plugin-message mutation is idempotent');
  r=await a.rpc({...place,token:crypto.randomUUID(),x:8,z:8});assert.equal(r.ok,false);pass('An out-of-date village revision cannot buy a second building');
  s=(await state()).state;const move={v:1,type:'move',session,region:'HOME',token:crypto.randomUUID(),revision:s.revision,building:'hall',x:25,z:25};
  const mark=a.packets.length;r=await a.rpc(move);assert(r.ok,JSON.stringify(r));assert.equal(r.state.buildings.find(x=>x.id==='hall').x,25);assert(!a.packets.slice(mark).some(x=>['position','window_items','set_slot','open_window'].includes(x.name)));pass('Server applies a valid village move without sending teleport or inventory mutations');
  fs.mkdirSync(root+'/validation',{recursive:true});fs.writeFileSync(root+'/validation/native-before-restart.json',JSON.stringify({owner:r.state.owner,gold,building,session}));
 }
 const b=await player('CLJ2');await b.login();r=await b.rpc({v:1,type:'hello',catalog:catalog.snapshotSha256});assert.equal(r.ok,false);pass('Authenticated ordinary players cannot enable unfinished development gameplay');
 proof.passed=true;
})().catch(e=>{proof.error=e.stack;console.error(e);process.exitCode=1}).finally(async()=>{for(const c of clients)c.end();await delay(300);fs.mkdirSync(root+'/validation',{recursive:true});fs.writeFileSync(root+'/validation/native-'+(process.argv[2]||'initial')+'.json',JSON.stringify(proof,null,2));process.exit(process.exitCode||0);});
