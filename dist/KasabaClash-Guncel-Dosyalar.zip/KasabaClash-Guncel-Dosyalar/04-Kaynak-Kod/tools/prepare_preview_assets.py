from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures,re
root=Path(__file__).resolve().parents[1];manifest=json.loads((root/'research/asset-manifest.json').read_text());assets={r['path']:r for rows in manifest['assets'].values()for r in rows};chosen=set()
for group in ['resources','heroes','pets']:
 chosen.update(x['path']for x in manifest['assets'][group])
for group,limit in [('troops',32),('spells',16),('equipment',18),('skins',18)]:
 chosen.update(x['path']for x in manifest['assets'][group][:limit])
for x in manifest['assets']['sceneries']:
 if any(k in x['path']for k in ['classic','jungle','magic','shadow','dragon','clashy','pirate','epic_winter'])and x['path'].endswith('thumbnail.webp'):chosen.add(x['path'])
for x in manifest['assets']['buildings']:
 if x['path'].endswith('/level_1.webp')or any(k in x['path']for k in ['/town_hall/','/builder_hall/']):chosen.add(x['path'])
for x in manifest['assets']['capital-base']:
 if '/capital-hall-pics/'in x['path']or x['path'].endswith('/Building_CC_Clan_House.png'):chosen.add(x['path'])
for x in manifest['assets']['icons']:
 if any(k in x['path']for k in ['Attack','Clan_Badge','Star','CWL','War','Blacksmith']):chosen.add(x['path'])
for name in ['archer','barbarian','dragon','giant','goblin','wall_breaker','balloon','wizard','healer','pekka','hog_rider','baby_dragon','rage_barbarian','sneaky_archer','boxer_giant','cannon_cart','night_witch','electro_dragon','yeti','witch']:
 p=f'troops/{name}/icon.webp'
 if p in assets:chosen.add(p)
for name in ['barbarian_king','archer_queen','gladiator_king','ice_queen','dragon_king','dragon_queen','royal_champion']:
 p=f'skins/{name}/icon.webp'
 if p in assets:chosen.add(p)
for p in ['landscape/home-landscape.png','landscape/builder-landscape.png','landscape/clan-capital-landscape.png']:
 if p in assets:chosen.add(p)
commit='fdac291ae7fbc2901221ff945834be534d0344ae'
def fetch(path):
 target=root/'preview/assets'/path;expected=assets[path]['sha']
 if target.exists()and hashlib.sha256(target.read_bytes()).hexdigest()==expected:return {'path':path,'bytes':target.stat().st_size,'sha256':expected}
 try:
  url='https://raw.githubusercontent.com/ClashKingInc/ClashKingAssets/'+commit+'/assets/'+urllib.parse.quote(path,safe='/')
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Kasaba-GUI-preview'}),timeout=25)as r:data=r.read(3000001)
  assert len(data)<=3000000 and hashlib.sha256(data).hexdigest()==expected
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  return {'path':path,'bytes':len(data),'sha256':expected}
 except Exception as e:return {'path':path,'error':str(e)}
rows=list(concurrent.futures.ThreadPoolExecutor(max_workers=8).map(fetch,sorted(chosen)))
(root/'preview/asset-sources.json').write_text(json.dumps({'upstream_commit':commit,'files':rows},indent=2)+'\n')
print(json.dumps({'selected':len(rows),'downloaded':sum('error'not in x for x in rows),'bytes':sum(x.get('bytes',0)for x in rows),'errors':[x for x in rows if 'error'in x]}))
