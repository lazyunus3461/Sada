# KasabaTR • Clash çalışması

Kullanıcının hedefi: Paper 1.21.10 / Java 21 üzerinde Ana Köy, İnşaatçı Üssü ve Klan Başkentini içeren; menüler, gelişim, savaşlar, karakterler, binalar ve kozmetiklerde Clash of Clans ile aynı davranışı ve görünüşü isteyen bir oyun. İstenen teslim: kaynak kod, kurulum JAR'ı, oyuncu istemci modu ve kaynak paketi. Bir deneme paketi istenmiyor.

Bu klasör **tamamlanmış oyun değildir**. Kaynak incelemesi ve SHA256 ile doğrulanan verilerin yanında Java sunucu çekirdeği ve gerçek Paper bağlantı adaptörü bulunur. `server/target/KasabaClash-Server-0.1.0-DEVELOPMENT.jar` geliştirme adaptörüdür; 43 ekranı Minecraft içinde açmaz ve tam oyun olarak dağıtılmaz. Henüz oynanabilir tam oyun JAR’ı veya istemci modu üretilmedi.

`client-common/` altında sunucu yanıtını bekleyen menü/veri etkileşimleri, nonce eşleştirmesi, isometrik kamera/tıklama hesabı ve 43 ekranın manifesti hazırlandı. Bu modül Fabric modu veya Minecraft GUI’si değildir. Ayrıntı: `client-common/README.md`. `dist/KasabaClash-Resources-0.1.0-DEVELOPMENT.zip` 287 doğrulanmış 2B görseli PNG/item-model/font olarak içerir; 3B binalar veya animasyonlu birlikler değildir. Gerçek Minecraft codec’iyle metadata doğrulaması yapıldı; istemcide görsel yükleme testi yapılamadı. Ayrıntı: `RESOURCE-PACK.md`.

`research/coverage.json` bulunan veriyi ve eksikleri açıkça listeler. `tools/audit_content.py`, kaynakların değişmediğini doğrular ve bu raporu yeniden üretir. Bir içerik kataloğunun bulunması, oyunun veya kozmetik sisteminin uygulanmış olduğu anlamına gelmez.

## Doğrulananlar

ClashKing Assets manifestiyle eşleşen 28 istatistik ve iki çeviri dosyası indirildi. Her dosyanın URL'si ve SHA256 değeri `research/sources.json` içinde. Kaynak, resmi Supercell oyun sürümünün doğrulaması değildir. Resmi sürüm notu alan adına erişim bu ortamda engellidir.

Kaynakta Ana Köy belediye binası 18 ve İnşaatçı Salonu 10 seviyesine kadar kayıt bulunuyor. Klan Başkenti için bazı görseller ve ev parçaları var; tam bina/ilçe istatistikleri bulunmuyor. Üretim hızları, kaynak kapasitesi ve bütün savaş davranışları bu dosyalardan çıkarılamıyor. Belediye seviyesindeki bina açılma/adet tabloları bulundu ve `HallRules` içinde uygulandı.

Görsel manifestte resim ve ikonlar bulunuyor. Bunlar tamamlanmış Minecraft 3B binaları, hareketli asker modelleri veya bütün GUI ekranları değildir. Bunları uygulamadan yapılmış gibi göstermek doğru olmaz.

## Onaylanan teslim biçimi

Kullanıcı GUI ve kontrolleri de birebir istiyor. Standart sunucu eklentisi + kaynak paketi Minecraft istemcisinin ekran ve giriş sistemini tamamen değiştiremez. Kullanıcı özel tam ekran GUI, kamera/köy düzenleme kontrolleri ve karakter animasyonu için istemci modunu açıkça onayladı. İstemci derlemesinin resmi Fabric/Mojang adresleri ağ filtresinde engelli; gerekli alan adları ortam taslağına kaydedildi ve ortamın yayımlanması bekleniyor.

## Mevcut Kasaba sistemleriyle sınırlar

Yeni oyun ayrı modülde geliştirilecek; Skyblock dünyası, para/veri dosyaları ve diğer oyunların kuralları değiştirilmez. Hub'a katılım/çıkış, oyuncu envanteri kurtarma, kimlik doğrulama, erişim engeli, bakım ve izleme hakları gerçek Kasaba API'leri üzerinden bağlanmalı. Klan Başkenti için ağın ortak klan üyeliği kullanılmalı; ikinci ve çelişen bir klan kimliği oluşturulmamalı. Mevcut ortak klan eklentisinde okuma/yönetim için tam bir servis API'si bulunmadığından bunun ayrıca tanımlanması gerekiyor.

Yalnız çalışan oyun akışları uygulanıp görsel ve sunucu testleri tamamlandığında üretim paketi hazırlanır. Bu klasörün mevcut durumuna “tam/birebir paket” denmez.

## Çekirdek doğrulaması

`bash kasaba-clash/tools/cloud-build-core.sh` artık çekirdek ve Paper adaptörünü birlikte derler. On bir Java testi çalıştırıldı: gerçek SQLite kapanış/açılışında kayıt, kaynak harcaması/geri alma, tekrar işlem ve eski sürüm reddi, bina çakışması/inşaatçı sınırı, doğrulanmış açılma adetleri, ağ durumu parçalarının bütünlüğü ve `GameService` yerleştirme/geliştirme/taşıma işlemleri. Bunlar Minecraft istemci GUI’si veya tam savaş sistemi testi değildir.

Aynı Maven derlemesi şimdi `client-common` modülünü de içerir. Sekiz yeni istemci ortak kodu testiyle toplam **19 Java testi** geçti. Yeni istek kimliği eşleştirmeleri gerçek Paper sunucusunda ayrıca 10 native protokol kontrolüyle doğrulandı. Önceki 12+8 kontroller önceki adaptör yapısına aittir; farklı artifact hashleri raporlarda ayrı tutulur.

Paper 1.21.10 / Java 21 ve gerçek KasabaAuth 1.4.2 ile ayrı, yalnız loopback test sunucusunda 12 ilk bağlantı + 8 tam yeniden başlatma kontrolü geçti. Gerçek Minecraft protokol paketleriyle oturum, katalog eşleşmesi, OP giriş kilidi, kaynak harcama, tekrar istek, çakışma/işlem geri alma, izin reddi ve kalıcılık doğrulandı. Kaynaklar `validation/native-*.json` ve `NATIVE-TEST.md` içindedir. İnsan tarafından Minecraft GUI görsel testi yapılmadı.

Adaptör, KasabaAuth servisini zorunlu tutar; oyunu tamamlanmış gibi Hub'a kaydetmez. Varsayılan `development-connection-enabled: false` bırakılır. Geliştirme bağlantısı ayrıca `kasabaclash.gelistirme` izni ister. Yalnız `state`, `place`, `upgrade`, `move` işlemleri bulunur; savaş, ödül, ordu, klan/başkent veya kozmetik işlemi varmış gibi sonuç üretilmez. Kasaba altın/kredi kayıtlarına, mevcut dünyalara ve oyuncu envanterine yazılmaz.

Kaynak dosyaları içerik hashlerinin yanında değişmez `fdac291ae7fbc2901221ff945834be534d0344ae` upstream commitine Git blob kimlikleriyle bağlandı. Proje sınırları ve yapılacak gerçek istemci/sunucu entegrasyonu `SERVER-CLIENT-CONTRACT.md` dosyasında.

## GUI tasarım galerisi

`preview/` altında 43 ekranlık çevrimdışı HTML tasarımı bulunur: üç köy, düzenleme, bina bilgisi/geliştirme, ordu, kahraman/ekipman/evcil, saldırı, klan, başkent, kozmetik, görev ve yardım ekranları. `python tools/build_gui_preview.py ./dist/gui-preview` tek dosyalı, gömülü görselli bir HTML üretir. Bu dosya Minecraft istemcisinde çalışan GUI değildir; oyun eklentisi veya kaynak paketi olarak yüklenmez.

287 kaynak görsel SHA-256 ile doğrulanıp gömüldü. Chromium 154 ile 43 ekranın yüklenmesi, bozuk görsel ve yatay sayfa taşması kontrol edildi; 26 etkileşim kontrolü geçti. `research/gui-preview-status.json` kapsamı kaydeder. Örnek bakiyeler, savaşlar ve yerel seçimler açıkça işaretlidir; gerçek inşaat, savaş, bağış veya satın alma işlemi yapılmaz. Kaynaklardan yeniden üretilen HTML ile teslim edilen HTML'nin SHA-256 değerleri eşleşti.
