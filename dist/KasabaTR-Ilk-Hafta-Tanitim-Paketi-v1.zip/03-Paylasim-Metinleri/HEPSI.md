# KasabaTR — İlk hafta paylaşım metinleri

Her günün metni, aynı numaralı görselle eşleşir. Gönderi metinleri doğrudan kopyalanabilir.

## 1. gün — İLK BULUŞMA

Arkadaşlarınla gireceğin yeni bir yer hazırlanıyor. 🏡

KasabaTR çok yakında. İlk günden yanında olmasını istediğin arkadaşını yoruma etiketle.

Duyurular için takip et: @kasabatrminecraft

#Minecraft #MinecraftTürkiye #KasabaTR #MinecraftSunucusu #ArkadaşlarlaOyun

## 2. gün — EKİBİNİ BUL

Ekibin kaç kişi? 👀

2 kişilik ayrılmaz ikili mi, bütün akşam birbirini bekleyen kalabalık ekip mi?

Sayını yoruma bırak; gelmesini istediğin arkadaşlarına gönder.
@kasabatrminecraft

#Minecraft #MinecraftTürkiye #KasabaTR #MinecraftSunucusu #ArkadaşlarlaOyun

## 3. gün — AYNI KASABA

Bu akşam ne oynuyoruz? 🎮

KasabaTR’de arkadaşlarınla buluşup farklı oyunlara geçebileceğin bir yer hazırlıyoruz.

Senin için ilk sırada rekabet mi, arkadaşlarla eğlence mi var?
@kasabatrminecraft

#Minecraft #MinecraftTürkiye #KasabaTR #MinecraftSunucusu #ArkadaşlarlaOyun

## 4. gün — TARAFINI SEÇ

Bir arkadaş her oyunu final maçı gibi oynar. Diğeri sadece ortalığı karıştırır. 😄

Sizin ekipte hangisi sensin? Yoruma yaz.

KasabaTR çok yakında.
@kasabatrminecraft

#Minecraft #MinecraftTürkiye #KasabaTR #MinecraftSunucusu #ArkadaşlarlaOyun

## 5. gün — BİRİNE GÖNDER

“Bir el girip çıkarız” deyip bütün akşam oynadığın o arkadaş… 💬

Bu paylaşımı ona gönder. Yeni buluşma yeriniz hazırlanıyor.

KasabaTR | @kasabatrminecraft

#Minecraft #MinecraftTürkiye #KasabaTR #MinecraftSunucusu #ArkadaşlarlaOyun

## 6. gün — BULUŞMA NOKTASI

Günün sonunda arkadaşlarınla aynı yerde buluşmak… 🌙

KasabaTR’yi bunun için hazırlıyoruz. Birlikte oynayacağımız yeni oyun geceleri çok yakında.

Duyuruları kaçırmamak için takipte kal.
@kasabatrminecraft

#Minecraft #MinecraftTürkiye #KasabaTR #MinecraftSunucusu #ArkadaşlarlaOyun

## 7. gün — İLK HAFTANIN SONU

Bu kasabada senin ve arkadaşlarının da yeri var. 🏡

İlk haftada burada olan herkese selam! Hazırlıklar sürüyor; oyunlardan yeni görüntüler ve duyurular bu hesapta olacak.

Takip et, ekibine gönder: @kasabatrminecraft
Sunucu adresi: play.kasabatr.com

#Minecraft #MinecraftTürkiye #KasabaTR #MinecraftSunucusu #ArkadaşlarlaOyun
