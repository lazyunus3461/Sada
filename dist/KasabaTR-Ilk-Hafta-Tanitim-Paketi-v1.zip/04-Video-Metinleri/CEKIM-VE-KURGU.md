# KasabaTR — Gerçek oyun kaydı için 7 video akışı

Bunlar bitmiş video değildir. Çekim ve kurgu metinleridir. Her video 24 saniye; dikey 1080×1920, 30 FPS. Gerçek kayıt geldiğinde uygulanır. Oyuncu adları/özel sohbetler kadrajda kalmamalı. Eski 3D render tanıtımı kullanılmaz.

Her akış: 0–3 sn giriş, 3–10 sn birinci görüntü, 10–18 sn ikinci görüntü, 18–24 sn kapanış. Kapanışta yalnız “KasabaTR çok yakında”, adres ve hesap görünür. Kullanım izni olan ses veya platformun hesabına uygun müzik kütüphanesi seçilir; hazır pakette müzik yoktur.

## 1. gün

Ekran girişi: **Ekibinle gireceğin yeni bir yer arıyorsan…**

1. Lobide yürüyüşten kısa, temiz bir açılış.
2. Lobinin iki farklı açısından gerçek görüntü.
3. Birlikte yürüyen oyuncular; ardından marka ve hesap.

## 2. gün

Ekran girişi: **Senin ekip de böyle mi?**

1. İki oyuncunun lobide karşılaşması.
2. Aynı noktaya sırayla gelen diğer oyuncular.
3. Ekibin birlikte yürümesi ve soru ekranı.

## 3. gün

Ekran girişi: **Her akşam aynı şeyi oynamak zorunda değilsin.**

1. Oyunlar pusulasının gerçek menüsünü aç.
2. İki farklı oyun lobisinden kısa yürüyüşler.
3. Ana lobide ekiple buluş; marka kapanışı.

## 4. gün

Ekran girişi: **Her ekipte bu iki kişi vardır.**

1. Gerçek bir yarıştan rekabetli bir an.
2. Aynı oturumdan komik bir hata veya çarpışma.
3. Oyuncuların yeniden buluşması ve soru ekranı.

## 5. gün

Ekran girişi: **“Bir el girip çıkarız” diyen arkadaşına gönder.**

1. Lobide birbirini bekleyen iki oyuncu.
2. Birlikte bir oyuna yürümeleri.
3. İki oyuncunun aynı kadrajda olduğu kapanış.

## 6. gün

Ekran girişi: **Günün en iyi kısmı bazen budur.**

1. Lobide gün batımı veya gece görüntüsü; gerçek sunucu çekimi.
2. Işıklı alanlardan yavaş, kısa geçişler.
3. Oyuncuların buluşması; hesap ve adres kapanışı.

## 7. gün

Ekran girişi: **Yeni bir kasaba. Aynı ekip. Yeni anılar.**

1. Haftanın en iyi üç gerçek oyun anını seç.
2. Her birinden 3–4 saniyelik temiz kesitler.
3. Lobide grup görüntüsü ve “Çok yakında” kapanışı.
