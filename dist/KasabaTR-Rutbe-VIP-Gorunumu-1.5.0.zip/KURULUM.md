# KasabaTR Rütbe ve VIP Görünüşü 1.5.0

Paper 1.21.10 / Java 21. Bu güncelleme KasabaRoles 1.5.0 ve KasabaKimlik 0.2.1 içerir.

## Kurulum

1. Sunucuyu tamamen durdur.
2. `plugins` içindeki eski `KasabaRoles-*.jar` ve `KasabaKimlik-*.jar` dosyalarını kaldır; ZIP'teki `plugins` klasörünün iki yeni JAR dosyasını buraya koy.
3. Veri klasörlerini silme: `plugins/KasabaRoles`, `plugins/KasabaKimlik` ve diğer eklentiler kalacak.
4. Sunucuyu yeniden başlat. Harita yüklemen veya doğma noktalarını yeniden kaydetmen gerekmez.
5. Oyunda `/rol görünüm` yaz. Aynı komutun Türkçe harfsiz yazımı: `/rol gorunum`.

KasabaKimlik zaten mevcut sunucu paketindeki KasabaAuth ve KasabaHub'a ihtiyaç duyar. Bu paket mevcut KasabaTR sunucusunu günceller; bağımsız tam sunucu değildir. İki JAR birlikte güncellenmelidir. `/reload` kullanma.

## Görünüş

| Rütbe | Rozet | Renk ailesi |
| --- | --- | --- |
| Kurucu | ✦ KURUCU | Mercan kırmızısı |
| Admin | ◆ ADMİN | Eflatun |
| Moderatör | ◆ MODERATÖR | Yeşil |
| Rehber | ✧ REHBER | Turkuaz |
| VIP | ✦ VIP ✦ | Altın geçiş |
| VIP+ | ✧ VIP+ ✧ | Buz mavisi geçiş |
| VIP Ultra | ✦ VIP ULTRA ✦ | Mor-pembe geçiş |
| Oyuncu | • OYUNCU | Gri-mavi |

Sohbet örneği: `✦ VIP ULTRA ✦ │ [KSB] Oyuncu › Merhaba`.

VIP rozetleri kalın, harfler arasında yumuşak renk geçişlidir. Oyuncunun adı ve mesajı bağımsız renklendirilir. Standart Minecraft yazı tipi kullanılır; ek mod veya kaynak paketi gerekmez. Sohbet, TAB ve isim üstü rozet aynı kaynaktan hazırlanır. Klanı olan normal oyuncuda `OYUNCU` öneki yerine klan etiketi görünmeye devam eder. Sağdaki küçük bilgi tablosu aynı boyutta kalır; `play.kasabatr.com` adresi korunur.

İsim üstü rozetlerin mevcut gizlilik kuralları korunur: sahibi kendi rozetini görmez; maçlarda, görünmezlikte, hayalet modunda ve oyuncu gizlemede rozet bilgi sızdırmaz. Oyunların kendi skor tabloları değiştirilmez.

## VIP kademeleri ve komutlar

- `/rol ver Oyuncu vip`
- `/rol ver Oyuncu vipplus`
- `/rol ver Oyuncu vipultra`
- `/rol liste`: rütbeleri kendi renkleriyle listeler.
- `/rol görünüm`: sekiz rütbe için sohbet görünüşünü gösterir; rol atamaz.
- `/rol bilgi Oyuncu`: mevcut rütbeyi gösterir.
- `/rol yenile`: yöneticinin rol ayarlarını yeniden okur.

Üst iki kademe yönetici tarafından atanabilir; şu anda mevcut VIP haklarını miras alır ve yönetici yetkisi vermez. Her kademenin farklı satış fiyatı ve ek oyun ayrıcalıkları kullanıcıyla daha sonra belirlenecektir. Bu sürüm üst kademeleri markette satışa çıkarmaz ve kendiliğinden oyuncu yükseltmez. Mevcut VIP satın alma fiyatları ve süreleri değişmez: 3 gün 40 / 7 gün 75 / 15 gün 145 / 30 gün 250 Akçe. Süreli VIP kayıtları korunur. `/rol ver` ile atanan rütbe mevcut sistemdeki gibi kalıcıdır.

## Kayıtlar ve yedek

İlk açılışta yalnız hazır rütbelerin görsel renk ayarları güncellenir ve eksik VIP+ / VIP Ultra tanımları eklenir. Eski rol dosyası otomatik olarak `plugins/KasabaRoles/config-before-appearance-1.5.0.yml` adıyla yedeklenir. Mevcut rol kimlikleri, görünen adlar, oyuncu atamaları, izinler, miras ilişkileri ve VIP süreleri korunur. Özel eklenmiş farklı rol kimlikleri değiştirilmez. Sonradan `/rol renk` veya config ile yaptığın renk düzenlemeleri yeniden başlatmada sıfırlanmaz.

Test raporu ve JAR doğrulama özetleri ZIP içindedir. Testler yerel Paper sunucusunda protokol istemcileriyle yürütülmüştür; canlı sunucuya yükleme yapılmamıştır.
