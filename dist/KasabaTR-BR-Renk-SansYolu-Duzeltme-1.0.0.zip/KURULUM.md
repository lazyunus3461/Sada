# KasabaTR — BR, Renk Kaçışı ve Şans Yolu düzeltmeleri

## Yükleme

1. Sunucuyu durdur ve `plugins/` klasörünü yedekle.
2. Eski BR (`KasabaBattleRoyale`), `KasabaRenk` ve `KasabaIspanya` JAR'larını kaldır.
   **Eklenti veri klasörlerini silme.** Aynı eklentinin iki sürümünü bırakma.
3. ZIP'in `plugins/` klasöründeki üç dosyayı sunucunun `plugins/` klasörüne koy:
   - `KasabaBattleRoyale-1.3.2.jar`
   - `KasabaRenk-1.5.2.jar`
   - `KasabaIspanya-0.9.2.jar`
4. Sunucuyu başlat; `/reload` kullanma. Dünya veya spawn kurulumunu tekrarlama.

Paper 1.21.10 / Java 21 ve mevcut KasabaTR eklentileri gerekir.
Kayıtlı dünyalar, lobi/arena konumları ve oyuncu verileri korunur.

## Battle Royale — kalkan

Normal oyuncu kalkanı **F** ile ikinci eline alabilir; envanterde yerleştirme,
sürükleme ve sayı tuşu da çalışır. Sandıktaki kalkana Shift ile tıklayınca ikinci
el boşsa doğrudan takılır. Kalkanın büyüleri korunur ve envanter kontrolü artık
takılan kalkanı geri çıkarmaz. Kalkanla savunma kullanılabilir.

Normal oyuncunun üstteki 27 depolama yuvası kapalı kalır. İkinci elde yalnız kalkan
bulunabilir; kılıç/yiyecek gibi başka eşyalar buraya depolanamaz. VIP'in tam
envanter hakkı devam eder. Zırh yuvaları ve maç sonunda eski envanterin geri
verilmesi korunur.

## Renk Kaçışı

- Kartopu bekleme süresi **2 saniyeden 1,5 saniyeye** indirildi. Menü ve eşya
  açıklaması güncellendi. Her tur yine 8 kartopu; vuruş hasarı yoktur.
- İki veya daha fazla kişiyle başlayan maçta tek yarışmacı kalınca kazanır ve
  Renk Kaçışı lobisine döner. Bu, iki kişilik yönetici denemesinde de çalışır.
- Oyun lobisine çıkma, `/lobi`, bağlantı kopması ve eski çevrimdışı oda kaydı
  sonucun takılmasına yol açmaz. Artık oyuncu sayısı güncel üyelerden hesaplanır.
- Son rakip düşerek elendiğinde kısa düşüş animasyonu tamamlanır; hemen geri
  ışınlanıp düşme hissinin kaybolmasına neden olunmaz.
- Tek başına açılan yönetici alıştırması oynanmaya devam eder. Deneme maçları
  liderlik tablosuna galibiyet yazmaz.

## Şans Yolu

- **1+1, 2+2, 3+3, 4+4, 5+5 ve 6+6** atan oyuncu tekrar zar atma hakkı kazanır.
  Oyuncu zar eşyasına tekrar tıklar veya `/sansyolu zar` yazar; zar otomatik atılmaz.
- Ek hak, hareket ve renkli karenin etkisi bittikten sonra verilir. Yeşil/mor
  ileri-geri hareketler ve sarı kestirme sırasında sıradaki oyuncuya erken geçilmez.
  Kestirme kullanıldıktan sonra çubuk silinir ve ek hak kullanılabilir.
- Art arda çift atan oyuncu tekrar hak kazanabilir. Çift gelmeyince sıra geçer.
  Bitişe ulaşan oyuncuya ek zar verilmez. Tam zarla bitiş ayarı da desteklenir.
- Herkes ayrılıp tek oyuncu kalınca **KAZANDIN** yazısı çıkar; 3 saniye sonra
  Şans Yolu lobisine döner. Hareket animasyonu ve bekleyen etkiler temizlenir.
- Yalnız bir oyuncu henüz bitişe ulaşmamışsa sıralaması son olarak tamamlanır;
  maç tek kişilik yarışla açık kalmaz. Bitişe ilk ulaşan birinci kalır.
- Kopan bağlantılar ve eski çevrimdışı oda üyeleri ayıklanır. Geçici maç dünyası
  sonuçtan sonra temizlenir. Diğer odalar çalışmaya devam eder.

Mevcut komutlar değişmedi: `/br`, `/renk`, `/sansyolu`. Zar atmama nedeniyle
üç uyarıda oyun lobisine dönme kuralı da devam eder.

## Doğrulama

`TEST-SONUCLARI.json` test kapsamını ve sonuçları içerir. Testler canlı sunucu
yerine izole Paper sunucusunda protokol istemcileriyle yapılır. F tuşu gerçek
istemci paketiyle sınanır; bazı envanter kontrolleri Bukkit olaylarıyla yapılır.
Özel test aracı konum/zar hazırlığı ve zaman ilerletmesi sağlar; bu araç ZIP'te
bulunmaz. JAR sağlamaları `SHA256SUMS.txt` içindedir. Yüklemeyi sen yapacaksın.
