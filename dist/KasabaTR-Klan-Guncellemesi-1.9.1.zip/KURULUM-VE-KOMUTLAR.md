# /klan güncellemesi

Ana komut artık **/klan**. Menü, yardım, defter ve VIP açıklamalarındaki ad da **Klan** oldu. Eski `/lonca` komutu uyumluluk için aynı sisteme yönlenir.

## Kurulum

1. Sunucuyu tamamen durdur.
2. `plugins` içindeki eski **KasabaTopluluk**, **KasabaHub** ve **KasabaSosyal** JAR dosyalarını kaldır. ZIP'in `plugins` içindeki üç yenisini yükle. Aynı eklentinin iki sürümü kalmasın.
3. Sunucuyu başlat. `/reload` kullanma.

**`plugins/KasabaTopluluk` klasörünü veya `topluluk.yml` dosyasını silme.** Klan kimlikleri, adları, üyeleri, liderleri, üç harfli etiketleri, davetleri ve kayıtlı sohbet cezaları aynı dosyada kalır. Daha önce ödenmiş kurulumların işlem anahtarı korunur; 50 Akçe yeniden alınmaz. Klan etiketinin TAB/sohbet/kafa üstü/kişisel panelde görünüşü aynı kalır.

## Komutlar

- `/klan`: menü.
- `/klan kur Kasaba KSB`: 50 Akçe ile klan kur.
- `/klan davet Oyuncu`: liderin oyuncu davet etmesi.
- `/klan katıl KSB`: daveti kabul et.
- `/klan üyeler`: bilgi ve üye menüsü.
- `/klan sohbet mesaj`: klan sohbeti; spawn ve lobilerde.
- `/klan çıkar Oyuncu`: liderin üye çıkarması.
- `/klan devret Oyuncu`: liderliği üyeye devret.
- `/klan çık`: üye olarak ayrıl.
- `/klan dağıt onayla`: liderin klanı silmesi; ücret iade edilmez.
- `/klan takvim`: savaş tarihleri.

## Doğrulama

34 mevcut birim testi geçti. Gerçek Paper 1.21.10 test sunucusunda eski sürümle kurulmuş iki üyeli klan yeni sürümde aynı kimlik ve etiketle açıldı. Daha önce ödenmiş ama tamamlanma kaydı bekleyen bir kurulum tekrar denendi; ikinci ödeme alınmadı. Yerli Minecraft menüsü ve TAB tamamlama, `/klan`, eski alias, ad alanlı komut, davet/katılım/liderlik, susturulan klan sohbeti, VIP sayfası ve defter kontrol edildi.

Bu değişiklik KasabaTopluluk **1.0.2**, KasabaHub **1.9.1**, KasabaSosyal **1.3.2** içerir. Önceki 1.9.0'daki hile korumasının çıkarılması, dikey/kapalı Ayna Mimar, kendi evcil/yedek/vitrin eklentileri ve 26338 UDP ses örneği tam pakette korunur. Canlı sunucuya yüklemeyi kullanıcı yapar.
