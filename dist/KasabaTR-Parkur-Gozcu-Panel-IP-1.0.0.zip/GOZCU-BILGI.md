# Kasaba Gözcü 1.0.0

KasabaTR için özgün, şüphe bildirimi oluşturan yönetim eklentisi. Paper 1.21.10,
Java 21, KasabaHub 1.9.3 ve KasabaAuth gerekir. Harici hile koruması içermez.

Tekrarlanan uzak saldırı denemeleri, çok yoğun saldırı girdileri ve uygun
koşullardaki hız/havada kalma örnekleri kaydedilir. Gerçek istemci saldırı
paketleri salt okunur izlenir; paketler değiştirilmez veya engellenmez.
Işınlanma, savrulma, yüksek gecikme, düşük TPS, araçlar ve özel oyun hareketleri
için muafiyetler vardır. Yerel mini oyunların özel hareketleri hareket kontrolü
dışındadır; istemci saldırıları ayrıca izlenir. Her hileyi yakalama garantisi yoktur.

Yalnız OP veya `kasabaroles.admin` yetkili Kurucu bildirim görür. `/yonet` içindeki
**Bildirimler** ekranı oyuncuyu, şüphe türünü, zamanı ve ölçümü gösterir.
**Görünmez ol ve izle** oyuncunun canlı konumuna görünmez spectator olarak gider.
`/yonet izlemeyibit` izlemeyi bitirir. Elle başlatmak için `/yonet izle Nick`.
İzleme sırasında normal oyuncu üyeliği ve aktiflik ödülü verilmez; mesaj ve
etkileşim kapalıdır. Çıkışta envanter ve önceki oyun modu geri yüklenir; hedef
çıkarsa veya yönetici yetkisi kalkarsa izleme sonlanır. Çevrimdışı kalan
gözlemcinin yedeği sonraki doğrulanmış girişte kurtarılır.

Otomatik atma, ban veya hareket düzeltme uygulanmaz. Yönetici **İncelendi** veya
**Yanlış şüphe olarak kapat** seçer. Kayıtlar `KasabaGozcu/bildirimler.json`
dosyasında tutulur; varsayılan üst sınır 500 kayıttır.
