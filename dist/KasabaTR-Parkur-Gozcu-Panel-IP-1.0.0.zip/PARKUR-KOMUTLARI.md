# KasabaTR Macera Parkuru 1.0.0

Paper 1.21.10 / Java 21. KasabaAuth ve KasabaHub ile çalışan özgün eklenti ve dünya.

Kolay, Orta ve Zor rotalarının her birinde 100 bölüm vardır. Oyuncular maç ve sıra
beklemeden aynı dünyada bağımsız oynar. Kontrol noktaları ve en iyi ilerleme diske
kaydedilir. İlk beş, üç rotanın en iyi bölüm sayılarının toplamıyla sıralanır
(en çok 300); eşitlikte önce ulaşan öndedir. Bitirilen bölümü tekrar oynamak puan
kazandırmaz. Yönetici denemesi sıralamaya yazılmaz.

Kütükler, çapraz atlayışlar, basamaklar, merdivenler, sarmaşıklar, iskele, dar
geçitler, slime ve bal bölümleri vardır. Düşüş algılandıktan sonra en az 10 tik
beklenir; en az 8 blok düşüldüğünde veya aşağıdaki zemine inildiğinde son kontrol
noktasına dönülür. Slime/bal bölümünün tasarlanmış alçak zemini düşüş sayılmaz.

## Kurulum

Sunucuyu durdur. Hazır paketteki JAR dosyalarını `plugins/` içine koy; aynı
eklentilerin eski JAR sürümlerini kaldır. Eklenti veri klasörlerini silme.
Başlatınca `kasaba_parkur` dünyası JAR içinden ilk kez kurulur ve pusulaya eklenir.
Mevcut dünya ve ilerleme dosyalarının üstüne harita yazılmaz. Multiverse varsa
dünya ayrıca tanıtılır. Ayrı dünya ZIP'i yüklemek zorunlu değildir.

## Komutlar

- `/parkur`: Lobi ve zorluk seçimi.
- `/parkur kolay`, `/parkur orta`, `/parkur zor`: Son kayıttan devam.
- `/parkur dön`: Son kontrol noktasına dön.
- `/parkur lobi`: Parkur lobisinde kal.
- `/parkur ilerleme`, `/parkur sıralama`: İlerleme ve ilk 5.
- `/parkur bölüm kolay 12`: Daha önce açılmış bir kontrol noktasından başla.
- `/parkur baştan kolay`: Rotanın mevcut noktasını sıfırla; en iyi rekor korunur.
- `/lobi`: Ana lobiye dön; parkurdan çıkış cezası yoktur.
- Yönetici: `/parkur deneme zor 50` ve `/parkur yönetim aç|kapat`.

## Doğrulama kapsamı

Gerçek Paper üzerinde çoklu protokol istemcileriyle giriş, bağımsız rotalar,
kayıt, atlanan kontrol noktaları, görünür düşüş, korumalar, eşya geri yükleme ve
yeniden başlatma kontrol edilir. Anvil dosyalarında 303 kontrol noktasının zemini
ve baş boşluğu, 1748 sıralı geçiş noktası ve 735 sıradan atlayış geçişinin
ölçüleri denetlenir. Bu kontroller, 300 bölümün tamamının insan oyuncuyla
oynanarak bitirildiği anlamına gelmez; özel mekaniklerin oyun içi denemesi gerekir.
