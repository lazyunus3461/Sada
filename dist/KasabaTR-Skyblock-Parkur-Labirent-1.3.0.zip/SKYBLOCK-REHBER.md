# KasabaTR Skyblock 1.2.0

Paper 1.21.10 / Java 21. Bu sürümü KasabaHub 1.12.2, KasabaRoles 1.6.2 ve KasabaEvcil 1.2.1 ile kur. Mevcut KasabaAuth ve KasabaAkce eklentileri ağda kalır. Dağıtım canlı sunucuya otomatik kurulmaz.

## Oyuna başlama

`/sb gir` → `/sb olustur`. Tek kalıcı `kasabatr_skyblock` dünyasında her ada tam 100×100 bloktur; komşu merkezler 2048 blok aralıklıdır. Yükseklik Minecraft'ın -64…319 aralığıdır. Yetkisiz ada erişimi kapalıdır. Oyuncular gizlenir; `show-island-members: true` takım arkadaşlarını gösterir. Varsayılan takım 4 kişidir.

Başlangıç sandığı adanın içindedir: taş kazma, taş çapa, çalışma masası,16 ekmek, su, yedek fidan, tohumlar, havuç, patates, kemik tozu, toprak, kum, kamış, kaktüs, meşale ve rehber kitap. Sandığın gerçek envanteri kaydedilir; tekrar giriş sandığı doldurmaz. Eski adanın sahibi `/sb baslangic` ile bir kez taş kazma/çapa,8 ekmek ve 8 tohum alabilir. Yeni adanın sandığı varken bu ek destek verilmez.

Hazır jeneratör adanın içinde küçük, düz 3×3 çerçevedir. Ortası doğma merkezinden 2 blok doğu ve 1 blok kuzeydedir. **Lav yoktur.** Kırılan çekirdek bir sonraki oyun tikinde yenilenir;20 TPS'de yaklaşık 50 ms. İlk şanslar: %70 kırık taş, %10 kömür, %8 demir, %8 bakır, %4 lapis. İlerleyen beş seviyede bu üç maden korunur; üst cevherler eklenir. Oyuncunun yerleştirdiği cevher görev sayılmaz. `/sb jenerator` eski adada uygun boş 3×3 alan varsa dönüştürür; oyuncu yapısını zorla silmez. Değiştirilmemiş eski ek jeneratör tanınırsa kaldırılır; oyuncunun değiştirdiği alan korunur.

## İlk Yardım ve görevler

`/sb rehber` ve Usta Poyraz aynı kısa rehberi açar. Dokuz aşama: sandık → ağaç →32 jeneratör bloğu →16 ürün satışı → kendi adanda 8 olgun hasat → ilk iki madenci ödülü → üretici minyon → ekmek yüklenmiş Bakıcı → ileri hedefler. Tamamlanma gerçek işlemlerden hesaplanır; düğmeye basarak tamamlanmış gösterilmez. Her sayfanın Hedefi aç düğmesi ilgili menüye veya adaya götürür.

`/gorevler`: madencilik, tarım, balıkçılık, avcılık, yapı.40 görev vardır:32 kalıcı,4 günlük,4 haftalık. Açıklama, kalan miktar, ödül ve kilit durumu görünür. Hazır ödüle tıkla. İlk 32 blok 200 Altın, toplam 128 blok 300 Altın verir: ilk minyonun 500 Altını. **Görev ödülü ortak ada kasasına, satış parası kişisel cüzdana gider.** Ada kasası sağ panelde görünür. Ödül takım için bir kez verilir. Günlükler Türkiye saati 00.00, haftalıklar pazartesi 00.00 yenilenir. Alınmış eski ödüller korunur; yeni ilk ödül tutarı geriye dönük tekrar ödenmez.

`/sb teslim`:3 günlük,3 haftalık,3 aylık malzeme siparişi; eksikler parçalı verilir. Bir dönemin üçünü bitirmek %25 sözleşme Altını ve ek Mühür kazandırır. Günlük değişim bedeli 100 ada Altını; günde en fazla 3 değişim. Teslimatlar görev sayaçlarından ayrıdır.

Rehberi çağır/gizle: `/sb rehber yanima`, `/sb rehber kapat`, `/sb rehber ac`.

## Market ve kasaba tarlası

`/market`:9 kaynak kategorisi, **Çantamdaki ürünleri sat**, özel tezgâhlar ve hasat tarlası. Ürünler gerçek malzeme simgelerini kullanır. Alış yeşil, satış altın rengindedir. Ürün → adet → toplam → ONAYLA. Ürüne tekrar tıklamak+1; ±1/16/64 düğmeleri vardır. Adet seçmek ödeme yapmaz. Tam dolu çanta/yetersiz bakiye işlemi geri alır. Satış sadece normal, özel adı/verisi olmayan eşyaları tüketir. Kaynak marketi adası olmayan Skyblock oyuncusuna da açıktır.

Satış ekranı yalnız çantandaki satılabilir ürünleri gösterir. Özel tezgâhlardan minyon,12 tür spawner, oyuncu pazarı, VIP/Kredi, Mühür ödülleri ve VIP haklarına ulaşılır. VIP yıldız, uçuş elytra, minyon insan kafası ile gösterilir.

`/warp sb tarla`: olgun buğdayı biç;1 buğday doğrudan çantana gelir.20 saniyede yeniden olgunlaşır. Çanta doluysa ürün alınmaz. Su, toprak ve çevre korunur. **Çiftçi Efe** satış ekranını açar; normal buğday satışı 4 Altındır. Bu alan kendi ada tarım görevini ilerletmez. Görünür kasaba tabelaları havada TextDisplay yazılarıdır.

`/sb banka`: kişisel cüzdan ve ada kasası ayrıdır. Üye yatırabilir; yalnız sahip çekebilir. Oyuncu pazarı 5 ilan/24 saat, satış vergisi %5; alıcı/satıcı/emanet/eşya kayıtları aynı işlemde yazılır.

## Minyonlar

Küçük insan figürleri, oyuncu kafası, renkli kıyafet, meslek aracı ve havada durum yazısı. `/sb minyon` ile yönetilir. Taşçı/Oduncu/Çiftçi/Balıkçı üretir; **Bakıcı ekmek dağıtır**. Kurulum 500 ada Altını + türüne uygun 32 ürün; Bakıcı için 32 ekmek. Kurulum malzemesi depo veya enerji değildir.

Üreticiye 1 kömür veya 1 ekmek eklemek varsayılan 30 dakika enerji verir. Bakıcıya Besle ile ekmek yükle; ihtiyaç olan üreticiye gerçek ekmek tüketerek enerji aktarır. Yiyecek yokken ücretsiz üretim yoktur. Seviye 1/2/3 üretim 30/20/10 saniyedir. Depo 64×seviye×ada depo çarpanıdır. Depo dolunca yakıt/ekmek tüketimi durur. Çevrimdışı hesap tek seferde en fazla 6 saat; enerji ve kapasiteyle sınırlıdır. Kalıcı chunk yükleme yapılmaz.

Başlangıç 2 yuva, geliştirmeyle 6; üç minyon seviyesi ve üç ada depo seviyesi. Kaldırmadan önce depoyu topla; kalan enerji ayrıca onaylanarak silinir. Normal spawner/huni/yaratık sınırları 4/16/32'dir.

## Kişisel sandıklar

`/chest` menüsü veya `/chest 1`…`/chest 4`. Her sayfa 54 yuva; yalnız sahibi açar. Oyuncu 1, Gezgin/VIP 2, Usta/VIP+3, Mimar/VIP Ultra 4 sayfa. Ayar: `chests.pages-by-tier`; ek izinler `kasabaskyblock.chest.1`…`.4`. OP dört sayfayı açabilir. VIP bitince kilitli sayfanın eşyaları silinmez. Sandık hareketi, kişisel çanta ve imleç birlikte kalıcı kaydedilir. Skyblock dışındaki oyun çantalarıyla karışmaz.

## Ölüm, dönüş ve ada havası

**Skyblock oturumunda ölümde eşya ve deneyim korunur.** Lav dahil normal ölümlerde yere eşya/XP bırakılmaz; güvenli ada doğma noktasına dönülür. Boşluk kurtarması sürer. Bu düzeltme kurulmadan önce lavda yok olmuş ve kayıtta bulunmayan eşyaları kendiliğinden geri getirmez. Son ölüm profili yönetici incelemesi için tutulur; oyuncuya eşya çoğaltabilecek geri alma düğmesi verilmez.

Oyunlar menüsünden tekrar giriş, son kaydedilen **güvenli ve hâlâ izinli** Skyblock konumunu/yönünü geri yükler. Boşluk, lav, engellenmiş veya erişimi bitmiş ada konumu yerine güvenli doğma noktası kullanılır. Konum çanta işlemlerinden ayrı tutulur; normal çıkışta ve düzenli kayıtta korunur.

Ada sahibi `/sb set kar`, `/sb set yagmur`, `/sb set gunes` veya Skyblock içindeyken `/set kar|yagmur|gunes` kullanır; `/sb set` menüyü açar. Yalnız bu adadaki oyuncular aynı havayı görür. Diğer adalar ve dünya genelindeki hava değişmez. Kar için adanın dikey iklimi SNOWY_PLAINS; yağmur/güneş için PLAINS olur. İklim birkaç saniyede parça parça güncellenir. Ada sınırında biyomlar Minecraft'ın 4 blokluk çözünürlüğünü kullanır; komşu adalar 2048 blok uzaktadır. Bu görsel yerel yağıştır: kar biriktirme, buz oluşturma veya küresel fırtına başlatılmaz. Ayar kalıcıdır; adadan ayrılınca kişisel hava geri sıfırlanır.

Tavuklar yumurta bırakır; **Skyblock'ta atılan yumurtalardan civciv çıkmaz**. Skyblock ve ağ spawnında çağırma yumurtaları/çoğalma/dağıtıcı yumurtası kapalıdır; özel adada izinli hayvan çağırma yumurtası kullanılabilir.

## Arkadaşlar, yetkiler ve warp

`/sb davet Oyuncu` → `/sb kabul`: kalıcı takım. `/sb ziyaret davet|kabul|git|ayril|bitir` ve `/sb koop ...`: kişiye özel 30 dakikalık geçici erişim,60 saniyelik davet kabul süresi. En fazla 8 geçici erişim. `/sb ayarlar`: üye, ziyaretçi ve kooperatif için 17 ayrı yetki. Kasa çekme, geliştirme, spawner ve hava ayarı sahibe aittir.

`/warp sb lobi|market|gorev|atolye|muhur|vip|rehber|adalar|siralama|tarla|iskele`. `/spawn` Skyblock meydanına, `/lobi` ağın ana lobisine döner. `/sb ev` kendi adanın doğmasına gider. Sağ panel, hedef çubuğu ve TAB kısayolları vardır; `/sb panel kapat|ac` paneli yönetir.

## VIP, Kredi ve Mühür

Altın Skyblock parasıdır; Akçe ve Kredi ayrı tutulur. Kredi konsoldan `sb kredi ver Oyuncu miktar`; Mühür `sb muhur ver Oyuncu miktar`. VIP paketleri özgündür: Gezgin 120 Kredi/30 gün, Usta 220, Mimar 360; sırasıyla VIP/VIP+/VIP Ultra. Mühürlerle 7 günlük Gezgin ve başka ödüller alınabilir. Gerçek para ödeme sistemi bu paketin parçası değildir; mevcut mağaza başarılı ödeme sonrası konsol komutunu çalıştırabilir.

VIP satış bonusu %5/10/15; uçuş, süreli tamir/doyurma, sanal masalar ve günlük hediyeler. `/sb vip`, `/sb ucus`, `/sb tamir`, `/sb tamir hepsi`, `/sb doyur`, `/sb vipgunluk`. `/ucushizi 1–10` veya `/sb ucus hiz`; OP her yerde ayarlayabilir. OP uçuş hızı uçuş hakkını tek başına değiştirmez.

Evcil: `/evcil`, `/evcil kapat` veya `/evcil gizle`, `/evcil ac` veya `/evcil goster`. Son sahip olunan seçimi hatırlar; tekrar göstermek satın alma değildir. Hem sunucu çarpışması hem istemci scoreboard çarpışması kapalıdır. Maçlarda gizlenir. Akçe ile evcil satın alma Skyblock Kredisinden ayrıdır.

## OP testi ve bakım

**`/sb test ac`**: kendi adası olan OP için isteğe bağlı test. Normal market alışları, minyon kurma/besleme/yükseltme, spawner ve ada geliştirmeleri ücretsiz; malzeme ve ada seviyesi aranmaz. Tamir/doyurma/günlük hediye beklemeleri test boyunca uygulanmaz ve normal bekleme kaydını tüketmez. En üst VIP kolaylıkları test boyunca açıktır; hesaba gerçek kalıcı VIP paketi yazılmaz. Mühür/Kredi kaynak tezgâhlarında bakiye harcanmaz. Gerçek oyuncu pazarındaki başkasının ilanı bedava alınmaz. Sahiplik, ada erişimi, doğma koruması ve üretim kapasitesi sınırları sürer. Spawn yumurtası yasağı OP testinde de geçerlidir.

`/sb test kapat` normal kuralları geri getirir. Test eşyaları ve yapılan ada geliştirmeleri kalır; bu bir geri alma komutu değildir. OP kaldırılınca ayrıcalıklar anında etkisizdir. Öncü test modu kullanamaz. Ana menüde OP test düğmesi ve panelde açık durumu görünür.

Öncü rolü (`/rol ver Oyuncu oncu`) ve beta destekçisi (`/beta ver Oyuncu`) bakımdaki **çalışır** oyunlara girebilir. Bakım kapatma, rol yönetimi, harita düzenleme veya OP verilmez. Rol/rozet kaldırılınca yeni bakım giriş hakkı da kalkar. İzin düğümü: `kasabahub.maintenance.bypass`.

OP/yönetici ada oluştururken 24 saat beklemez. `/sb OyuncuAdı 24 saatkaldir` yalnız ada kurma beklemesini kaldırır; konsol/OP/yönetici kullanır, çevrimdışı bilinen hedef de olur. `/yonet duzenleme ac` OP'nin bulunduğu Skyblock alanını düzenler; test modu farklı bir ayardır.

## Kurulum, kayıt ve doğrulama

Sunucuyu durdurarak dünya+`plugins/KasabaSkyblock`+Roles+Evcil veri klasörlerini birlikte yedekle. SQLite WAL yan dosyalarını çalışırken ayrı kopyalama. Veri klasörlerini/dünyaları silmeden yeni dört JAR'ı değiştir; aynı eklentinin eski JAR'ı kalmasın. `/reload` kullanma. `skyblock.db` para, adalar, görevler, minyonlar, sandıklar, profiller ve hava ayarlarını içerir. `ada`/KasabaAdalar ayrı oyundur. Towny/Sikke/Vault/Chunky eklenmez.

Paketin TEST-SONUCLARI.json dosyasında yeni derleme ve yerel Paper testleri, tarihsel testlerden ayrıdır. Özel audit adaptörleri ve test oyuncu verileri dağıtılmaz. Erişilebilen referans video kareleri ve açık kaynak mekanik belgeleri incelendi; Google/YouTube erişimi engelliyken 10 güncel video izlendiği iddia edilmez. Araştırma notları pakettedir.
