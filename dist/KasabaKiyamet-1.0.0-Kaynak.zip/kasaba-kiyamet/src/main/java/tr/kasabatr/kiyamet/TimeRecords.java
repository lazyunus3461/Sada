package tr.kasabatr.kiyamet;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** One personal best per player and difficulty. Shorter durations rank first. */
final class TimeRecords {
    record Key(UUID player,Difficulty difficulty){}
    record Entry(UUID player,String name,Difficulty difficulty,long millis,long achieved){
        Entry{if(player==null||name==null||!name.matches("[A-Za-z0-9_]{1,16}")||difficulty==null||millis<1||millis>604800000||achieved<0)throw new IllegalArgumentException("Geçersiz parkur süresi.");}
    }
    record Snapshot(int schema,List<Entry> records){}
    record Result(Entry best,int rank,boolean improved){}
    private final Path file;private final Gson gson=new GsonBuilder().setPrettyPrinting().create();
    private Map<Key,Entry> entries=Map.of();
    TimeRecords(Path file){this.file=file;}
    void load()throws IOException{
        if(!Files.exists(file))return;
        try(var reader=Files.newBufferedReader(file,StandardCharsets.UTF_8)){
            Snapshot data=gson.fromJson(reader,Snapshot.class);if(data==null||data.schema!=1||data.records==null)throw new IllegalArgumentException();
            Map<Key,Entry> next=new HashMap<>();for(Entry e:data.records){if(e==null||next.put(new Key(e.player,e.difficulty),e)!=null)throw new IllegalArgumentException();}entries=Map.copyOf(next);
        }catch(RuntimeException e){throw new IOException("Süre rekorları okunamadı; eski dosya korundu.",e);}
    }
    Entry best(UUID player,Difficulty difficulty){return entries.get(new Key(player,difficulty));}
    List<Entry> top(Difficulty difficulty){return sorted(difficulty).stream().limit(5).toList();}
    private List<Entry> sorted(Difficulty difficulty){return entries.values().stream().filter(e->e.difficulty==difficulty).sorted(Comparator.comparingLong(Entry::millis).thenComparingLong(Entry::achieved).thenComparing(e->e.player.toString())).toList();}
    Result record(UUID player,String name,Difficulty difficulty,long millis,long now)throws IOException{
        Entry attempt=new Entry(player,name,difficulty,millis,now);Key key=new Key(player,difficulty);Entry old=entries.get(key);boolean improved=old==null||millis<old.millis;
        Entry best=improved?attempt:new Entry(player,name,difficulty,old.millis,old.achieved);
        if(!best.equals(old)){
            Map<Key,Entry> next=new HashMap<>(entries);next.put(key,best);commit(next);entries=Map.copyOf(next);
        }
        List<Entry> ranks=sorted(difficulty);return new Result(best,ranks.indexOf(best)+1,improved);
    }
    private void commit(Map<Key,Entry> next)throws IOException{
        Files.createDirectories(file.toAbsolutePath().getParent());Path temp=Files.createTempFile(file.toAbsolutePath().getParent(),".parkur-time-",".tmp");
        try{
            try(var writer=Files.newBufferedWriter(temp,StandardCharsets.UTF_8)){gson.toJson(new Snapshot(1,next.values().stream().sorted(Comparator.comparing((Entry e)->e.player.toString()).thenComparing(e->e.difficulty.ordinal())).toList()),writer);}
            try{Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(temp);}
    }
    static String format(long millis){millis=Math.max(0,millis);long minutes=millis/60000,seconds=millis/1000%60;return String.format(Locale.ROOT,"%d dk %02d,%03d sn",minutes,seconds,millis%1000);}
}
