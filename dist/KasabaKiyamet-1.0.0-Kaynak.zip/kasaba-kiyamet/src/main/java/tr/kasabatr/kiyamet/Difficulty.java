package tr.kasabatr.kiyamet;
enum Difficulty {
 ASIRI("Aşırı Zor", "§c");
 final String title,color;
 Difficulty(String title,String color){this.title=title;this.color=color;}
 String id(){return "asiri";}
 static Difficulty parse(String value){if(java.util.Set.of("asiri","aşırı","kiyamet","kıyamet","zor").contains(value.toLowerCase(java.util.Locale.ROOT)))return ASIRI;throw new IllegalArgumentException("Tek rota: aşırı zor.");}
}
