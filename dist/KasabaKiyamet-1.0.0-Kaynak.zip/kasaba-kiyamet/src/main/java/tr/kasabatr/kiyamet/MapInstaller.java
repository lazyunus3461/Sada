package tr.kasabatr.kiyamet;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
final class MapInstaller {
    static void ensure(Plugin plugin,String name)throws IOException{
        if(name==null||!name.matches("[A-Za-z0-9_-]{1,64}"))throw new IOException("Geçersiz parkur dünya adı.");
        Path root=Bukkit.getWorldContainer().toPath().toAbsolutePath().normalize(),target=root.resolve(name);
        if(Files.exists(target)){
            if(!Files.isRegularFile(target.resolve("level.dat"))||!Files.isRegularFile(target.resolve("parkur-layout.json")))throw new IOException("Mevcut dünya başka bir haritaya ait veya eksik; üzerine yazılmadı: "+name);
            try(InputStream in=Files.newInputStream(target.resolve("parkur-layout.json"))){new CourseMap(in);}return;
        }
        Path stage=root.resolve(".kasaba-kiyamet-install-"+UUID.randomUUID());Files.createDirectory(stage);
        try{
            InputStream resource=plugin.getResource("parkur-world.zip");if(resource==null)throw new IOException("Hazır parkur haritası JAR'da bulunamadı.");
            try(ZipInputStream zip=new ZipInputStream(resource)){ZipEntry entry;long size=0;int files=0;byte[] buffer=new byte[32768];while((entry=zip.getNextEntry())!=null){
                Path out=stage.resolve(entry.getName()).normalize();if(!out.startsWith(stage)||entry.getName().contains("\\")||++files>1000)throw new IOException("Geçersiz dünya arşivi.");
                if(entry.isDirectory()){Files.createDirectories(out);continue;}Files.createDirectories(out.getParent());try(OutputStream stream=Files.newOutputStream(out)){int count;while((count=zip.read(buffer))!=-1){size+=count;if(size>128L*1024*1024)throw new IOException("Harita arşivi çok büyük.");stream.write(buffer,0,count);}}
            }}
            if(!Files.isRegularFile(stage.resolve("level.dat"))||!Files.isRegularFile(stage.resolve("parkur-layout.json")))throw new IOException("Dünya arşivi eksik.");
            try{Files.move(stage,target,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(stage,target);}
        }finally{if(Files.exists(stage))try(var paths=Files.walk(stage)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
    }
}
