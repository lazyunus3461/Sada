package tr.kasabatr.kiyamet;

import java.util.*;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;
import tr.kasaba.hub.api.MenuStyle;

final class KiyametHud {
  record State(Scoreboard previous, Scoreboard board, Objective objective) {}

  private final KasabaKiyametPlugin plugin;
  private final Map<UUID, State> states = new HashMap<>();

  KiyametHud(KasabaKiyametPlugin p) {
    plugin = p;
  }

  void update(Player p, KasabaKiyametPlugin.Run run) {
    State state =
        states.computeIfAbsent(
            p.getUniqueId(),
            id -> {
              Scoreboard old = p.getScoreboard(),
                  board = Bukkit.getScoreboardManager().getNewScoreboard();
              for (Team t : old.getTeams())
                if (!t.getName().matches("kr[0-9a-f]{14}")) {
                  Team n = board.registerNewTeam(t.getName());
                  n.prefix(t.prefix());
                  n.suffix(t.suffix());
                  if(t.hasColor()) n.setColor(t.getColor());
                  for (Team.Option option : Team.Option.values())
                    n.setOption(option, t.getOption(option));
                  n.setAllowFriendlyFire(t.allowFriendlyFire());
                  n.setCanSeeFriendlyInvisibles(t.canSeeFriendlyInvisibles());
                  for (String e : t.getEntries()) n.addEntry(e);
                }
              Objective objective =
                  board.registerNewObjective(
                      "kiyamet_live", Criteria.DUMMY, MenuStyle.line("§6§lKASABA §8• §cKIYAMET"));
              objective.setDisplaySlot(DisplaySlot.SIDEBAR);
              objective.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.blank());
              return new State(old, board, objective);
            });
    if (p.getScoreboard() != state.board()) p.setScoreboard(state.board());
    for (String e : state.board().getEntries()) state.board().resetScores(e);
    List<String> lines = new ArrayList<>();
    lines.add("§7CANLI İLERLEME");
    if (run.difficulty == null) {
      lines.add("§c48 aşırı zor bölüm");
      lines.add("§7Kapıdan rota seç.");
      lines.add(" ");
      for (Difficulty d : Difficulty.values()) {
        var top = plugin.live(d);
        lines.add(d.color + d.title + " §7lideri:");
        lines.add(
            top.isEmpty()
                ? "§8Henüz yarışan yok"
                : "§f" + top.getFirst().name() + " §a%" + (int) top.getFirst().progress());
      }
      lines.add("  ");
      lines.add("§e/kiyamet ilk5");
    } else {
      lines.add(
          run.difficulty.color
              + run.difficulty.title
              + " §8• §fBölüm "
              + Math.min(CourseMap.STAGES, run.checkpoint + 1));
      lines.add(
          "§bİlerlemen: %"
              + (int)
                  LiveProgress.position(
                      plugin.map.route(run.difficulty), run.checkpoint, run.gate));
      lines.add(" ");
      var top = plugin.live(run.difficulty);
      for (int i = 0; i < 5; i++)
        lines.add(
            "§e"
                + (i + 1)
                + ". "
                + (i < top.size()
                    ? "§f" + top.get(i).name() + " §a%" + (int) top.get(i).progress()
                    : "§8—"));
      lines.add("  ");
      lines.add(
          run.practice
              ? "§dDeneme • sıralama dışı"
              : run.assisted ? "§cYardımlı • sıralama dışı" : "§7Saniyede yenilenir");
      lines.add("§e/kiyamet süreler");
    }
    int score = lines.size();
    for (String line : lines) {
      Score row=state.objective().getScore(line);
      row.customName(MenuStyle.line(line));
      row.setScore(score--);
    }
  }

  void remove(Player p) {
    State state = states.remove(p.getUniqueId());
    if (state != null && p.getScoreboard() == state.board()) p.setScoreboard(state.previous());
  }
}
