package tr.kasabatr.kiyamet;
import java.util.*;
final class LiveProgress {
 record Entry(UUID player,String name,double progress){}
 static double position(CourseMap.Route route,int section,int gate){
  if(section>=route.stages().size())return 100;
  if(section<0)return 0;
  int size=route.stages().get(section).gates().size();
  return Math.clamp((section+Math.clamp((double)gate/size,0,1))/route.stages().size()*100,0,100);
 }
 static List<Entry> top(Collection<Entry> entries){return entries.stream().sorted(Comparator.comparingDouble(Entry::progress).reversed().thenComparing(Entry::name).thenComparing(x->x.player.toString())).limit(5).toList();}
}
