package tr.kasabatr.kiyamet;
/** Tick-based visible falling, with each stage's lowest intended platform as the datum. */
final class DropPolicy {
    private final double depth;private final long delay;private long started=-1;
    DropPolicy(double depth,long delay){if(depth<6||depth>20||delay<6||delay>40)throw new IllegalArgumentException();this.depth=depth;this.delay=delay;}
    void clear(){started=-1;}
    boolean falling(){return started>=0;}
    boolean update(long tick,double y,double floor,boolean landed){
        if(y>=floor-2){clear();return false;}
        if(y<floor-3&&started<0)started=tick;
        return started>=0&&tick-started>=delay&&(y<=floor-depth||(landed&&y<floor-3));
    }
}
