package tr.kasabatr.kiyamet;

/** A monotonic clock belongs to a single uninterrupted attempt. */
final class TrialTimer {
    private long start;private boolean finished,invalid;private long result;
    void restart(long now){start=now;finished=false;invalid=false;result=0;}
    void invalidate(){invalid=true;}
    boolean valid(){return !invalid;}
    boolean finished(){return finished;}
    long elapsed(long now){return finished?result:Math.max(0,(now-start)/1000000);}
    long finish(long now){if(invalid||finished)throw new IllegalStateException("Bu deneme süre sıralamasına yazılamaz.");result=Math.max(1,elapsed(now));finished=true;return result;}
}
