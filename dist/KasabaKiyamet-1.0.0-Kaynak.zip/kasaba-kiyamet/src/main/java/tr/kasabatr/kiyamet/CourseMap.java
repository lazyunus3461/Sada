package tr.kasabatr.kiyamet;

import com.google.gson.Gson;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.bukkit.*;

final class CourseMap {
 static final int STAGES=48;
 record Point(double x,double y,double z,float yaw){
  Location at(World world){return new Location(world,x,y,z,yaw,0);}
  void validate(){if(!Double.isFinite(x+y+z)||Math.abs(x)>2048||Math.abs(z)>2048||y<0||y>290)throw new IllegalArgumentException("Geçersiz parkur noktası.");}
 }
 record Gate(double x,double y,double z,double radius,boolean grounded){
  boolean contains(Location at,boolean ground){return (!grounded||ground)&&Math.abs(at.getY()-y)<(grounded?.22:1.1)&&Math.pow(at.getX()-x,2)+Math.pow(at.getZ()-z,2)<=radius*radius;}
 }
 record Stage(String name,String instruction,double floor,List<Gate> gates,String kind){}
 record Route(List<Point> checkpoints,List<Stage> stages){}
 record Portal(String difficulty,double x,double y,double z){}
 record Data(int schema,String world,Point lobby,List<Portal> portals,Map<String,Route> routes){}
 record Progress(int section,int gate,boolean advanced){}
 final Data data;
 CourseMap(InputStream input)throws IOException{
  try(var reader=new InputStreamReader(Objects.requireNonNull(input),StandardCharsets.UTF_8)){data=new Gson().fromJson(reader,Data.class);validate();}
  catch(RuntimeException bad){throw new IOException("Kıyamet rota verisi okunamadı.",bad);}
 }
 Route route(Difficulty difficulty){return data.routes.get(difficulty.id());}
 Progress advance(int section,int gate,Location at,boolean supported){
  if(section<0||section>STAGES)throw new IllegalArgumentException("Geçersiz bölüm.");
  if(section==STAGES)return new Progress(STAGES,0,false);
  var route=route(Difficulty.ASIRI);var stage=route.stages.get(section);
  if(gate<0||gate>stage.gates.size())throw new IllegalArgumentException("Geçersiz geçiş.");
  if(gate<stage.gates.size()&&stage.gates.get(gate).contains(at,supported))gate++;
  var end=route.checkpoints.get(section+1);
  if(supported&&gate==stage.gates.size()&&Math.abs(at.getY()-end.y)<.3
      &&Math.pow(at.getX()-end.x,2)+Math.pow(at.getZ()-end.z,2)<4)
    return new Progress(section+1,0,true);
  return new Progress(section,gate,false);
 }
 void validate(){
  if(data==null||data.schema!=2||data.world==null||!data.world.matches("[a-z0-9_-]{1,64}")||data.routes==null||data.routes.size()!=1||data.portals==null||data.portals.size()!=1||data.lobby==null)throw new IllegalArgumentException("Harita bilgisi eksik.");
  data.lobby.validate();var r=Objects.requireNonNull(route(Difficulty.ASIRI));
  if(r.checkpoints==null||r.stages==null||r.checkpoints.size()!=STAGES+1||r.stages.size()!=STAGES)throw new IllegalArgumentException("48 bölüm ve 49 bağlantı noktası gerekli.");
  r.checkpoints.forEach(Point::validate);
  for(var stage:r.stages){
   if(stage==null||stage.name==null||stage.name.isBlank()||stage.instruction==null||stage.kind==null||stage.gates==null||stage.gates.size()<3||stage.gates.size()>20||!Double.isFinite(stage.floor))throw new IllegalArgumentException("Bölüm bilgisi eksik.");
   for(var g:stage.gates)if(g==null||!Double.isFinite(g.x+g.y+g.z)||g.radius<.45||g.radius>2)throw new IllegalArgumentException("Geçiş bilgisi geçersiz.");
  }
 }
}
