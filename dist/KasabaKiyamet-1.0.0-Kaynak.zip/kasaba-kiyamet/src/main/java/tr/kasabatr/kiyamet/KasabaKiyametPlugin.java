package tr.kasabatr.kiyamet;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.boss.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import tr.kasaba.auth.api.*;
import tr.kasaba.hub.api.*;

/** Ordered extreme course. Every normal attempt starts at the beginning. */
public final class KasabaKiyametPlugin extends JavaPlugin implements HubGame, Listener, TabExecutor {
  static final String ID = "kiyamet";

  static final class Run {
    Difficulty difficulty;
    int checkpoint;
    int gate;
    boolean practice, assisted;
    long lastReturn, finishedMillis = -1;
    BossBar bar;
    final TrialTimer timer = new TrialTimer();
    final DropPolicy drop;

    Run(double depth, long delay) {
      drop = new DropPolicy(depth, delay);
    }
  }

  final Map<UUID, Run> visitors = new LinkedHashMap<>();
  final Set<UUID> transit = new HashSet<>(), quitting = new HashSet<>(), editors = new HashSet<>();
  final List<TextDisplay> labels = new ArrayList<>();
  final Map<Difficulty, TextDisplay> timeBoards = new EnumMap<>(Difficulty.class);
  KiyametHud hud;
  final Map<Difficulty, TextDisplay> liveBoards = new EnumMap<>(Difficulty.class);
  HubApi hub;
  World world;
  CourseMap map;
  TimeRecords records;
  GameScreens screens;
  NamespacedKey toolKey;
  boolean stopping, storageFailed;
  long ticks;

  @Override
  public void onEnable() {
    saveDefaultConfig();
    hud = new KiyametHud(this);
    toolKey = new NamespacedKey(this, "kiyamet-tool");
    screens = new GameScreens(this);
    try {
      String name = getConfig().getString("world", "kasaba_kiyamet_v1");
      MapInstaller.ensure(this, name);
      try (InputStream in =
          Files.newInputStream(
              Bukkit.getWorldContainer().toPath().resolve(name).resolve("parkur-layout.json"))) {
        map = new CourseMap(in);
      }
      world = Bukkit.getWorld(name);
      if (world == null)
        world =
            new WorldCreator(name)
                .generator(new EmptyWorldGenerator())
                .generateStructures(false)
                .createWorld();
      if (world == null) throw new IOException("Parkur dünyası yüklenemedi.");
      world.setTime(18000);
      world.setStorm(false);
      world.setThundering(false);
      world.setPVP(false);
      world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
      world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
      world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
      world.setGameRule(GameRule.DO_FIRE_TICK, false);
      world.setGameRule(GameRule.RANDOM_TICK_SPEED, 0);
      world.setSpawnLocation(lobbyPoint());
      new MultiverseBridge(this).register(world, lobbyPoint());
      records = new TimeRecords(getDataFolder().toPath().resolve("sure-rekorlari-v1.json"));
      records.load();
      hub = Objects.requireNonNull(Bukkit.getServicesManager().load(HubApi.class));
      hub.register(this, this);
      Bukkit.getPluginManager().registerEvents(this, this);
      Objects.requireNonNull(getCommand("kiyamet")).setTabCompleter(this);
      Bukkit.getScheduler().runTaskTimer(this, this::tick, 1, 1);
      Bukkit.getScheduler().runTaskLater(this, this::labels, 2);
      for (Player p : Bukkit.getOnlinePlayers()) recover(p);
    } catch (Exception e) {
      getLogger().log(Level.SEVERE, "Parkur açılamadı; mevcut dünya ve kayıtlar korundu.", e);
      Bukkit.getPluginManager().disablePlugin(this);
    }
  }

  @Override
  public void onDisable() {
    stopping = true;
    for (UUID id : List.copyOf(visitors.keySet())) leave(id);
    labels.forEach(Entity::remove);
    labels.clear();
    timeBoards.clear();
    liveBoards.clear();
    if (world != null) world.removePluginChunkTickets(this);
    if (hub != null) hub.unregister(this, ID);
  }

  @Override
  public ChunkGenerator getDefaultWorldGenerator(String name, String id) {
    return new EmptyWorldGenerator();
  }

  @Override
  public GameInfo info() {
    return new GameInfo(
        ID, "Kıyamet Parkuru", "48 aşırı zor bölüm • Zorunlu geçişler • Düşünce en baştan", 1, 20);
  }

  @Override
  public boolean available() {
    return world != null && records != null && !storageFailed && !stopping;
  }

  @Override
  public boolean lobby(UUID id) {
    Run r = visitors.get(id);
    return r != null && r.difficulty == null;
  }

  @Override
  public boolean spatialActivity(UUID id) {
    Run r = visitors.get(id);
    return r != null && r.difficulty != null;
  }

  @Override
  public boolean containsMatch(UUID id, Location at) {
    return at != null && at.getWorld() == world;
  }

  @Override public boolean editingAllowed(UUID id,World at) { Player p=Bukkit.getPlayer(id);return p!=null&&admin(p)&&at==world; }
  @Override public void editingChanged(UUID id,boolean enabled) { Run run=visitors.get(id);if(run!=null){run.assisted=true;run.timer.invalidate();} }

  boolean auth(Player p) {
    AuthState a = Bukkit.getServicesManager().load(AuthState.class);
    return p.isOnline() && a != null && a.authenticated(p.getUniqueId());
  }

  void ready(Player p) {
    if (!auth(p) || !visitors.containsKey(p.getUniqueId()))
      throw new IllegalArgumentException("Önce /kiyamet ile parkur lobisine gir.");
    if (storageFailed)
      throw new IllegalArgumentException("İlerleme kaydı açılamadı; yöneticiye haber ver.");
    GameAccessGuard guard = Bukkit.getServicesManager().load(GameAccessGuard.class);
    if (guard != null && guard.blocked(p.getUniqueId()))
      throw new IllegalArgumentException(guard.message(p.getUniqueId()));
  }

  boolean admin(Player p) {
    return p.isOp()
        || p.hasPermission("kasaba.kiyamet.admin")
        || p.hasPermission("kasabaroles.admin");
  }

  void tell(CommandSender p, String text) {
    p.sendMessage("§6[Kıyamet] §f" + text);
  }

  Location lobbyPoint() {
    return map.data.lobby().at(world);
  }

  Location checkpoint(Run r) {
    return r.difficulty == null
        ? lobbyPoint()
        : map.route(r.difficulty).checkpoints().get(r.checkpoint).at(world);
  }

  boolean protectedAt(Location at) {
    return world != null && at != null && at.getWorld() == world;
  }

  /** Collision boxes, not the client onGround flag alone; also handles fences/trapdoors. */
  boolean supported(Player p) {
    if(!p.isOnGround()) return false;
    var at=p.getLocation();double y=at.getY();
    for(int x=(int)Math.floor(at.getX()-.299);x<=Math.floor(at.getX()+.299);x++)
      for(int z=(int)Math.floor(at.getZ()-.299);z<=Math.floor(at.getZ()+.299);z++)
        for(int by=(int)Math.floor(y)-2;by<=Math.floor(y);by++) {
          var block=world.getBlockAt(x,by,z);
          for(var box:block.getCollisionShape().getBoundingBoxes()) {
            if(Math.abs(by+box.getMaxY()-y)>.12)continue;
            if(at.getX()+.299>x+box.getMinX()&&at.getX()-.299<x+box.getMaxX()
                &&at.getZ()+.299>z+box.getMinZ()&&at.getZ()-.299<z+box.getMaxZ())return true;
          }
        }
    return false;
  }

  boolean editing(Player p) {
    return (admin(p) && editors.contains(p.getUniqueId())) || AdminAccess.editing(p);
  }

  void teleport(Player p, Location to) {
    transit.add(p.getUniqueId());
    try {
      if (p.isInsideVehicle()) p.leaveVehicle();
      if (!p.teleport(to, PlayerTeleportEvent.TeleportCause.PLUGIN))
        throw new IllegalStateException("Parkur ışınlanması engellendi.");
      p.setFallDistance(0);
      p.setVelocity(new org.bukkit.util.Vector());
    } finally {
      transit.remove(p.getUniqueId());
    }
  }

  @Override
  public boolean join(List<Player> team) {
    if (!available() || team.isEmpty() || team.size() > 20) return false;
    for (Player p : team)
      if (!auth(p)
          || !p.hasPermission("kasaba.kiyamet.play")
          || visitors.containsKey(p.getUniqueId())
          || PlayerBackup.exists(getDataFolder(), p.getUniqueId())) return false;
    List<Player> prepared = new ArrayList<>();
    try {
      for (Player p : team) {
        p.closeInventory();
        PlayerBackup.save(getDataFolder(), p);
        prepared.add(p);
        Run r =
            new Run(
                Math.clamp(getConfig().getDouble("fall-distance-blocks", 8), 6, 20),
                Math.clamp(getConfig().getLong("fall-delay-ticks", 10), 6, 40));
        visitors.put(p.getUniqueId(), r);
        prepare(p);
        teleport(p, lobbyPoint());
        tell(p, "Kıyamet lobisi • 48 aşırı zor bölüm. Pusuladan başla veya kızıl kapıdan geç.");
      }
      return true;
    } catch (Exception e) {
      getLogger().log(Level.WARNING, "Parkur grup girişi geri alındı.", e);
      for (Player p : prepared) {
        visitors.remove(p.getUniqueId());
        try {
          transit.add(p.getUniqueId());
          PlayerBackup.restore(getDataFolder(), p, true);
        } catch (Exception problem) {
          getLogger().log(Level.SEVERE, "Parkur yedeği korundu.", problem);
        } finally {
          transit.remove(p.getUniqueId());
        }
      }
      return false;
    }
  }

  void prepare(Player p) {
    if (NetworkFeatures.get() != null) NetworkFeatures.get().beforeGame(p);
    p.closeDialog();
    p.closeInventory();
    p.setItemOnCursor(null);
    p.getInventory().clear();
    p.getInventory().setArmorContents(new ItemStack[4]);
    p.getInventory().setItemInOffHand(null);
    for (var effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
    p.setGameMode(GameMode.ADVENTURE);
    p.setFlying(false);
    p.setAllowFlight(false);
    p.setWalkSpeed(.2f);
    p.setFlySpeed(.1f);
    p.setGravity(true);
    p.setInvulnerable(false);
    p.setCollidable(false);
    p.setAbsorptionAmount(0);
    p.setFireTicks(0);
    p.setFoodLevel(20);
    p.setSaturation(20);
    p.setExhaustion(0);
    p.setTotalExperience(0);
    p.setLevel(0);
    p.setExp(0);
    if (!p.isDead()) p.setHealth(Math.min(20, p.getMaxHealth()));
    tools(p);
  }

  void tools(Player p) {
    p.getInventory().setItem(8, item(Material.COMPASS, "§cKıyamet • Menü / Lobi", 1));
    p.getInventory().setItem(7, item(Material.RED_DYE, "§eRotaya baştan başla", 2));
    p.getInventory().setItem(6, item(Material.BOOK, "§6Canlı ilerleme • İlk 5", 3));
  }

  ItemStack item(Material material, String name, int code) {
    ItemStack item = new ItemStack(material);
    var meta = item.getItemMeta();
    meta.setDisplayName(name);
    meta.getPersistentDataContainer().set(toolKey, PersistentDataType.INTEGER, code);
    item.setItemMeta(meta);
    return item;
  }

  int tool(ItemStack item) {
    return item == null || !item.hasItemMeta()
        ? 0
        : item.getItemMeta()
            .getPersistentDataContainer()
            .getOrDefault(toolKey, PersistentDataType.INTEGER, 0);
  }

  @Override
  public void leave(UUID id) {
    Run r = visitors.remove(id);
    editors.remove(id);
    screens.clear(id);
    if (r == null) return;
    if (r.bar != null) r.bar.removeAll();
    Player p = Bukkit.getPlayer(id);
    if (p != null) hud.remove(p);
    if (p == null || quitting.contains(id)) return;
    p.closeDialog();
    try {
      transit.add(id);
      PlayerBackup.restore(getDataFolder(), p, stopping && !hub.transferring(id));
    } catch (Exception e) {
      getLogger().log(Level.SEVERE, "Parkur eşya yedeği korundu.", e);
      p.kick(Component.text("Parkur envanter yedeğin korunuyor; yöneticiye haber ver."));
    } finally {
      transit.remove(id);
    }
  }

  void recover(Player p) {
    if (!auth(p)
        || visitors.containsKey(p.getUniqueId())
        || !PlayerBackup.exists(getDataFolder(), p.getUniqueId())) return;
    try {
      transit.add(p.getUniqueId());
      PlayerBackup.restore(getDataFolder(), p, true);
    } catch (Exception e) {
      getLogger().log(Level.SEVERE, "Parkur kurtarma yedeği korundu.", e);
      p.kick(Component.text("Parkur envanter kaydın korunuyor."));
    } finally {
      transit.remove(p.getUniqueId());
    }
  }

  void enter(Player p) {
    if (visitors.containsKey(p.getUniqueId())) return;
    if (!auth(p)) throw new IllegalArgumentException("Önce hesabına giriş yap.");
    hub.enterGame(p.getUniqueId(), ID);
    ready(p);
  }

  void start(Player p, Difficulty difficulty, boolean practice, int selected) {
    ready(p);
    if (selected > 0 && !practice)
      throw new IllegalArgumentException("Süre yarışı rotanın en başından başlar.");
    int cp = practice ? Math.max(0, selected) : 0;
    if (cp >= CourseMap.STAGES) throw new IllegalArgumentException("Bölüm 1–48 olmalı.");
    Run r = visitors.get(p.getUniqueId());
    screens.clear(p.getUniqueId());
    p.closeDialog();
    if (r.bar != null) r.bar.removeAll();
    editors.remove(p.getUniqueId());
    r.difficulty = difficulty;
    r.practice = practice;
    r.checkpoint = cp;
    r.gate = 0;
    r.assisted = false;
    r.finishedMillis = -1;
    r.drop.clear();
    prepare(p);
    teleport(p, checkpoint(r));
    r.timer.restart(System.nanoTime());
    if (practice) r.timer.invalidate();
    r.bar =
        Bukkit.createBossBar(
            "Kıyamet Parkuru",
            BarColor.RED,
            BarStyle.SEGMENTED_10);
    r.bar.addPlayer(p);
    update(p, r);
    tell(
        p,
        difficulty.color
            + difficulty.title
            + " §f• Süre başladı!"
            + (practice
                ? " §dDeneme; sıralamaya yazılmaz."
                : " Düşersen rotanın başına dönersin."));
  }

  void gameLobby(Player p) {
    ready(p);
    Run r = visitors.get(p.getUniqueId());
    if (r.bar != null) {
      r.bar.removeAll();
      r.bar = null;
    }
    r.difficulty = null;
    r.practice = false;
    r.assisted = false;
    r.finishedMillis = -1;
    r.timer.invalidate();
    r.drop.clear();
    editors.remove(p.getUniqueId());
    screens.clear(p.getUniqueId());
    prepare(p);
    teleport(p, lobbyPoint());
  }

  void reset(Player p, Run r) {
    if (ticks - r.lastReturn < 10) return;
    r.lastReturn = ticks;
    r.drop.clear();
    r.checkpoint = 0;
    r.gate = 0;
    r.assisted = false;
    r.finishedMillis = -1;
    prepare(p);
    teleport(p, checkpoint(r));
    r.timer.restart(System.nanoTime());
    if (r.practice) r.timer.invalidate();
    tell(
        p,
        r.difficulty == null
            ? "Parkur lobisine döndün."
            : "Rotanın başına döndün. Kronometre yeniden başladı.");
    if (r.bar != null) update(p, r);
  }

  void update(Player p, Run r) {
    if (r.bar == null) return;
    long elapsed = r.finishedMillis >= 0 ? r.finishedMillis : r.timer.elapsed(System.nanoTime());
    r.bar.setTitle(
        r.difficulty.color
            + r.difficulty.title
            + " §f• §e"
            + TimeRecords.format(elapsed)
            + " §7• "
            + (r.checkpoint == CourseMap.STAGES ? "Tamamlandı" : ("Bölüm " + (r.checkpoint + 1) + "/48 • Geçiş " + r.gate + "/" + map.route(r.difficulty).stages().get(r.checkpoint).gates().size()))
            + (r.practice ? " §dDENEME" : r.assisted ? " §cGEÇERSİZ DENEME" : ""));
    r.bar.setProgress(r.checkpoint / (double)CourseMap.STAGES);
  }

  void finish(Player p, Run r) {
    long elapsed = Math.max(1, r.timer.elapsed(System.nanoTime()));
    r.checkpoint = CourseMap.STAGES;
    r.finishedMillis = elapsed;
    r.drop.clear();
    if (r.practice || r.assisted || !r.timer.valid()) {
      tell(
          p,
          "Deneme tamamlandı: " + TimeRecords.format(elapsed) + " • Süre sıralamasına yazılmadı.");
      update(p, r);
      return;
    }
    try {
      elapsed = r.timer.finish(System.nanoTime());
      r.finishedMillis = elapsed;
      var result =
          records.record(
              p.getUniqueId(), p.getName(), r.difficulty, elapsed, System.currentTimeMillis());
      p.showTitle(
          net.kyori.adventure.title.Title.title(
              MenuStyle.line("§aParkur tamamlandı!"),
              MenuStyle.line(
                  "§e" + TimeRecords.format(elapsed) + " §7• §6" + result.rank() + ". sıradasın")));
      tell(
          p,
          "§aBitiriş: §e"
              + TimeRecords.format(elapsed)
              + " §7• En iyi süren: "
              + TimeRecords.format(result.best().millis())
              + " §7• "
              + r.difficulty.title
              + " sıralaması: §6"
              + result.rank()
              + ".");
      for (Player viewer : Bukkit.getOnlinePlayers())
        if (auth(viewer)
            && (visitors.containsKey(viewer.getUniqueId()) || hub.socialArea(viewer.getUniqueId())))
          tell(
              viewer,
              "§e"
                  + p.getName()
                  + " §f"
                  + r.difficulty.title
                  + " parkurunu §b"
                  + TimeRecords.format(elapsed)
                  + "§f'de bitirdi. En iyi derecesiyle §6"
                  + result.rank()
                  + ". sırada!");
      p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, .6f, 1);
      refreshBoards();
      update(p, r);
    } catch (IOException e) {
      storageFailed = true;
      getLogger().log(Level.SEVERE, "Bitiriş süresi kaydedilemedi; önceki rekorlar korundu.", e);
      tell(p, "Süre kaydedilemedi. Önceki rekorlar korunuyor; yöneticiye haber ver. /lobi");
    }
  }

  void tick() {
    ticks++;
    if (ticks % 20 == 0) {
      refreshLiveBoards();
      for (var v : visitors.entrySet()) {
        Player viewer = Bukkit.getPlayer(v.getKey());
        if (viewer != null) hud.update(viewer, v.getValue());
      }
    }
    for (var entry : List.copyOf(visitors.entrySet())) {
      Player p = Bukkit.getPlayer(entry.getKey());
      if (p == null || !auth(p) || p.isDead()) continue;
      Run r = entry.getValue();
      if (p.getWorld() != world) {
        hub.returnToLobbyForced(p.getUniqueId());
        continue;
      }
      if (editing(p)) {
        r.timer.invalidate();
        r.assisted = true;
        continue;
      }
      if (storageFailed) {
        if (ticks % 40 == 0)
          p.sendActionBar(Component.text("Süre kaydı durdu; /lobi ile çıkabilirsin."));
        continue;
      }
      if (r.difficulty == null) {
        if (p.getY() < 67) {
          reset(p, r);
          continue;
        }
        for (var portal : map.data.portals())
          if (Math.abs(p.getX() - portal.x()) < 3
              && Math.abs(p.getZ() - portal.z()) < 1.4
              && Math.abs(p.getY() - portal.y()) < 2) {
            start(p, Difficulty.parse(portal.difficulty()), false, -1);
            break;
          }
        continue;
      }
      if (p.getGameMode() != GameMode.ADVENTURE
          || p.isFlying()
          || p.isGliding()
          || p.isInsideVehicle()) {
        r.assisted = true;
        r.timer.invalidate();
        continue;
      }
      if (r.checkpoint >= CourseMap.STAGES) {
        if (p.getY() < checkpoint(r).getY() - 8) reset(p, r);
        if (ticks % 5 == 0) update(p, r);
        continue;
      }
      var stage = map.route(r.difficulty).stages().get(r.checkpoint);
      if (r.drop.update(ticks, p.getY(), stage.floor(), p.isOnGround() || p.isInWater())
          || p.getY() < world.getMinHeight() + 8) {
        reset(p, r);
        continue;
      }
      var position=map.advance(r.checkpoint,r.gate,p.getLocation(),supported(p));
      r.gate=position.gate();
      if(position.advanced()) {
        r.checkpoint=position.section();
        if(r.checkpoint==CourseMap.STAGES) finish(p,r);
        else { p.playSound(p.getLocation(),Sound.BLOCK_NOTE_BLOCK_PLING,.25f,1.2f);update(p,r); }
        continue;
      }
      if (ticks % 5 == 0) {
        update(p, r);
        if (r.gate < stage.gates().size()) {
          var next=stage.gates().get(r.gate);
          Location cue=new Location(world,next.x(),next.y()+.15,next.z());
          if(p.getLocation().distanceSquared(cue)<196)
            p.spawnParticle(Particle.END_ROD,cue,2,.08,.04,.08,0);
        }
      }
      if (ticks % 20 == 0)
        p.sendActionBar(
            MenuStyle.line(
                r.assisted
                    ? "§cBu deneme geçersiz. Baştan başlamak için /kiyamet dön."
                    : stage.instruction()));
    }
  }

  void menu(Player p) {
    ready(p);
    List<GameScreens.Button> buttons = new ArrayList<>();
    for (Difficulty d : Difficulty.values()) {
      var best = records.best(p.getUniqueId(), d);
      buttons.add(
          new GameScreens.Button(
              d.title
                  + " • Başla"
                  + (best == null ? "" : " • " + TimeRecords.format(best.millis())),
              () -> start(p, d, false, -1)));
    }
    buttons.add(new GameScreens.Button("Canlı ilerleme • İlk 5", () -> progress(p)));
    buttons.add(new GameScreens.Button("En hızlı bitirenler", () -> stats(p)));
    buttons.add(new GameScreens.Button("Parkur lobisi", () -> gameLobby(p)));
    buttons.add(
        new GameScreens.Button(
            "Oyun lobileri",
            () -> {
              gameLobby(p);
              hub.openGames(p.getUniqueId());
            }));
    buttons.add(new GameScreens.Button("Ana lobiye dön", () -> hub.returnToLobby(p.getUniqueId())));
    buttons.add(new GameScreens.Button("Kapat", () -> {}));
    screens.show(
        p,
        "Kıyamet • Süre yarışı",
        List.of(
            "§cAŞIRI ZOR §7• 48 farklı bölüm",
            "§eİşaretli geçişleri sırayla tamamla; uçuş ve ışınlanma rekoru geçersiz kılar.",
            "§cDüşünce rotanın en başına dönersin; süre sıfırlanır.",
            "§648 bölümü bitir; en hızlı ilk 5'e gir!"),
        buttons,
        false);
  }

  void stats(Player p) {
    ready(p);
    List<String> lines = new ArrayList<>();
    for (Difficulty d : Difficulty.values()) {
      lines.add(d.color + d.title.toUpperCase(Locale.ROOT) + " §7• EN HIZLI İLK 5");
      var own = records.best(p.getUniqueId(), d);
      lines.add(
          "§7En iyi süren: "
              + (own == null ? "Henüz bitirmedin" : TimeRecords.format(own.millis())));
      int n = 1;
      for (var top : records.top(d))
        lines.add("§e" + (n++) + ". §f" + top.name() + " §b" + TimeRecords.format(top.millis()));
    }
    screens.show(
        p,
        "Kıyamet • Süre sıralaması",
        lines,
        List.of(
            new GameScreens.Button("Kıyamet menüsü", () -> menu(p)),
            new GameScreens.Button("Kapat", () -> {})),
        false);
  }

  @Override
  public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
    try {
      if (!(s instanceof Player p)) throw new IllegalArgumentException("Oyunda kullan.");
      enter(p);
      String v = a.length == 0 ? "menu" : fold(a[0]);
      switch (v) {
        case "basla", "asiri", "kiyamet" -> start(p, Difficulty.ASIRI, false, -1);
        case "menu", "yardim" -> menu(p);
        case "lobi" -> gameLobby(p);
        case "don", "kontrol" -> reset(p, visitors.get(p.getUniqueId()));
        case "ilerleme", "ilk5" -> progress(p);
        case "siralama", "sureler" -> stats(p);
        case "bastan" -> {
          if (a.length > 2) throw new IllegalArgumentException("/kiyamet baştan");
          start(p, Difficulty.ASIRI, false, 0);
        }
        case "bolum" ->
            throw new IllegalArgumentException(
                "Süre yarışı en baştan başlar. Yönetici denemesi: /kiyamet deneme asiri"
                    + " <1-48>");
        case "deneme", "test" -> {
          if (!admin(p) || a.length != 3)
            throw new IllegalArgumentException("Yönetici: /kiyamet deneme asiri <1-48>");
          int number = Integer.parseInt(a[2]);
          if (number < 1 || number > CourseMap.STAGES) throw new IllegalArgumentException("Bölüm 1–48 olmalı.");
          start(p, Difficulty.parse(fold(a[1])), true, number - 1);
        }
        case "yonetim" -> {
          if (!admin(p) || a.length != 2)
            throw new IllegalArgumentException("/kiyamet yönetim aç|kapat");
          if (fold(a[1]).equals("ac")) {
            editors.add(p.getUniqueId());
            p.setGameMode(GameMode.CREATIVE);
            p.setAllowFlight(true);
            tell(p, "Harita düzenlemesi açık; süre sıralamasına yazılmaz.");
          } else {
            editors.remove(p.getUniqueId());
            gameLobby(p);
          }
        }
        case "durum" ->
            tell(
                p,
                "Dünya: "
                    + world.getName()
                    + " • 48 aşırı zor bölüm • İçeride "
                    + visitors.size()
                    + " oyuncu.");
        default ->
            throw new IllegalArgumentException(
                "/kiyamet • asiri • dön • lobi • ilerleme • sıralama");
      }
    } catch (Exception e) {
      tell(s, e.getMessage() == null ? "İşlem tamamlanamadı." : e.getMessage());
    }
    return true;
  }

  static String fold(String s) {
    return s.toLowerCase(Locale.ROOT)
        .replace('ı', 'i')
        .replace('ö', 'o')
        .replace('ü', 'u')
        .replace('ş', 's')
        .replace('ç', 'c')
        .replace('ğ', 'g');
  }

  @Override
  public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
    return a.length == 1
        ? List.of(
            "başla",
            "asiri",
            "lobi",
            "dön",
            "ilerleme",
            "sıralama",
            "baştan",
            "deneme",
            "yönetim",
            "durum")
        : a.length == 2 ? List.of("asiri") : List.of();
  }

  void use(Player p, int code) {
    if (!visitors.containsKey(p.getUniqueId())) return;
    try {
      if (code == 1) menu(p);
      else if (code == 2) reset(p, visitors.get(p.getUniqueId()));
      else if (code == 3) progress(p);
    } catch (Exception e) {
      tell(p, e.getMessage());
    }
  }

  TextDisplay label(Location at, Component content) {
    world.addPluginChunkTicket(at.getBlockX() >> 4, at.getBlockZ() >> 4, this);
    TextDisplay text =
        world.spawn(
            at,
            TextDisplay.class,
            t -> {
              t.setPersistent(false);
              t.setBillboard(Display.Billboard.CENTER);
              t.text(content);
              t.setShadowed(true);
              t.setSeeThrough(false);
              t.setLineWidth(430);
              t.setBackgroundColor(Color.fromARGB(100, 15, 20, 25));
              t.addScoreboardTag("kasaba-kiyamet-info");
            });
    labels.add(text);
    return text;
  }

  void labels() {
    for (var portal : map.data.portals()) {
      Difficulty d = Difficulty.parse(portal.difficulty());
      label(
          new Location(world, portal.x(), 79.5, portal.z() - .5),
          MenuStyle.line(d.color + d.title.toUpperCase(Locale.ROOT)));
    }
    label(
        lobbyPoint().add(0, 4, 8),
        MenuStyle.title("KIYAMET PARKURU")
            .append(Component.newline())
            .append(MenuStyle.line("§cAşırı zor §7• 48 özgün bölüm"))
            .append(Component.newline())
            .append(MenuStyle.line("§eGeçişleri sırayla tamamla; düşersen en başa dönersin."))
            .append(Component.newline())
            .append(MenuStyle.line("§cDüşünce baştan; bitişte süren ve sıralaman!")));
    for (Difficulty d : Difficulty.values())
      timeBoards.put(d, label(lobbyPoint().add(-16, 4, 22), Component.empty()));
    for (Difficulty d : Difficulty.values())
      liveBoards.put(d, label(lobbyPoint().add(16, 4, 22), Component.empty()));
    for(int i=0;i<CourseMap.STAGES;i++) {
      var point=map.route(Difficulty.ASIRI).checkpoints().get(i);
      var stage=map.route(Difficulty.ASIRI).stages().get(i);
      TextDisplay text=label(point.at(world).add(0,3.4,0),MenuStyle.line("§c"+(i+1)+"/48 §7• §f"+stage.name()));
      text.setViewRange(.42f);text.setLineWidth(220);
    }
    refreshBoards();
    refreshLiveBoards();
  }

  void refreshBoards() {
    for (var entry : timeBoards.entrySet()) {
      Difficulty d = entry.getKey();
      Component text = MenuStyle.title(d.title.toUpperCase(Locale.ROOT) + " • EN HIZLI İLK 5");
      var top = records.top(d);
      for (int i = 0; i < 5; i++)
        text =
            text.append(Component.newline())
                .append(
                    MenuStyle.line(
                        "§e"
                            + (i + 1)
                            + ". "
                            + (i < top.size()
                                ? "§f"
                                    + top.get(i).name()
                                    + " §b"
                                    + TimeRecords.format(top.get(i).millis())
                                : "§7—")));
      if (entry.getValue().isValid()) entry.getValue().text(text);
    }
  }

  List<LiveProgress.Entry> live(Difficulty difficulty) {
    List<LiveProgress.Entry> entries = new ArrayList<>();
    for (var e : visitors.entrySet()) {
      Run r = e.getValue();
      Player p = Bukkit.getPlayer(e.getKey());
      if (p != null
          && p.getWorld() == world
          && r.difficulty == difficulty
          && !r.practice
          && !r.assisted
          && !editing(p)
          && r.timer.valid())
        entries.add(
            new LiveProgress.Entry(
                e.getKey(),
                p.getName(),
                LiveProgress.position(map.route(difficulty), r.checkpoint, r.gate)));
    }
    return LiveProgress.top(entries);
  }

  void progress(Player p) {
    ready(p);
    List<String> lines = new ArrayList<>();
    lines.add("§7Şu an yarışanların bulunduğu konum; saniyede yenilenir.");
    lines.add("§7Deneme ve yardımlı koşular listeye girmez.");
    for (Difficulty d : Difficulty.values()) {
      lines.add(d.color + d.title + " • EN İLERİDEKİ 5");
      var entries = live(d);
      for (int i = 0; i < 5; i++)
        lines.add(
            "§e"
                + (i + 1)
                + ". "
                + (i < entries.size()
                    ? "§f"
                        + entries.get(i).name()
                        + " §a%"
                        + String.format(Locale.ROOT, "%.1f", entries.get(i).progress())
                    : "§8—"));
    }
    screens.show(
        p,
        "Kıyamet • Canlı ilerleme",
        lines,
        List.of(
            new GameScreens.Button("Yenile", () -> progress(p)),
            new GameScreens.Button("Süre rekorları", () -> stats(p)),
            new GameScreens.Button("Geri", () -> menu(p))),
        false);
  }

  void refreshLiveBoards() {
    for (var e : liveBoards.entrySet()) {
      Component text =
          MenuStyle.title(e.getKey().title.toUpperCase(Locale.ROOT) + " • CANLI İLK 5");
      var top = live(e.getKey());
      for (int i = 0; i < 5; i++)
        text =
            text.append(Component.newline())
                .append(
                    MenuStyle.line(
                        "§e"
                            + (i + 1)
                            + ". "
                            + (i < top.size()
                                ? "§f" + top.get(i).name() + " §a%" + (int) top.get(i).progress()
                                : "§8—")));
      if (e.getValue().isValid()) e.getValue().text(text);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void verified(PlayerAuthenticatedEvent e) {
    recover(e.getPlayer());
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void quit(PlayerQuitEvent e) {
    UUID id = e.getPlayer().getUniqueId();
    quitting.add(id);
    leave(id);
    quitting.remove(id);
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void travel(PlayerTeleportEvent e) {
    Run r = visitors.get(e.getPlayer().getUniqueId());
    if (r != null && !transit.contains(e.getPlayer().getUniqueId())) {
      r.assisted = true;
      r.timer.invalidate();
      r.drop.clear();
    }
  }

  @EventHandler
  public void flight(PlayerToggleFlightEvent e) {
    Run r = visitors.get(e.getPlayer().getUniqueId());
    if (r != null && e.isFlying()) {
      r.assisted = true;
      r.timer.invalidate();
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void damage(EntityDamageEvent e) {
    if (protectedAt(e.getEntity().getLocation())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void food(FoodLevelChangeEvent e) {
    if (protectedAt(e.getEntity().getLocation())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void breaks(BlockBreakEvent e) {
    if (protectedAt(e.getBlock().getLocation()) && !editing(e.getPlayer())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void places(BlockPlaceEvent e) {
    if (protectedAt(e.getBlock().getLocation()) && !editing(e.getPlayer())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void interact(PlayerInteractEvent e) {
    if (!protectedAt(e.getPlayer().getLocation())) return;
    if (!editing(e.getPlayer())) e.setCancelled(true);
    if (e.getHand() == EquipmentSlot.HAND && e.getAction().isRightClick()) {
      int code = tool(e.getItem());
      if (code > 0) Bukkit.getScheduler().runTask(this, () -> use(e.getPlayer(), code));
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void inventory(InventoryClickEvent e) {
    if (!(e.getWhoClicked() instanceof Player p) || !protectedAt(p.getLocation()) || editing(p))
      return;
    e.setCancelled(true);
    int code = tool(e.getCurrentItem());
    if (code > 0) Bukkit.getScheduler().runTask(this, () -> use(p, code));
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void drag(InventoryDragEvent e) {
    if (e.getWhoClicked() instanceof Player p && protectedAt(p.getLocation()) && !editing(p))
      e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void drop(PlayerDropItemEvent e) {
    if (protectedAt(e.getPlayer().getLocation()) && !editing(e.getPlayer())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void pickup(EntityPickupItemEvent e) {
    if (protectedAt(e.getEntity().getLocation())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void spawn(CreatureSpawnEvent e) {
    if (CosmeticAccess.permitted(e.getEntity())) return;
    if (protectedAt(e.getLocation())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void explode(EntityExplodeEvent e) {
    if (protectedAt(e.getLocation())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void burn(BlockBurnEvent e) {
    if (protectedAt(e.getBlock().getLocation())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void bucket(PlayerBucketEmptyEvent e) {
    if (protectedAt(e.getBlock().getLocation()) && !editing(e.getPlayer())) e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void swap(PlayerSwapHandItemsEvent e) {
    if (visitors.containsKey(e.getPlayer().getUniqueId()) && !editing(e.getPlayer()))
      e.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void death(PlayerDeathEvent e) {
    if (visitors.containsKey(e.getPlayer().getUniqueId())) {
      e.setKeepInventory(true);
      e.getDrops().clear();
      e.setDroppedExp(0);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void respawn(PlayerRespawnEvent e) {
    Run r = visitors.get(e.getPlayer().getUniqueId());
    if (r != null) {
      r.drop.clear();
      r.checkpoint = 0;
      r.gate = 0;
      r.assisted = false;
      r.finishedMillis = -1;
      r.timer.restart(System.nanoTime());
      if (r.practice) r.timer.invalidate();
      e.setRespawnLocation(checkpoint(r));
    }
  }
}
