package tr.kasabatr.kiyamet;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class LiveProgressTest {
 @Test void percentageUsesCompletedSectionsAndOrderedGates()throws Exception{
  var m=new CourseMap(getClass().getResourceAsStream("/parkur-layout.json"));var r=m.route(Difficulty.ASIRI);assertEquals(0,LiveProgress.position(r,0,0));assertEquals(50,LiveProgress.position(r,24,0));assertEquals(100,LiveProgress.position(r,48,0));double half=LiveProgress.position(r,0,r.stages().getFirst().gates().size()/2);assertTrue(half>0&&half<100./48);
 }
 @Test void furthestFiveAreSortedWithStableTies(){
  var entries=new ArrayList<LiveProgress.Entry>();for(int i=0;i<8;i++)entries.add(new LiveProgress.Entry(new UUID(0,i),"P"+i,i*10));var top=LiveProgress.top(entries);assertEquals(5,top.size());assertEquals("P7",top.getFirst().name());assertEquals("P3",top.getLast().name());assertEquals("Amy",LiveProgress.top(List.of(new LiveProgress.Entry(new UUID(0,3),"Zed",50),new LiveProgress.Entry(new UUID(0,1),"Amy",50))).getFirst().name());
 }
}
