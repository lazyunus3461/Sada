package tr.kasabatr.kiyamet;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.bukkit.Location;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class CourseMapTest {
 CourseMap map()throws Exception{return new CourseMap(getClass().getResourceAsStream("/parkur-layout.json"));}
 @Test void completeCourseHasFortyEightDistinctSectionsAndNineFamilies()throws Exception{
  var route=map().route(Difficulty.ASIRI);assertEquals(49,route.checkpoints().size());assertEquals(48,route.stages().size());assertEquals(9,route.stages().stream().map(CourseMap.Stage::kind).distinct().count());assertEquals(48,route.stages().stream().map(CourseMap.Stage::name).distinct().count());
 }
 @Test void finishCannotBeReachedWithoutOrderedGates()throws Exception{
  var m=map();var r=m.route(Difficulty.ASIRI);var end=r.checkpoints().get(48);var state=m.advance(0,0,end.at(null),true);assertEquals(new CourseMap.Progress(0,0,false),state);
  var wrong=r.stages().getFirst().gates().get(2);assertEquals(0,m.advance(0,0,at(wrong),true).gate());
 }
 @Test void groundedGateRequiresSupportAndEachObservationConsumesOneGate()throws Exception{
  var m=map();var gate=m.route(Difficulty.ASIRI).stages().getFirst().gates().getFirst();assertTrue(gate.grounded());assertEquals(0,m.advance(0,0,at(gate),false).gate());assertEquals(1,m.advance(0,0,at(gate),true).gate());assertEquals(1,m.advance(0,1,at(gate),true).gate());
 }
 @Test void allOrderedGatesAndLandingsReachFinishExactlyOnce()throws Exception{
  var m=map();var r=m.route(Difficulty.ASIRI);int section=0;
  while(section<48){int gate=0;for(var g:r.stages().get(section).gates()){var s=m.advance(section,gate,at(g),true);assertEquals(section,s.section());assertFalse(s.advanced());assertEquals(++gate,s.gate());}
   var end=r.checkpoints().get(section+1).at(null);assertFalse(m.advance(section,gate,end,false).advanced());var s=m.advance(section,gate,end,true);assertTrue(s.advanced());assertEquals(++section,s.section());assertEquals(0,s.gate());}
  assertEquals(new CourseMap.Progress(48,0,false),m.advance(48,0,r.checkpoints().getLast().at(null),true));
 }
 @Test void malformedMapAndInvalidProgressAreRejected()throws Exception{
  assertThrows(IOException.class,()->new CourseMap(new ByteArrayInputStream("{}".getBytes(StandardCharsets.UTF_8))));var m=map();assertThrows(IllegalArgumentException.class,()->m.advance(-1,0,new Location(null,0,0,0),true));assertThrows(IllegalArgumentException.class,()->m.advance(0,99,new Location(null,0,0,0),true));
 }
 static Location at(CourseMap.Gate g){return new Location(null,g.x(),g.y(),g.z());}
}
