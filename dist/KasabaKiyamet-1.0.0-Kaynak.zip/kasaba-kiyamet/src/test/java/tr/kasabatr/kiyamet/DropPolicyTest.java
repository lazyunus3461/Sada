package tr.kasabatr.kiyamet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class DropPolicyTest {
 @Test void fallingIsVisibleAndNeverInstant(){var d=new DropPolicy(8,10);assertFalse(d.update(100,68,72,false));assertFalse(d.update(105,61,72,false));assertTrue(d.update(110,59,72,false));}
 @Test void landingOnLowerTerrainStillWaits(){var d=new DropPolicy(8,10);assertFalse(d.update(0,68,72,true));assertFalse(d.update(9,68,72,true));assertTrue(d.update(10,68,72,true));}
 @Test void normalJumpDoesNotReset(){var d=new DropPolicy(8,10);for(int t=0;t<100;t++)assertFalse(d.update(t,73+Math.sin(t*.2),72,false));assertFalse(d.falling());}
 @Test void intentionalSlimeDescentUsesTheLowerFloor(){var d=new DropPolicy(8,10);for(int t=0;t<30;t++)assertFalse(d.update(t,Math.max(70,79-t*.5),69,t>=18));}
 @Test void recoveringOntoThePathClearsPendingFall(){var d=new DropPolicy(8,10);d.update(1,68,72,false);assertFalse(d.update(20,73,72,true));assertFalse(d.falling());assertFalse(d.update(21,68,72,false));}
}
