package tr.kasabatr.kiyamet;
import java.nio.file.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;
class TimeRecordsTest {
 @TempDir Path dir;
 @Test void shorterTimeWinsAfterRestart()throws Exception{
  var s=new TimeRecords(dir.resolve("r.json"));UUID a=UUID.randomUUID(),b=UUID.randomUUID();s.record(a,"First",Difficulty.ASIRI,90000,10);assertEquals(1,s.record(b,"Second",Difficulty.ASIRI,60000,20).rank());var restored=new TimeRecords(dir.resolve("r.json"));restored.load();assertEquals(b,restored.top(Difficulty.ASIRI).getFirst().player());assertEquals(2,restored.top(Difficulty.ASIRI).size());
 }
 @Test void slowerFinishesCannotReplaceBestOrDuplicatePlayer()throws Exception{
  var s=new TimeRecords(dir.resolve("r"));UUID a=UUID.randomUUID();s.record(a,"OldName",Difficulty.ASIRI,60000,10);var r=s.record(a,"NewName",Difficulty.ASIRI,70000,20);assertFalse(r.improved());assertEquals(60000,r.best().millis());assertEquals(10,r.best().achieved());assertEquals("NewName",r.best().name());assertEquals(1,s.top(Difficulty.ASIRI).size());assertTrue(s.record(a,"NewName",Difficulty.ASIRI,59000,30).improved());
 }
 @Test void tiesUseEarlierAchievementAndOnlyFiveAreShown()throws Exception{
  var s=new TimeRecords(dir.resolve("r"));UUID first=UUID.randomUUID();s.record(first,"First",Difficulty.ASIRI,50000,1);for(int i=0;i<8;i++)s.record(UUID.randomUUID(),"Other"+i,Difficulty.ASIRI,50000,i+2);assertEquals(5,s.top(Difficulty.ASIRI).size());assertEquals(first,s.top(Difficulty.ASIRI).getFirst().player());
 }
 @Test void failedWritePreservesMemoryAndExistingRecord()throws Exception{
  Path f=dir.resolve("records");var s=new TimeRecords(f);UUID id=UUID.randomUUID();s.record(id,"Player",Difficulty.ASIRI,60000,10);byte[] previous=Files.readAllBytes(f);Files.delete(f);Files.createDirectory(f);assertThrows(java.io.IOException.class,()->s.record(id,"Player",Difficulty.ASIRI,30000,20));assertEquals(60000,s.best(id,Difficulty.ASIRI).millis());Files.delete(f);Files.write(f,previous);var restored=new TimeRecords(f);restored.load();assertEquals(60000,restored.best(id,Difficulty.ASIRI).millis());
 }
 @Test void invalidTimesAndCorruptDataAreRejectedWithoutReset()throws Exception{
  Path f=dir.resolve("r");String bad="{\"schema\":1,\"records\":[null]}";Files.writeString(f,bad);assertThrows(java.io.IOException.class,()->new TimeRecords(f).load());assertEquals(bad,Files.readString(f));var s=new TimeRecords(dir.resolve("valid"));for(long n:new long[]{-1,0,604800001})assertThrows(IllegalArgumentException.class,()->s.record(UUID.randomUUID(),"Player",Difficulty.ASIRI,n,1));assertTrue(s.top(Difficulty.ASIRI).isEmpty());
 }
 @Test void timesShowMinutesSecondsAndMilliseconds(){assertEquals("2 dk 03,456 sn",TimeRecords.format(123456));assertEquals("0 dk 00,001 sn",TimeRecords.format(1));}
}
