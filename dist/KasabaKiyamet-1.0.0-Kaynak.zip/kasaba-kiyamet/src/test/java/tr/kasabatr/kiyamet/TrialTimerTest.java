package tr.kasabatr.kiyamet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class TrialTimerTest {
 @Test void retryResetsEntireClock(){var t=new TrialTimer();t.restart(1000000000L);assertEquals(2500,t.elapsed(3500000000L));t.restart(4000000000L);assertEquals(500,t.elapsed(4500000000L));}
 @Test void invalidAttemptCannotRecordUntilRestart(){var t=new TrialTimer();t.restart(0);t.invalidate();assertThrows(IllegalStateException.class,()->t.finish(1000000000L));t.restart(2000000000L);assertEquals(1500,t.finish(3500000000L));}
 @Test void finishFreezesTimeAndCannotRepeat(){var t=new TrialTimer();t.restart(0);assertEquals(1000,t.finish(1000000000L));assertEquals(1000,t.elapsed(9000000000L));assertThrows(IllegalStateException.class,()->t.finish(9000000000L));}
}
