param([Parameter(Mandatory=$true)][string]$AuthJar,[Parameter(Mandatory=$true)][string]$HubJar)
$ErrorActionPreference = 'Stop'
if (!(Test-Path $AuthJar) -or !(Test-Path $HubJar)) { throw 'İki eklenti JAR yolunu da kontrol et.' }
$AuthJar = (Resolve-Path $AuthJar).Path
$HubJar = (Resolve-Path $HubJar).Path
Set-Location $PSScriptRoot
& mvn -B -ntp org.apache.maven.plugins:maven-install-plugin:3.1.2:install-file "-Dfile=$AuthJar" -DgroupId=tr.kasaba -DartifactId=kasaba-auth -Dversion=1.4.0 -Dpackaging=jar -DgeneratePom=true
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& mvn -B -ntp org.apache.maven.plugins:maven-install-plugin:3.1.2:install-file "-Dfile=$HubJar" -DgroupId=tr.kasaba -DartifactId=kasaba-hub -Dversion=1.12.2 -Dpackaging=jar -DgeneratePom=true
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& mvn -B -ntp verify
exit $LASTEXITCODE
