#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 2 ]; then
  printf '%s\n' 'Kullanım: ./build.sh /yol/KasabaAuth.jar /yol/KasabaHub.jar' >&2
  exit 2
fi
test -f "$1"
test -f "$2"
task_auth_jar=$(realpath -- "$1")
task_hub_jar=$(realpath -- "$2")
cd -- "$(dirname -- "$0")"
# Runtime Auth 1.4.2 provides the compatible 1.4.0 AuthState API used in pom.xml.
mvn -B -ntp org.apache.maven.plugins:maven-install-plugin:3.1.2:install-file -Dfile="$task_auth_jar" -DgroupId=tr.kasaba -DartifactId=kasaba-auth -Dversion=1.4.0 -Dpackaging=jar -DgeneratePom=true
mvn -B -ntp org.apache.maven.plugins:maven-install-plugin:3.1.2:install-file -Dfile="$task_hub_jar" -DgroupId=tr.kasaba -DartifactId=kasaba-hub -Dversion=1.12.2 -Dpackaging=jar -DgeneratePom=true
mvn -B -ntp verify
