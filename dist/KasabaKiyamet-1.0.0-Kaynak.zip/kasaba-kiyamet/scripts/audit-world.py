#!/usr/bin/env python3
"""Decode the exported Anvil files; check real collisions, not builder memory."""
from pathlib import Path
import io,json,math,struct,zlib
import nbtlib as n

root=Path(__file__).resolve().parents[1]
world=root/'world-template/kasaba_kiyamet_v1'
layout=json.loads((world/'parkur-layout.json').read_text())
regions={};chunks={};states_seen=set()
def block(x,y,z):
    cx,cz=x//16,z//16
    if (cx,cz) not in chunks:
        region=cx//32,cz//32
        if region not in regions:regions[region]=(world/'region'/f'r.{region[0]}.{region[1]}.mca').read_bytes()
        data=regions[region];idx=(cx%32+cz%32*32)*4;offset=int.from_bytes(data[idx:idx+3],'big')*4096
        if not offset:chunks[cx,cz]={}
        else:
            length=struct.unpack('>I',data[offset:offset+4])[0];assert data[offset+4]==2
            chunk=n.File.parse(io.BytesIO(zlib.decompress(data[offset+5:offset+4+length])))
            chunks[cx,cz]={int(s['Y']):s['block_states'] for s in chunk['sections']}
    states=chunks[cx,cz].get(y//16)
    if states is None:return 'air',{}
    palette=states['palette'];i=(y%16)*256+(z%16)*16+x%16
    if len(palette)==1:entry=palette[0]
    else:
        bits=max(4,(len(palette)-1).bit_length());per=64//bits
        value=int(states['data'][i//per])&((1<<64)-1)
        entry=palette[(value>>((i%per)*bits))&((1<<bits)-1)]
    name=str(entry['Name']).removeprefix('minecraft:');props={str(k):str(v)for k,v in entry.get('Properties',{}).items()}
    states_seen.add('minecraft:'+name+('['+','.join(k+'='+v for k,v in sorted(props.items()))+']'if props else''))
    return name,props

def collision(x,y,z):
    name,props=block(x,y,z)
    if name in ('air','ladder','lava','water'):return []
    if name.endswith('_fence'):
        assert all(props.get(k)=='false' for k in ['north','south','east','west'])
        return [(x+.375,y,z+.375,x+.625,y+1.5,z+.625)]
    if name=='iron_trapdoor':
        assert props['open']=='false' and props['half']=='bottom'
        return [(x,y,z,x+1,y+.1875,z+1)]
    if name=='honey_block':return [(x+.0625,y,z+.0625,x+.9375,y+.9375,z+.9375)]
    return [(x,y,z,x+1,y+1,z+1)]

def check_body(x,y,z,supported,label):
    support=False
    for xx in range(math.floor(x-.299),math.floor(x+.299)+1):
        for zz in range(math.floor(z-.299),math.floor(z+.299)+1):
            for yy in range(math.floor(y)-2,math.floor(y+1.8)+1):
                for a,b,c,d,e,f in collision(xx,yy,zz):
                    overlapx=d>x-.299+1e-6 and a<x+.299-1e-6
                    overlapz=f>z-.299+1e-6 and c<z+.299-1e-6
                    if overlapx and overlapz:
                        if abs(e-y)<.001:support=True
                        assert not(e>y+.001 and b<y+1.799),(label,'player intersects block',xx,yy,zz,block(xx,yy,zz))
    if supported:assert support,(label,'missing exact support surface',x,y,z)

route=layout['routes']['asiri'];landings=json.loads((root/'validation/landings.json').read_text())
gates=transitions=0;max_travel=0
for i,cp in enumerate(route['checkpoints']):
    assert block(math.floor(cp['x']),math.floor(cp['y'])-1,math.floor(cp['z']))[0]=='lodestone'
    check_body(cp['x'],cp['y'],cp['z'],True,('platform',i))
for i,stage in enumerate(route['stages']):
    for j,g in enumerate(stage['gates']):
        check_body(g['x'],g['y'],g['z'],g['grounded'],('gate',i+1,j+1));gates+=1
    if stage['kind'] not in ['precision','diagonal','headhit','fence','trapdoors','ascent']:continue
    a=landings[i];floor=a['base'][1]
    nodes=[{'u':0,'v':0,'surface':floor+1,'width':3}]+a['landings']+[{'u':40,'v':0,'surface':route['checkpoints'][i+1]['y'],'width':3}]
    for first,last in zip(nodes,nodes[1:]):
        # Edge-to-edge movement needed by a 0.6-block-wide player. No physics simulation.
        wa=.25 if first.get('material','').endswith('fence')else first['width']
        wb=.25 if last.get('material','').endswith('fence')else last['width']
        clearance=(wa+wb)/2+.6
        needed=math.hypot(max(0,abs(last['u']-first['u'])-clearance),max(0,abs(last['v']-first['v'])-clearance))
        rise=last['surface']-first['surface']
        limit=1.45 if stage['kind']=='headhit' else 3.05 if rise>.6 else 3.7
        assert rise<=1.001 and needed<=limit+1e-6,('jump dimensions',i+1,stage['kind'],first,last,needed,rise,limit)
        max_travel=max(max_travel,needed);transitions+=1

proof={'checkpoints_with_support_and_headroom':49,'ordered_gates_with_clearance':gates,'ordinary_transitions_checked':transitions,'max_required_horizontal_travel':round(max_travel,4),'scope':'Decoded actual Anvil blocks; exact support and 1.8-block body clearance. Conservative ordinary jump dimensions only. Ladder exits, slime bounce, honey slide and a full human playthrough remain unverified.','humanPlaythrough':False}
(root/'validation/physical-audit.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'validation/palette.json').write_text(json.dumps(sorted(states_seen),indent=2)+'\n')
print(json.dumps(proof,ensure_ascii=False))
