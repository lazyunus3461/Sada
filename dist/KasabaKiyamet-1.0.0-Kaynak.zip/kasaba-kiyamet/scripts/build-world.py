#!/usr/bin/env python3
"""Build an original void-surrounded 48-section extreme fortress course."""
from pathlib import Path
import copy,gzip,io,json,math,random,struct,zlib,zipfile
from collections import Counter
import numpy as np
import nbtlib as n
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'world-template/kasaba_kiyamet_v1'
RES=ROOT/'src/main/resources'
chunks={};palette=[];registry={};entities={};rng=random.Random(13112026)
def state(name,**props):
    k=(name,tuple(sorted((k,str(v)) for k,v in props.items())))
    if k not in registry:
        b=n.Compound({'Name':n.String('minecraft:'+name)})
        if props:b['Properties']=n.Compound({k:n.String(str(v)) for k,v in props.items()})
        registry[k]=len(palette);palette.append(b)
    return registry[k]
AIR=state('air')
def put(x,y,z,name,**props):
    x,y,z=map(int,(x,y,z));assert -64<=y<320
    a=chunks.setdefault((x//16,z//16),{}).setdefault(y//16,np.zeros((16,16,16),dtype=np.uint16))
    a[y%16,z%16,x%16]=name if isinstance(name,int) else state(name,**props)
def fill(x1,y1,z1,x2,y2,z2,name,**props):
    value=state(name,**props) if isinstance(name,str) else name
    for x in range(int(x1),int(x2)+1):
        for z in range(int(z1),int(z2)+1):
            for y in range(int(y1),int(y2)+1):put(x,y,z,value)
def get(x,y,z):
    a=chunks.get((int(x)//16,int(z)//16),{}).get(int(y)//16)
    return 0 if a is None else int(a[int(y)%16,int(z)%16,int(x)%16])
def tree(x,y,z,large=False):
    height=9 if large else 6
    fill(x-1 if large else x,y,z,x,y+height,z,'oak_log',axis='y')
    for yy in range(y+height-3,y+height+3):
        radius=4 if large else 3
        for dx in range(-radius,radius+1):
            for dz in range(-radius,radius+1):
                if dx*dx+dz*dz+(yy-y-height)**2<radius*radius+3 and not get(x+dx,yy,z+dz):put(x+dx,yy,z+dz,'oak_leaves',persistent='true',distance='1',waterlogged='false')
def tower(x,y,z,height,hard=False):
    material='polished_blackstone_bricks' if hard else 'mossy_stone_bricks'
    for yy in range(y,y+height+1):
        for dx in range(-3,4):
            for dz in range(-3,4):
                if abs(dx)==3 or abs(dz)==3 or yy in (y,y+height):put(x+dx,yy,z+dz,material)
    for dx in [-3,0,3]:
        for dz in [-3,0,3]:put(x+dx,y+height+1,z+dz,material)
    put(x,y+height+1,z,'soul_lantern' if hard else 'lantern',hanging='false',waterlogged='false')

STAGES=48
SECTORS=['Kızıl Avlu','Kırık Surlar','Demir Denge','Cam Tünel','Slime Kuyusu','Bal Perdesi','Kara Zirve','Son Taç']
TITLE={'precision':'İğne Ucu','diagonal':'Çapraz Uçurum','headhit':'Kafa Payı Yok','ladder':'Dış Cephe','slime':'Kontrollü Sekiş','honey':'Bal Perdesi','fence':'Tek Direk','trapdoors':'İnce Kapak','ascent':'Dar Sırt'}
HELP={'precision':'Tek blokluk inişleri sırayla tuttur.','diagonal':'Çapraz inişlerde son anda yönünü ayarla.','headhit':'Alçak tavanda sprint ritmini koru; kısa sıçra.','ladder':'Merdiveni tırman; üstten yana çık, inişleri takip et.','slime':'Yukarı tırman, slime üzerine düş ve ileri sek; Shift basma.','honey':'Duvara yaklaşarak kay; alttaki dar platformu yakala.','fence':'Çit direklerinin üzerinde denge kur; inişleri kaçırma.','trapdoors':'İnce kapakların üzerine in; son sahanlığa yüksel.','ascent':'Tek blokluk yükselen sırttan ilerle.'}

def path():
    r=random.Random(73912026)
    points=[(x,z)for z in range(10)for x in (range(5)if z%2==0 else reversed(range(5)))]
    for _ in range(5000):
        if r.random()<.5:points.reverse()
        x,z=points[-1];near=[i for i,(a,b)in enumerate(points[:-2])if abs(a-x)+abs(b-z)==1]
        if near:
            i=r.choice(near);points[i+1:]=reversed(points[i+1:])
    points=points[:49]
    turns=sum((b[0]-a[0],b[1]-a[1])!=(c[0]-b[0],c[1]-b[1])for a,b,c in zip(points,points[1:],points[2:]))
    assert turns>=20,turns
    return points,turns

cells,turns=path();nodes=[]
for i,(x,z)in enumerate(cells):
    nx,nz=cells[min(i+1,48)];dx,dz=nx-x,nz-z
    nodes.append({'x':(x-2)*40+.5,'y':89+min(i//6,7)*6.,'z':z*40+32.5,'yaw':math.degrees(math.atan2(-dx,dz))if dx or dz else 0})
stages=[];audits=[];patterns=Counter()

# A distant lava basin frames the route; reset triggers well above its surface.
fill(-115,39,0,115,39,425,'blackstone');fill(-114,40,1,114,40,424,'lava',level='0')
for x in range(-115,116,8):
    for z in [0,425]:fill(x,40,z,x+3,43,z,'polished_blackstone_bricks')

# All sahanliks are respite platforms, never saved respawn checkpoints.
for i,cp in enumerate(nodes):
    x,y,z=math.floor(cp['x']),math.floor(cp['y'])-1,math.floor(cp['z'])
    fill(x-2,y-2,z-2,x+2,y-1,z+2,'polished_blackstone_bricks')
    fill(x-1,y,z-1,x+1,y,z+1,'lodestone')
    for dx,dz in [(-2,-2),(2,2),(-2,2),(2,-2)]:
        put(x+dx,y,z+dz,'red_concrete'if i<48 else'lime_concrete')
        put(x+dx,y-3,z+dz,'sea_lantern')
    # Tapered undersides and suspended chains give the platforms a built silhouette.
    fill(x-1,y-5,z-1,x+1,y-3,z+1,'deepslate_bricks')
    fill(x,y-12,z,x,y-6,z,'polished_basalt',axis='y')

for i in range(STAGES):
    a,b=nodes[i],nodes[i+1];sx,sz=math.floor(a['x']),math.floor(a['z']);by=math.floor(a['y'])-1;ey=math.floor(b['y'])-1
    du,dv=(math.floor(b['x'])-sx)//40,(math.floor(b['z'])-sz)//40
    def pos(u,v=0,y=None):return sx+u*du-v*dv,by if y is None else y,sz+u*dv+v*du
    def box(u1,y1,v1,u2,y2,v2,name,**props):
        for u in range(u1,u2+1):
            for v in range(v1,v2+1):
                for yy in range(y1,y2+1):put(*pos(u,v,yy),name,**props)
    gates=[];steps=[];structure=[];variant=i//8;sign=1 if i%2==0 else-1
    kind='ascent'if ey>by else['precision','diagonal','ladder','headhit','slime','fence','trapdoors','honey'][(i+i//6)%8]
    variant=patterns[kind]
    def gate(u,y,v=0,ground=True,r=.78):
        x,_,z=pos(u,v,y);gates.append({'x':x+.5,'y':float(y),'z':z+.5,'radius':r,'grounded':ground})
    def pad(u,y,v=0,w=1,material='polished_blackstone_bricks',height=1,mark=True,**props):
        lo=-(w//2);hi=lo+w-1
        box(u+lo,y,v+lo,u+hi,y,v+hi,material,**props)
        if mark:gate(u,y+height,v,True,.62 if material.endswith('fence')else.78)
        steps.append({'u':u,'y':y,'v':v,'width':w,'material':material,'surface':y+height})
    def climb(u,height):
        box(u,by+1,-1,u,by+height+1,-1,'deepslate_bricks')
        # The support is on local -v; facing points out into local +v.
        normal=(-dv,du);facing={(1,0):'east',(-1,0):'west',(0,1):'south',(0,-1):'north'}[normal]
        box(u,by+1,0,u,by+height,0,'ladder',facing=facing,waterlogged='false')
        gate(u,by+height-1,0,False,1.1)
    if kind=='precision':
        offsets=[0,0,1,1,0,-1,-1,0,0]
        for j,u in enumerate(range(4,37,4)):
            v=offsets[(j+variant)%9]*sign
            y=by+(1 if (j+variant)%4==2 else 0)
            pad(u,y,v,material='chiseled_deepslate'if j%2 else'polished_blackstone_bricks')
    elif kind=='diagonal':
        wave=[0,1,2,1,0,-1,-2,-1,0,1,1,0]
        for j,u in enumerate(range(4,38,3)):
            pad(u,by,sign*wave[(j+variant)%12],material='red_nether_bricks')
    elif kind=='headhit':
        for j,u in enumerate(range(4,38,3)):pad(u,by,material='smooth_quartz'if(j+variant)%3 else'polished_blackstone')
        # Roof already covers the launch edge: entering a low roof mid-jump would be unfair.
        roof_start=1+(variant%2);roof_end=33+variant
        box(roof_start,by+3,-1,roof_end,by+3,1,'black_stained_glass')
        structure.append(('roof',roof_start,roof_end))
        for u in range(roof_start,roof_end+1,3):box(u,by+4,-1,u,by+4,1,'redstone_block')
    elif kind=='ladder':
        lu=9+(variant%2);height=6+(variant%3)
        pad(4,by,0,2);pad(7,by,0,1);climb(lu,height)
        for u,y,w in [(lu+3,by+height-1,2),(lu+7,by+height-2,1),(lu+11,by+3,1),(lu+15,by+2,1),(lu+19,by+1,1),(lu+23,by,1),(lu+26,by,1)]:pad(u,y,0,w)
    elif kind=='slime':
        lu=6+(variant%2);height=8+(variant%2);slime_u=12+(variant%3);target=slime_u+5
        pad(4,by,0,2);climb(lu,height);pad(lu+2,by+height-1,0,2)
        pad(slime_u,by-1,0,2,'slime_block',mark=False);gate(slime_u,by,0,False,1.15)
        for u,y,w in [(target,by+2,2),(target+4,by+1,1),(target+8,by,1),(target+12,by,1),(36,by,1)]:pad(u,y,0,w)
    elif kind=='honey':
        lu=6+(variant%2);height=6+(variant%3);wall=13+(variant%2)
        pad(4,by,0,2);climb(lu,height);pad(lu+3,by+height-1,0,2)
        box(wall,by,-1,wall,by+height+1,-1,'honey_block');gate(wall,by+(height-1)/2,0,False,1.0)
        for u,y in [(wall+2,by-1),(wall+6,by),(wall+10,by),(wall+14,by),(wall+18,by),(36,by)]:pad(u,y,0,1,'gilded_blackstone')
    elif kind=='fence':
        offsets=[0,1,0,-1,0,0,1,0,0]
        for j,u in enumerate(range(4,37,4)):
            v=sign*offsets[(j+variant)%9]
            pad(u,by,v,1,'dark_oak_fence',height=1.5,north='false',south='false',east='false',west='false',waterlogged='false')
    elif kind=='trapdoors':
        points=list(range(3+(variant%3),38,3))
        if points[-1]<37:points.append(38)
        for j,u in enumerate(points):
            vv=sign*(1 if (variant%2 and j%4 in [1,2])else 0)
            pad(u,by,vv,1,'iron_trapdoor',height=.1875,facing='north',half='bottom',open='false',powered='false',waterlogged='false')
    elif kind=='ascent':
        for u in range(3,39):
            vv=round(sign*(i//6+1)*math.sin(math.pi*(u-2)/36));yy=by+int((u-2)*(ey-by)/36)
            box(u,yy,vv,u,yy,vv,'polished_blackstone_bricks')
            if u in [4,8,12,16,20,24,28,32,36]:gate(u,yy+1,vv)
            steps.append({'u':u,'y':yy,'v':vv,'width':1,'material':'polished_blackstone_bricks','surface':yy+1})
    assert 3<=len(gates)<=20,(i,kind,len(gates))
    # Inaccessible hanging trim stays below the playable space.
    for u in [7,20,33]:
        for v in [-7,7]:
            x,y,z=pos(u,v,by-12);fill(x,y,z,x,y+4,z,'blackstone');put(x,y+5,z,'soul_lantern',hanging='false',waterlogged='false')
    floor=by-1 if kind in ['slime','honey']else by
    stages.append({'name':f'{SECTORS[i//6]} · {TITLE[kind]} {i+1:02d}','instruction':HELP[kind]+' Geçişleri sırayla tamamla.','floor':floor,'gates':gates,'kind':kind})
    audits.append({'stage':i+1,'kind':kind,'base':[sx,by,sz],'direction':[du,dv],'landings':steps,'end':b,'structure':structure})
    patterns[kind]+=1

# A real entrance plaza: basalt buttresses, eight lantern braziers and a single red arch.
fill(-30,68,-120,30,70,-55,'blackstone');fill(-30,71,-120,30,71,-55,'deepslate_bricks');fill(-29,72,-119,29,72,-56,'polished_blackstone_bricks')
for x in range(-30,31):
    for z in range(-120,-54):
        if x in [-30,30]or z in [-120,-55]:
            put(x,73,z,'polished_blackstone_bricks');put(x,74,z,'polished_blackstone_brick_wall',up='true',north='none',south='none',east='none',west='none',waterlogged='false')
        elif x%6==0 and z%7==0:put(x,72,z,'gilded_blackstone')
for x in [-23,23]:
    for z in [-110,-95,-80,-64]:
        fill(x-1,73,z-1,x+1,76,z+1,'chiseled_deepslate');put(x,77,z,'campfire',facing='north',lit='true',signal_fire='false',waterlogged='false')
for x in [-6,6]:fill(x,73,-66,x,83,-66,'polished_blackstone_bricks')
fill(-6,82,-66,6,83,-66,'red_nether_bricks');fill(-4,72,-67,4,72,-64,'red_concrete')
for x in [-27,27]:tower(x,73,-117,16,True)
end=nodes[-1];ex,ey,ez=math.floor(end['x']),int(end['y'])-1,math.floor(end['z'])
for dx,dz in [(-7,-7),(7,-7),(-7,7),(7,7)]:tower(ex+dx,ey-5,ez+dz,17,True)
manifest={'schema':2,'world':'kasaba_kiyamet_v1','lobby':{'x':.5,'y':73.,'z':-103.5,'yaw':0},'portals':[{'difficulty':'asiri','x':.5,'y':73.,'z':-65.5}],'routes':{'asiri':{'checkpoints':nodes,'stages':stages}}}
RES.mkdir(parents=True,exist_ok=True);(RES/'parkur-layout.json').write_text(json.dumps(manifest,ensure_ascii=False,separators=(',',':')))

def pack(values,bits):
    flat=np.asarray(values,dtype=np.uint64).ravel();per=64//bits;words=np.zeros(math.ceil(len(flat)/per),dtype=np.uint64)
    for i in range(per):part=flat[i::per];words[:len(part)]|=part<<np.uint64(i*bits)
    return n.LongArray(words.view(np.int64))
regions={};blocks_count=0
for (cx,cz),sections in sorted(chunks.items()):
    encoded=[];height=np.full((16,16),-65,dtype=int)
    for sy,arr in sorted(sections.items()):
        ids,inverse=np.unique(arr,return_inverse=True);bs=n.Compound({'palette':n.List[n.Compound]([palette[int(i)]for i in ids])})
        if len(ids)>1:bs['data']=pack(inverse,max(4,(len(ids)-1).bit_length()))
        encoded.append(n.Compound({'Y':n.Byte(sy),'block_states':bs,'biomes':n.Compound({'palette':n.List[n.String]([n.String('minecraft:plains')])})}))
        height=np.maximum(height,np.max(np.where(arr!=0,np.arange(sy*16,sy*16+16)[:,None,None],-65),axis=0));blocks_count+=int(np.count_nonzero(arr))
    hm=pack(height+65,9)
    chunk=n.File({'DataVersion':n.Int(4556),'xPos':n.Int(cx),'yPos':n.Int(-4),'zPos':n.Int(cz),'Status':n.String('minecraft:full'),'LastUpdate':n.Long(0),'InhabitedTime':n.Long(0),'isLightOn':n.Byte(0),'sections':n.List[n.Compound](encoded),'block_entities':n.List[n.Compound]([]),'block_ticks':n.List[n.Compound]([]),'fluid_ticks':n.List[n.Compound]([]),'structures':n.Compound({'starts':n.Compound({}),'References':n.Compound({})}),'Heightmaps':n.Compound({k:hm for k in ['WORLD_SURFACE','MOTION_BLOCKING','MOTION_BLOCKING_NO_LEAVES','OCEAN_FLOOR']})})
    buffer=io.BytesIO();chunk.write(buffer);payload=zlib.compress(buffer.getvalue(),7);raw=struct.pack('>I',len(payload)+1)+b'\x02'+payload
    regions.setdefault((cx//32,cz//32),{})[cx%32+cz%32*32]=raw
(OUT/'region').mkdir(parents=True,exist_ok=True)
for (rx,rz),entries in regions.items():
    head=bytearray(8192);body=bytearray();sector=2
    for index,raw in sorted(entries.items()):
        count=math.ceil(len(raw)/4096);assert count<256;head[index*4:index*4+4]=((sector<<8)|count).to_bytes(4,'big');body.extend(raw);body.extend(bytes(count*4096-len(raw)));sector+=count
    (OUT/'region'/f'r.{rx}.{rz}.mca').write_bytes(head+body)
level=n.load(ROOT/'scripts/void-level-template.dat');d=level['Data']
for k in ['Player','CustomBossEvents']:d.pop(k,None)
d['LevelName']=n.String('Kasaba Kıyamet Parkuru');d['SpawnX']=n.Int(0);d['SpawnY']=n.Int(73);d['SpawnZ']=n.Int(-104);d['Time']=n.Long(18000);d['DayTime']=n.Long(18000)
d['WorldGenSettings']['generate_features']=n.Byte(0)
g=d['WorldGenSettings']['dimensions']['minecraft:overworld']['generator'];g['type']=n.String('minecraft:flat');g['settings']['layers']=n.List[n.Compound]([]);g['settings']['structure_overrides']=n.List[n.String]([])
for k,v in {'doDaylightCycle':'false','doWeatherCycle':'false','doMobSpawning':'false','doFireTick':'false','randomTickSpeed':'0','fallDamage':'false','keepInventory':'true','doImmediateRespawn':'true'}.items():d['GameRules'][k]=n.String(v)
d['BorderCenterX']=n.Double(0);d['BorderCenterZ']=n.Double(150);d['BorderSize']=d['BorderSizeLerpTarget']=n.Double(2048)
level.save(OUT/'level.dat',gzipped=True);(OUT/'parkur-layout.json').write_bytes((RES/'parkur-layout.json').read_bytes())
with zipfile.ZipFile(RES/'parkur-world.zip','w',zipfile.ZIP_DEFLATED,compresslevel=7)as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(OUT))
shapes={(a['kind'],tuple((s['u'],s['y']-a['base'][1],s['v'],s['width'],s['material'])for s in a['landings']),tuple(tuple(x)for x in a['structure']))for a in audits}
assert len(shapes)==48,('Repeated local obstacle geometry',len(shapes))
report={'stages':48,'gates':sum(len(s['gates'])for s in stages),'distinct_section_layouts':len(shapes),'turns':turns,'families':dict(patterns),'chunks':len(chunks),'regions':len(regions),'blocks':blocks_count,'worldZipBytes':(RES/'parkur-world.zip').stat().st_size,'humanPlaythrough':False}
(ROOT/'validation/landings.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2)+'\n')
(ROOT/'validation/layout.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')

# Engineering overview rendered from the actual exported block arrays.
from PIL import ImageFont
im=Image.new('RGB',(1000,1250),(15,17,27));draw=ImageDraw.Draw(im)
for (cx,cz),sections in chunks.items():
    for zz in range(16):
        for xx in range(16):
            wx,wz=cx*16+xx,cz*16+zz;ix=500+wx*2;iz=300+wz*2
            if not(0<=ix<1000 and 0<=iz<1200):continue
            for sy,arr in sorted(sections.items(),reverse=True):
                ys=np.flatnonzero(arr[:,zz,xx])
                if len(ys):
                    name=str(palette[int(arr[int(ys[-1]),zz,xx])]['Name']).removeprefix('minecraft:')
                    color={'lava':'#803016','lodestone':'#d8d8d3','slime_block':'#95c957','honey_block':'#e8aa38','red_concrete':'#e04437','iron_trapdoor':'#ccdde2','dark_oak_fence':'#b69264','black_stained_glass':'#a15eae','redstone_block':'#a4343e','smooth_quartz':'#ebe4dd','ladder':'#d5ad7e','sea_lantern':'#bce8ed'}.get(name,'#6e6478')
                    draw.rectangle((ix,iz,ix+1,iz+1),fill=color);break
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(font_path,14);big=ImageFont.truetype(font_path,28)
draw.text((40,25),'KASABA • KIYAMET PARKURU',font=big,fill='#f5c775')
draw.text((40,72),'48 aşırı zor bölüm • Sıralı geçişler • Düşüşte en başa dönüş',font=font,fill='#ccd2df')
for i,node in enumerate(nodes):
    x=500+node['x']*2;z=300+node['z']*2
    draw.text((x+6,z-18),str(i+1)if i<48 else'BİTİŞ',font=font,fill='#fff1c5')
draw.text((40,1180),'Gerçek blok verisinden üstten görünüm. Ekran görüntüsü değildir.',font=font,fill='#a8a6b5')
im.save(ROOT/'validation/actual-world-overview.png')
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)

