#!/usr/bin/env python3
"""Isometric illustration decoded from the shipped Anvil world, not a client screenshot."""
from pathlib import Path
import runpy,math,json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parents[1]
a=runpy.run_path(str(root/'scripts/audit-world.py'));block=a['block'];chunks=a['chunks'];world=a['world']
for p in (world/'region').glob('*.mca'):
    _,rx,rz,_=p.name.split('.');rx,rz=int(rx),int(rz);data=p.read_bytes()
    for idx in range(1024):
        if int.from_bytes(data[idx*4:idx*4+3],'big'):block((rx*32+idx%32)*16,0,(rz*32+idx//32)*16)
blocks={};palette=set()
for (cx,cz),sections in chunks.items():
    for sy,s in sections.items():
        entries=s['palette']
        for e in entries:
            props=e.get('Properties',{});palette.add(str(e['Name'])+('['+','.join(str(k)+'='+str(v)for k,v in sorted(props.items()))+']'if props else''))
        if sy<3 or sy>10:continue
        if len(entries)==1:ids=np.zeros(4096,dtype=np.uint16)
        else:
            bits=max(4,(len(entries)-1).bit_length());per=64//bits;words=np.asarray(s['data'],dtype=np.int64).view(np.uint64);i=np.arange(4096)
            ids=((words[i//per]>>((i%per)*bits).astype(np.uint64))&((1<<bits)-1)).astype(np.uint16)
        for i in np.flatnonzero(ids if str(entries[0]['Name'])=='minecraft:air'else np.ones(4096)):
            name=str(entries[int(ids[i])]['Name']).removeprefix('minecraft:')
            if name!='air':blocks[cx*16+int(i%16),sy*16+int(i//256),cz*16+int(i//16%16)]=name
(root/'validation/palette.json').write_text(json.dumps(sorted(palette),indent=2)+'\n')
def color(name):
    return {'lodestone':(206,207,199),'red_concrete':(185,48,52),'lime_concrete':(116,188,81),'slime_block':(138,194,81),'honey_block':(224,156,42),'black_stained_glass':(94,72,107),'redstone_block':(142,37,39),'smooth_quartz':(227,225,211),'ladder':(172,125,68),'iron_trapdoor':(176,195,199),'dark_oak_fence':(130,97,70),'sea_lantern':(169,211,198),'soul_lantern':(106,198,203),'campfire':(232,125,44),'red_nether_bricks':(101,40,51),'gilded_blackstone':(110,89,61)}.get(name,(77,76,92)if'deepslate'in name else(85,78,91))
def project(x,y,z):return (x-z)*3.1,(x+z)*1.5-y*3.7
allpts=[project(x,y,z)for x,y,z in blocks];minx=min(p[0]for p in allpts)-80;miny=min(p[1]for p in allpts)-160
maxx=max(p[0]for p in allpts)+80;maxy=max(p[1]for p in allpts)+160
w,h=math.ceil(maxx-minx),math.ceil(maxy-miny);im=Image.new('RGB',(w,h),(15,16,25));draw=ImageDraw.Draw(im)
def proj(x,y,z):px,py=project(x,y,z);return px-minx,py-miny
# Exact exported lava-basin perimeter, represented by one plane.
draw.polygon([proj(x,40,z)for x,z in [(-114,1),(115,1),(115,425),(-114,425)]],fill=(83,35,32))
for (x,y,z),name in sorted(blocks.items(),key=lambda q:(q[0][0]+q[0][2],q[0][1])):
    # The fence and cap height is visible in the preview as well as the actual course.
    height=.1875 if name=='iron_trapdoor'else 1.5 if name.endswith('_fence')else 1
    inset=.375 if name.endswith('_fence')else 0
    x0,z0,x1,z1=x+inset,z+inset,x+1-inset,z+1-inset
    top=[proj(x0,y+height,z0),proj(x1,y+height,z0),proj(x1,y+height,z1),proj(x0,y+height,z1)]
    c=color(name);shade=lambda s:tuple(int(v*s)for v in c)
    if (x,y,z+1)not in blocks:draw.polygon([top[2],top[3],proj(x0,y,z1),proj(x1,y,z1)],fill=shade(.62))
    if (x+1,y,z)not in blocks:draw.polygon([top[1],top[2],proj(x1,y,z1),proj(x1,y,z0)],fill=shade(.82))
    if (x,y+1,z)not in blocks or height!=1:draw.polygon(top,fill=c)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',28);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
draw.text((45,35),'KASABA • KIYAMET PARKURU',font=font,fill='#f0c279')
draw.text((45,78),'48 bölüm · 9 engel ailesi · 33 yön değişimi · Düşüşte en başa',font=small,fill='#c2bdcf')
draw.text((45,h-45),'Gerçek Anvil bloklarından izometrik önizleme; oyun istemcisi ekran görüntüsü değildir.',font=small,fill='#c2bdcf')
im.save(root/'validation/actual-world-isometric.png');print('Rendered',len(blocks),'actual blocks; registered states',len(palette))
