# KasabaTR Skyblock 1.1.0 — Kurulum ve güncelleme

Mevcut KasabaTR ağı için Paper 1.21.10 / Java 21. KasabaAuth ve KasabaAkce mevcut ağda kurulu kalmalıdır. Bu, eski Skyblock 1.0.0 paketinin yerine geçen güncellemedir.

1. Sunucuyu tamamen durdur. `kasabatr_skyblock`, `plugins/KasabaSkyblock`, `plugins/KasabaRoles`, `plugins/KasabaHub` ve `plugins/KasabaEvcil` klasörlerini yedekle.
2. `plugins` içindeki eski **KasabaSkyblock**, **KasabaHub**, **KasabaEvcil** ve **KasabaRoles JAR dosyalarını** kaldır. **Veri klasörlerini silme.** ZIP'teki dört JAR'ı koy: Skyblock **1.1.0**, Hub **1.12.0**, Evcil **1.2.0**, Roles **1.6.1**. Kurucu renk güncellemesi Roles 1.6.1 içindedir. Hub ve Evcil güncellemelerini atlama.
3. Sunucuyu başlat. Konsolda `Skyblock hazır` ve Paper'ın `Done` satırlarını bekle. İlk merkez oluşturma ve mevcut merkezin yenilenmesi zaman alabilir; `/reload` kullanma.
4. `/warp sb lobi` ile yeni kasabaya gel. Yeni oyuncu Ada Yolcusu veya `/sb olustur` ile adasını açar. Eski oyuncunun adası, üyelikleri, çantası ve bakiyeleri korunur.

## Kullanıcının bildirdiği sorunlar ve yeni akışlar

- **`/market`**: Skyblock oturumundayken normal malzeme marketini açar. Diğer yerlerde ağın mevcut market komutu devam eder. `/sb market` de çalışır.
- **Alışveriş**: Kategori → ürün → miktarı artır/azalt → alış/satış yönü → toplamı gör → **ONAYLA**. Ürün simgesine her tıklama +1; ayrıca ±1, ±16 ve ±64 düğmeleri var. Seçim sırasında ödeme yapılmaz. Yetersiz bakiye veya dolu çantada işlem tamamlanmaz. VIP satış bonusu toplamda gösterilir.
- **Otomatik toplama**: Kırdığın blokların, avladığın yaratıkların ve tuttuğun balıkların ürünleri doğrudan çantana gider. Yakındaki sahipsiz ada ürünleri de izinli en yakın oyuncuya toplanır. Çanta dolunca eşyalar kişisel, kalıcı **emanete** gider; `/sb emanet` ile yer açtıkça alırsın. Elle attığın eşyalar otomatik geri çekilmez. Ziyaretçinin eşya toplama izni ayrıca uygulanır.
- **Ağaç devrilmesi**: Doğal, yapraklı ağacı en alttan kesince %75 olasılıkla devrilme animasyonu ve otomatik toplama olur. %25 durumda normal tek blok kırılır. Eğilerek kesmek tek blok modudur. Oyuncunun yerleştirdiği kütük yapıları ve sınır dışındaki bloklar topluca kırılmaz. Çok büyük ağaçlar güvenli sınırlar içinde değerlendirilir.
- **Usta Poyraz**: `/sb rehber yanima` güvenli boş zemine çağırır. `/sb rehber kapat` gizler, `/sb rehber ac` gösterir. Konum ve görünüm kaydedilir; ayarlar ada sahibine aittir. Rehber menüsü gizliyken de `/sb rehber` çalışır.
- **Hazır taş ocağı**: Yeni adanın doğusunda gerçek su/lav jeneratörü hazır kurulur. Sarı işaretin önündeki oluşan taşı kaz. Eski adada `/sb jenerator` yalnız boş ek alana kurar; mevcut yapıyı silmez. Alan doluysa rehberdeki tarifi kullan. İleride jeneratör seviyesini ayrıca yükseltirsin.
- **Görev defteri**: `/gorevler` veya `/sb gorev`. Beş kalıcı yol, günlük ve haftalık hedefler ayrıdır. Her hedefte ne yapacağın, kalan miktar, ilerleme ve ödülün gideceği hesap yazılıdır. **Altın ada kasasına**, XP adaya, Mühür kalıcı üyelere gider. Malzeme teslimatları ayrı sekmededir.
- **Uçuş hızı**: `/sb ucus hiz` menüsü veya `/sb ucus hiz 1–10`. 1 normal, varsayılan 2×, en çok 10× hız. Seçim kalıcıdır; VIP/kart uçuş hakkı ve ada izinleri ayrıca gerekir. OP hesapları `/ucushizi 1–10`, `/flyspeed 1–10` ve `/sb ucus hiz 1–10` komutlarını bütün dünyalarda kullanabilir; OP tercihi dünya değişiminde de korunur. Normal oyuncunun Skyblock çıkışında önceki ağ uçuş hızı geri gelir. Hız seçimi kendi başına uçuş yetkisi vermez.
- **Sağ ve üst bilgi**: Altın/Mühür/Kredi, ada seviyesi, takım, jeneratör, minyon yuvası ve alınan görev ödülleri sağda; sıradaki hedef üst çubukta; kısayollar TAB ekranında gösterilir. `/sb panel ac|kapat` Skyblock panelini yönetir. Çıkışta önceki oyun görünümü geri gelir.
- **Kâbuslar**: Doğal doğmaları kapalıdır; eski parçalardan yüklenen saldırgan kâbuslar temizlenir ve oyuncuya hedef/hasar vermeleri engellenir. **Kâbus** ayrıca `/evcil` kataloğunda ve `/evcil kabus` ile açılan onay ekranındadır. Mevcut evcil fiyatı 10 Akçe; kullanılmamış ilk VIP evcil hakkı aynı kuralla geçerlidir. Evcil kâbus saldırmaz, güneşte yanmaz; adada da takip eder.
- **Oyun seçimi**: Ayrı `Skyblock İlk Yardım` düğmesi kaldırıldı. Skyblock, en üstte tek geniş giriş olarak durur; diğer oyunlar altta sayfalıdır. Rehber Skyblock içinde kalır.

## Warp noktaları

`/warp sb` yol haritasını açar. `/warp sb lobi` ağ lobisinden de güvenli Skyblock girişini yapar.

| Komut | Nokta |
| --- | --- |
| `/warp sb lobi` | Rüzgâr Meydanı / Skyblock merkezi |
| `/warp sb rehber` | Kasaba Rehberi |
| `/warp sb adalar` | Ada Yolcusu |
| `/warp sb market` | Gök Pazarı |
| `/warp sb atolye` | Üretim Ustası |
| `/warp sb gorev` | Görev Konağı |
| `/warp sb muhur` | Mühür Hanı |
| `/warp sb vip` | Gezgin Ofisi |
| `/warp sb siralama` | Ada Kâtibi |
| `/warp sb iskele` | Rüzgâr İskelesi |

`/sb ev` kendi adana döner. Skyblock içindeki `/spawn` kasaba meydanına, `/lobi` ağın ana lobisine götürür. Skyblock dışındaki mevcut warp sistemi korunur.

## Yeni kasaba ve OP düzenlemesi

Merkez özgün dağ sırtları, orman kenarları, gölet/şelale, işaretli sokaklar, döşenmiş hanlar, çatı/çatı pencereleri, bacalar, pazar, saat kulesi, yel değirmeni, balon iskelesi, sekiz işlevli NPC ve dolaşan kasabalılar içerir. Oyuncuların özel adalarına dokunmaz. Eski 1.0.0 merkezi yenilenirken yalnız merkeze ait bölge dosyalarının yedeği `plugins/KasabaSkyblock/merkez-yedekleri` altına alınır. Tasarım bir kez kurulur; sonraki normal başlatmalarda OP'nin yaptığı merkez değişiklikleri silinmez.

Giriş yapmış OP/Kurucu Skyblock'tayken **`/yonet duzenleme ac`** ile bulunduğu dünyayı doğrudan düzenleyebilir; `/lobi` şartı yoktur. Yaratıcı mod ve serbest sınır açılır. **`/yonet duzenleme kapat`** önceki oyun modunu ve korumaları geri getirir; izinsiz boşlukta kaldıysan güvenli alana dönersin. Normal oyuncular bunu açamaz. Diğer oyunların geçici aktif maç kopyaları için korumalar devam eder.

Kurucu etiketi altın (`#E5B85C`), oyuncu adı açık fildişi (`#FFF0C2`), sohbeti açık nötr (`#F2EDE0`) olarak yenilenir. Eski renk ayarı bir kez yedeklenip güncellenir; yetkiler ve diğer rütbeler korunur.

## Mevcut sistemler

Tek dünya, tam 100×100 özel ada; koruma Y=-64…319 boyunca, ek dikey sınır yok. Minecraft'ın gerçek yüksekliği sonsuz değildir. Sahip dahil varsayılan dört kişilik takım, ziyaret/kooperatif, 17 grup izni, 40 görev, dokuz dönemlik teslimat, 586 ürün / dokuz kategori, beş jeneratör seviyesi, dört minyon, 12 spawner, ortak kasa, oyuncu pazarı, ada sıralaması, Altın/Mühür/Kredi ve süreli VIP sistemleri devam eder. Arkadaşlar dahil oyuncular varsayılan gizlidir; `show-island-members: true` kalıcı üyeleri birbirine gösterir. `ada` / Adanı Yap ayrıdır; Towny/Sikke/Vault/Chunky eklenmez.

Kredi yükleme konsol komutu değişmedi: `skyblock yonet kredi Oyuncu 100.00 benzersiz-siparis-kodu`. Bu paket gerçek para ödeme sitesi/sağlayıcısı kurmaz. Altın yüklemek için oyun içinde yönetici hesabıyla `/sb yonet altin Oyuncu 100000` kullanılır.
