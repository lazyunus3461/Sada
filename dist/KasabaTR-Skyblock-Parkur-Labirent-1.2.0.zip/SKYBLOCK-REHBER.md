Uçuş hızı: `/sb ucus hiz` menüsü veya `/sb ucus hiz 1–10`. Varsayılan 2× normal; seçim kalıcı, uçuş hakkı/ada izni ayrı, çıkışta ağdaki önceki hız geri yüklenir.

# Skyblock 1.1.0 yenilikleri

/market artık adada normal marketi açar. Yeni markette miktarı tıklayarak biriktir, alış/satış yönünü seç ve toplamı gördükten sonra onayla. /gorevler beş gelişim yolu ve ayrı günlük/haftalık hedeflerden oluşan anlaşılır görev defterini açar.

Kırılan bloklar, av ve balık ürünleri çantaya; doluysa /sb emanet deposuna gider. Doğal yapraklı ağaçların dipten kesilmesinde %75 devrilme efekti vardır; eğilerek tek blok kesilir, oyuncu kütük yapıları topluca kırılmaz. Yeni adada gerçek su/lav jeneratörü hazırdır; eski adada /sb jenerator boş ek alanı kullanır.

Ada rehberi Usta Poyraz: /sb rehber yanima, /sb rehber kapat, /sb rehber ac. Ada sahibinin seçtiği konum ve görünürlük korunur. Sağ panel Skyblock bakiyelerini ve ada gelişimini, üst çubuk sıradaki görevi, TAB ise oyun kısayollarını gösterir.

/warp sb lobi, market, gorev, atolye, muhur, vip, rehber, adalar, siralama, iskele. Dağlarla çevrili yeni Rüzgâr Kasabası; döşenmiş hanlar, işaretli sokaklar, gölet, şelale, yel değirmeni ve balon iskelesi içerir. OP için /yonet duzenleme ac artık Skyblock'tan çıkmadan çalışır. Doğal ve eski kayıtlı kâbuslar saldırmaz; ayrı Kâbus evcili Evcil1.2.0 ile gelir.

Tam kurulum ve güncelleme: ZIP'teki KURULUM.md. Gereken JAR'lar Skyblock1.1.0, Hub1.12.0, Evcil1.2.0, Roles1.6.1. Veri klasörlerini silmeyin. Aşağıda devam eden sistemlerin ayrıntılı rehberi vardır.

# KasabaTR Skyblock 1.0.0

Paper 1.21.10, Java 21 ve mevcut KasabaTR ağı için hazırlanmıştır. KasabaHub 1.11.0, KasabaRoles 1.6.0 ve mevcut KasabaAuth gerektirir. SQLite sürücüsü Paper tarafından sağlanır; ayrıca veritabanı sunucusu gerekmez.

## Oyun

Tek kalıcı boşluk dünyası: `kasabatr_skyblock`. Her ada **tam 100×100 blok**; komşu merkezler arasında 2048 blok vardır. Alan dünya tabanından tavanına kadar korunur: normal Minecraft dünyasında **Y=-64…319**. Eklenti ek bir dikey sınır koymaz. Fiziksel olarak sonsuz yükseklik yoktur.

İlk ada ücretsizdir; hesap aynı anda bir adaya üye olabilir. Başlangıç sandığı, ağaç, yedek fidanlar, su/lav, tohumlar, yiyecek ve ilk yardım kitabı otomatik hazırlanır. Merkez bedrock ve üstündeki doğma boşluğu korunur. Boşluğa düşen oyuncu adasına kurtarılır. Diğer normal ölümlerde vanilla eşya düşürme kuralları geçerlidir.

Arkadaş daveti ve ortak ada desteklenir; varsayılan 4 kişi (sahip dahil). Yetkisiz başka adalara giriş, blok değiştirme ve eşya alma engellenir. Sahibi kişiye özel ziyaret veya kooperatif daveti verebilir. Oyuncular varsayılan olarak arkadaşları dahil gizlenir; üyelerin birbirini görmesi için `show-island-members: true` yapılabilir. Görünürlük ayarı sunucu yeniden başlatıldığında uygulanır.

## İlk yardım ve ilerleme

`/sb rehber` oyuncuya bir komut listesi yerine şu oyun aşamalarını anlatır: ağacı/fidanı koruma, ilk kazma ve çalışma masası, su-lav jeneratörü tarifi, sonsuz su/tarım, ilk satış/ada kasası, görev ödülleri, jeneratör geliştirme, minyon üretimi ve ileri hedefler. Yapılan işlemler rehberdeki sıradaki öneriyi günceller. Bilinen aşama ayrıca “Bu adımı anladım” ile geçilebilir; bu düğme para veya deneyim vermez. Adadaki yardımcıya sağ tıklamak aynı rehberi açar. Kitap başlangıç sandığındadır.

40 ilerleme görevi + 9 dönemlik teslimat vardır: 32 kalıcı zincir görevi, 4 günlük ve 4 haftalık. Madencilik, olgun hasat, gerçek balık, düşman avlama ve mevcut oyuncu yapıları sayılır. Madenci görevleri yalnız su-lav jeneratörünün ürettiği bloklardan ilerler; yerleştirilmiş cevheri kırmak ilerletmez. Yapı hedefi mevcut yerleştirilmiş blokları sayar; kırıp aynı bloğu koyarak sayaç biriktirilmez. Takım üyeleri ortak ilerler ve ödül ortak kasaya bir kez verilir. Günlükler Türkiye saati 00.00, haftalıklar pazartesi 00.00 yenilenir. Ödüller yenilenmeden alınmalıdır.

`/sb teslim` ayrıca 3 günlük, 3 haftalık ve 3 aylık malzeme teslimatını açar. Çantadaki normal malzemeler eksik miktar kadar tüketilir; parçalı teslim korunur. Ödül ortak kasaya bir kez gider. Bir dönemin 3 teslimatı da biterse toplam sözleşme ödülünün %25'i ayrıca verilir. Gün/hafta/ay Türkiye saatine göre yenilenir. Günlük teslimat başlamadan önce sahip 100 Altın ortak kasa ödeyerek değiştirebilir; ada başına günde en fazla 3 değişiklik. Aylık hedefler yüksek miktarda kaynak üretimi için uzun vadeli hedeftir. Altın ortak kasaya gider; Mühür her kalıcı üyeye eşit verilir. Günlük teslimat 6, haftalık 30, aylık 90 Mühür; dönem tamamlama bonusu bir teslimat kadar ek Mühürdür.

## Ziyaret, kooperatif ve izinler

`/sb ayarlar` ziyaretçi, kalıcı üye ve kooperatif izinlerini ayrı kategorilerde açar. Ada sahibi her grup için 17 yetkiyi değiştirir: blok kırma/yerleştirme, sandık, üretim masaları, kova, kapı, kızıl taş anahtarları, yaratık hasarı, hayvan etkileşimi, eşya toplama/bırakma, balıkçılık, minyon toplama/yakıt, görev ödülü, kasaya katkı ve lisansla uçuş. Sahip daima yetkilidir; kasa çekme, geliştirme ve spawner düzenleme yalnız sahibe aittir.

`/sb ziyaret davet Oyuncu` salt gözlem için kişiye özel davet gönderir; `/sb ziyaret kabul` ile kabul edilir. Ziyaretçi varsayılan olarak blok, sandık ve ürünlere dokunamaz. `/sb koop davet Oyuncu` ve `/sb koop kabul` geçici birlikte çalışma erişimi verir. İki tür de en fazla 30 dakika sürer; daveti kabul etmek için 60 saniye vardır. Her adada en fazla 8 geçici erişim. Kalıcı ada üyeliği değişmez. Bitişte oyuncu kendi adasına veya Skyblock girişine döner; sahibi `/sb ziyaret bitir Oyuncu` veya `/sb koop bitir Oyuncu` ile daha erken kaldırabilir. Oyuncu `/sb ziyaret ayril` veya `/sb koop ayril` kullanabilir. Geçerli erişime yeniden gitme: `/sb ziyaret git` veya `/sb koop git`.

Davetler yalnız seçilen adaya erişim verir; diğer adalar kapalıdır. Oyuncu gizleme ayarı ziyaretlerde de geçerlidir. Sırf davet almak özel üretim veya kasa sahipliği hakkı vermez; grup izinleri uygulanır.

## Ekonomi ve üretim

Skyblock parası **Altın**dır; Akçe ve VIP kredisiyle ayrıdır. Ürün satışı kişisel cüzdana, görev ödülü ortak ada kasasına gider. Üyeler kasaya yatırabilir; yalnız sahip çekebilir ve geliştirme yapabilir. Normal kaynak marketi 586 ürünle 9 kategori içerir: temel, renkli ve yapı blokları; odunlar/fidanlar; tarım/yiyecek; yumurtalar/mob eşyaları; madenler; aletler/ileri kaynaklar; kızıl taş/makineler. Alış fiyatı satış fiyatından yüksektir.

Jeneratör 5 seviyedir; yükseltme ada deneyimi ve ortak kasa gerektirir. Cevher yüzdeleri geliştirme menüsündedir. Taşçı, Oduncu, Çiftçi ve Balıkçı minyonları; yakıt, 3 seviye, depo ve yer taşıma destekler. İlk kurulum 500 Altın ortak kasa + türüne uygun 32 üründür. Her kömür varsayılan 30 dakika yakıt verir. Üretim 30/20/10 saniyede bir üründür; depo 64×minyon seviyesi×ada depo çarpanı. Başlangıç 2 yuva, en fazla 6 yuva. Çevrimdışı hesap en fazla 6 saattir; dolu depoda yakıt tüketimi durur. Oyuncu çevrimdışıyken ada chunk'ları açık tutulmaz. Minyon üretimi etkinlik süresi/Akçe kazancı sayılmaz.

12 tür seviye gerektiren spawner; varsayılan ada başına 4 spawner, 16 huni ve 32 yaratık sınırı. Spawner yerleştirme/kırma yalnız sahibine aittir ve kırınca eşyası çantaya geri gelir; çanta doluysa işlem yapılmaz. Spawner yalnız yüklü adada, yakında oyuncu varken çalışır. Hayvanlar için uygun zemin/ışık, su yaratıkları için uygun su alanı gerekir. Nether ve End geçişi bu tek dünya düzeninde kapalıdır; gereken malzemeler markettedir.

Oyuncu pazarı eldeki eşyayı emanete alır: kişi başı 5 ilan, 24 saat süre, satışta %5 kesinti. Alıcı parası, satıcı kazancı, emanet ve alıcı çantası aynı SQLite işlemiyle yazılır. Dolu çanta veya yetersiz bakiye işlemi geri alır. Süresi dolan/iptal edilen ilan sahibi tarafından geri alınır; eşya çevrimdışı oyuncunun önüne atılmaz.

## Komutlar

- `/sb gir`, `/sb`, `/sb olustur`, `/sb ev`, `/sb giris`, `/lobi`
- `/sb rehber`, `/sb gorev`, `/sb odul görev-kodu`, `/sb gelistirme`, `/sb top`
- `/sb market`, `/sb al MALZEME adet`, `/sb sat MALZEME adet`, `/sb para`
- `/sb banka`, `/sb banka yatir|cek miktar`, `/sb gonder Oyuncu miktar`
- `/sb takim`, `/sb davet Oyuncu`, `/sb kabul`, `/sb reddet`, `/sb at Oyuncu`, `/sb ayril`, `/sb devret Oyuncu`
- `/sb minyon`, `/sb minyon kur tasci|oduncu|ciftci|balikci`
- `/sb minyon yakit yuva adet`, `/sb minyon topla|yukselt|tasi|kaldir yuva`
- `/sb spawner`, `/sb pazar`, `/sb ilan fiyat`, `/sb ilan-geri kod`
- Yönetici: `/sb yonet`, `/sb yonet altin Oyuncu miktar`. Dünyayı düzenleme mevcut `/yonet` hizmetinin açık düzenleme oturumuna bağlıdır; sırf OP olmak ada korumasını atlatmaz.

Menülerde aynı işlemler miktar seçimi ve geri düğmeleriyle sunulur. Davet ve serbest fiyat gibi yazı gerektiren adımlar komutla tamamlanır. Ada adı kurulumda sahibinin adıyla oluşturulur. Ada sahibi yalnızsa `/sb adabirak` onay ekranıyla adaya erişimini kapatıp bir arkadaşının adasına katılabilir. Yapılar arşivlenir ve ada kimliği başkasına verilmez; yeni ada kurmak için 24 saat bekler. Üyeli adada önce sahiplik devredilmeli veya üyeler çıkarılmalıdır. Otomatik yapı silme ve sıfırdan ada resetleme açık değildir.

## Özgün gökyüzü kasabası

Aynı dünyadaki başlangıç kasabası yaklaşık 145×133 blokluk doğal bir uçan ada üzerinde hazırlanır; merkez ziyaret sınırı 160×160'dır. Bu ölçü yalnız ortak merkez içindir; özel adalar hep 100×100 kalır. Pazar meydanı, bakır çatılı hanlar, Görev Konağı, Üretim Atölyesi, tarla bahçesi, saat kulesi, bahçeler, yel değirmeni ve balon iskelesi kendi blok yerleşimimizdir. Merkez bu paket için oluşturulmuş özgün blok yerleşimidir.

8 NPC: Kasaba Rehberi, Ada Yolcusu, Gök Pazarı, Üretim Ustası, Görev Yazmanı, Mühür Tüccarı, Gezgin Ofisi ve Ada Kâtibi. Sağ tıkla ilgili menü açılır. İlk girişte Ada Yolcusu/rehber üzerinden kendi adana geç. Merkezde yapılar, NPC'ler ve dekorlar korunur. Merkez lobi sayılır; etkinlik Akçesi üretmez.

`merkez-tasarimi-v3.txt` üretilen merkezin dünya kimliği kaydıdır; sonraki açılışlarda yapılar yeniden kurulmaz. Bu kaydı silmek merkezi yeniden oluşturur; normal kurulum ve güncellemede silme. NPC'ler geçicidir ve yüklü merkezde yeniden görünür; oyuncu adaları açık tutulmaz. Dağıtımdaki önizleme gerçek test dünyası bloklarından çizilen yerleşim görüntüsüdür, Minecraft istemci ekran görüntüsü değildir.

## Mühür, Kredi ve özgün destek mağazası

**Mühür** oynayarak kazanılır. İlerleme görevlerinde kalıcı üyelerin her birine en az 1 Mühür; daha ileri görevlerde daha fazla verilir. Günlük/haftalık/aylık malzeme sözleşmeleri sırasıyla 6/30/90 Mühür verir. Bir dönemin 3 sözleşmesi tamamlanınca bir sözleşme kadar ek Mühür kazanılır. Ödül anındaki kalıcı üyelere eşit verilir; Kredi değildir.

`/sb muhur` Mühür Tüccarı: Bereket Çantası 35, Atölye Tedariki 75, Pazar Yıldızı 150, Usta Sandığı 120, 7 günlük Gezgin VIP 300 Mühür. Kaynak çantaları ve Usta Sandığı günde bir alınır. Pazar Yıldızı kalıcı ilan yıldızı/parlaması açar. Usta Sandığı yalnız Mühür ile açılır; spawner olasılıkları %50 temel hayvan, %30 zombi/iskelet/örümcek, %15 Blaze, %5 demir golem. Yerleştirme için ilgili ada seviyesi gerekir. Olasılıklar alış öncesi menüde yazılıdır.

**Kredi** ayrı destek mağazası bakiyesidir. Konsoldan `skyblock yonet kredi Oyuncu miktar benzersiz-islem-kodu` yüklenir; aynı kodla tekrar yüklenmez. Kredi oyuncular arasında `/sb kredi gonder Oyuncu miktar` ile hediye edilebilir. İşlem defterinden hediye kabulü kapatılabilir; alım ve hediye geçmişi kalıcıdır. Bu eklenti ödeme sağlayıcısı/web sitesi değildir; mevcut mağaza başarılı siparişten sonra bu konsol komutunu çalıştırabilir.

| 30 günlük paket | Kredi | Kademe | İlk hediye |
| --- | ---: | --- | --- |
| Gezgin | 120 | VIP | 40 Mühür, 16 kömür, 16 kemik tozu |
| Usta | 220 | VIP+ | 100 Mühür, 32 kömür, 32 kemik tozu |
| Mimar | 360 | VIP Ultra | 200 Mühür, 48 kömür, 48 kemik tozu |

Temel VIP süre dosyası korunur; üst kademeler `vip-kademeleri.yml` içinde ayrı sürelerle tutulur. Aynı kademeyi yeniden almak süresini uzatır. Etkin üst kademe varken daha düşük paket alınmaz; kalıcı aynı kademe varsa aynı paket alınmaz. Satın alma para/hediye kaydıyla tek işlemde yazılır; VIP hizmeti geçici hata verirse mutlak bitiş tarihli sipariş tekrar denenir. Tekrar denemek yeni ücret veya ikinci hediye üretmez. VIP kademesi diğer oyunlardaki mevcut VIP haklarıyla aynı Role hizmetini kullanır; yönetici yetkisi vermez.

Skyblock kolaylıkları `/sb vip` menüsündedir:

- Uçuş: VIP veya 40 Kredi/7 günlük Rüzgâr Kartı ve adanın grup uçuş izni. `/sb ucus` ile açılır. Yetki/süre bitince uçuş kapanır; oyuncu havadaysa güvenli ada doğma noktasına döner; diğer oyunlara taşınmaz.
- Eldeki eşya tamiri: Gezgin 6 saat, Usta 1 saat, Mimar 15 dakika bekleme. `/sb tamir`.
- Toplu tamir: Usta 12 saat, Mimar 4 saat bekleme. `/sb tamir hepsi`.
- Doyurma: 20/10/5 dakika bekleme. `/sb doyur`.
- Sanal çalışma masası ve ayrı Skyblock ender sandığı.
- Günlük hediye: 500/1000/1500 Altın ve 1/2/3 Mühür, Türkiye günü başına bir kez. `/sb vipgunluk`.
- Normal market satışlarında %5/%10/%15 ek Altın. Alış ve teslimat sözleşmeleri bu bonusla değişmez.

Kredi mağazasında sabit kaynak çantaları ve kalıcı Pazar Yıldızı da vardır. Fiyat ve içerikler alış öncesi gösterilir; ürün alımları onay ekranı ister. Yetersiz bakiye veya dolu çantada eşya/para işlemi birlikte geri alınır. VIP/kredi fiyatları videodan kopyalanmamış Kasaba paketleridir.

## Kayıt ve yedek

`plugins/KasabaSkyblock/skyblock.db` ada, üyelik, cüzdan, kasalar, görevler, minyonlar ve pazarın kaydıdır. Skyblock çantası, ender sandığı, XP ve lobi kurtarma profili ayrıdır. Normal çıkışta ve düzenli aralıklarla kaydedilir; kontrollü ekonomik işlemler eşya profiliyle birlikte tek veritabanı işlemi kullanır. Sunucu dururken **dünya klasörü, Skyblock eklenti veri klasörü ve KasabaRoles veri klasörü birlikte** yedeklenmelidir. VIP süreleri Roles içindeki `vip-sureleri.yml` ve `vip-kademeleri.yml` dosyalarındadır. Sunucu çalışırken yalnız `.db` dosyasını kopyalamak yerine durdurarak yedek alın; SQLite WAL yan dosyaları bulunabilir.

`ada` dünyasına ve KasabaAdalar verilerine dokunulmaz. Towny, Sikke, Vault veya Chunky bu paketin bağımlılığı değildir. VIP ve destek mağazaları bu rehberde açıklanmıştır; eski Akçe bakiyeleri korunur.

## Doğrulama

Test sonuçları dağıtımın `TESTLER` klasöründedir. Yerel Paper ortamı ve protokol istemcileri kullanılır; canlı kullanıcı sunucusuna kurulmuş sayılmaz. Özel test adaptörü dağıtıma alınmaz. Video araştırması tamamlanmış/10 video izlenmiş olarak sunulmaz.
