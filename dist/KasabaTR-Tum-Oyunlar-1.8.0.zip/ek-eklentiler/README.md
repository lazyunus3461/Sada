# KasabaTR ek eklenti kurulumu

Bu dört üçüncü taraf JAR bu çalışma ortamında **indirilemedi**: resmî sürüm API'leri 403 döndürdü. Sahte dosya eklenmedi. Resmî kaynak kodlarının ayar ve API şemaları incelendi; gerçek üçüncü taraf sunucu testi henüz yapılmadı.

Bilgisayarında `EK-EKLENTILERI-INDIR.cmd` çalıştır. GrimAC, DriveBackupV2 ve MiniMOTD için Modrinth'ten Minecraft **1.21.10** ile işaretlenmiş kararlı **Paper/Spigot/Bukkit** sürümünü seçer ve SHA512 doğrular. Uygun sürüm bulunmazsa başka sürümü otomatik yüklemez. SimplePets, üreticinin README'de verdiği resmî Jenkins kaynağından gelir; JAR tanımının adı kontrol edilir ve yerel SHA256 kaydı tutulur. SimplePets NMS kodunda 1.21.10 (`v1_21_R6`) desteği bulundu; ilk açılış konsolundaki sürüm yüklemesini ayrıca kontrol et.

İndirilen dosyalar ve ayarlar `kuruluma-hazir/plugins` altındadır. Sunucuyu kapat, aynı eklentinin eski JAR dosyasını kaldır, yeni dosyaları yükle. Mevcut veri klasörlerini silme. Daha önce özel ayarın varsa örnek ayarları karşılaştır; doğrudan üzerine yazma. Bu araç sunucuya bağlanmaz, dosyaları yalnız kendi bilgisayarında hazırlar.

- **GrimAC:** İlk kurulum gözlem içindir. Otomatik ban/kick komutu yok; normal hareket düzeltmeleri özel hareketleri bozmasın diye geri atma eşikleri kapatıldı. Tespitler kayda/yetkili uyarısına gider; bu ayar tam otomatik hile cezası değildir. OP olmayan iki gerçek oyuncuyla at/tekne, uçuşlu saklambaç, X Arena atılımları, BR inişi ve parkur testinden sonra cezaları sıkılaştır. Sadece OP ile test etme; OP için hile kontrolleri farklı davranabilir. `/grim alerts`, `/grim verbose`, `/grim reload`.
- **DriveBackupV2:** Saatte bir, oyuncu olmasa da yerel yedek; son 24 kopya. Adalar, arena, BR, VK ve `KasabaTR-*` dünyaları, eklenti verileri ve Paper ayarları kapsanır. Geçici `*_room_*` maç kopyaları arşivlenmez. `KasabaYedekler` klasörü kaynak listesinde yok; yedek kendi içine girmez. Bulut sağlayıcıları kapalıdır; Google/OneDrive şifresi/tokeni verilmediği için uzaktan yedek bağlı sayılmaz. Aynı diskteki yedeğin dışında zaman zaman panelden bir kopya indir. `/drivebackup backup` ile ilk kopyayı ve panel disk kullanımını kontrol et.
- **MiniMOTD:** KasabaTR renkli iki satır; sahte oyuncu sayısı ve sahte kapasite kapalı. Listede isimlerin gösterilmesi kapalı; gerçek çevrimiçi sayı korunur. `/minimotd reload`.
- **SimplePets R5:** `/evcil` veya `/pet`. Pet sayısı normal oyuncuda 1; binme kapalı, ulaşım aracı olarak kullanılamaz. KasabaHub, pet üretim olayında sahibinin gerçekten spawn/güvenli lobide olduğunu kontrol eder, maç/ada/seyirci sırasında petleri kaldırır. Diğer oyunların yaratık engeli yalnız gerçek, güvenli lobideki sahibine bağlı SimplePets canlılarını kabul eder. API uyumsuzsa sınırlama atlanmaz; SimplePets kapatılır. Özel oda dünyaları otomatik izinli değildir. Varsayılan oyuncu rolüne kedi ve kurt izinleri eklenir; daha önce açıkça verdiğin yasaklar korunur. Diğer türler açılmaz. İstersen daha sonra ek tür seçebilirsin.

Resmî indirmeler:

- https://modrinth.com/plugin/grimac
- https://github.com/GrimAnticheat/Grim/releases
- https://github.com/MaxMaeder/DriveBackupV2/releases
- https://modrinth.com/plugin/minimotd
- https://github.com/jpenilla/MiniMOTD/releases
- https://jenkins.bsdevelopment.org/job/SimplePets/

İncelenen kaynak commitleri `KAYNAK-VE-SINIRLAR.json` dosyasındadır. API uyarlaması JAR içinde üçüncü taraf kodu veya indirilen yazılımı çalıştırmaz; ses için istenen tek istemci modu Simple Voice Chat olarak kalır.
