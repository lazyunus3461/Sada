$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression.FileSystem
$outDir = Join-Path $PSScriptRoot 'kuruluma-hazir'
$pluginsDir = Join-Path $outDir 'plugins'
New-Item -ItemType Directory -Force -Path $pluginsDir | Out-Null
$headers = @{ 'User-Agent'='KasabaTR-Setup/1.8'; 'Accept'='application/json' }
$manifest = @()
function Receive-Plugin($url, $name, $sha512) {
  $uri = [Uri]$url
  if($uri.Scheme -ne 'https' -or $uri.Host -notin @('cdn.modrinth.com','github.com','jenkins.bsdevelopment.org','builds.bsdevelopment.org')) { throw "Beklenmeyen indirme kaynagi: $($uri.Host)" }
  $tempFile = Join-Path $pluginsDir ([Guid]::NewGuid().ToString()+'.download')
  try {
    Invoke-WebRequest -UseBasicParsing -Headers $headers -Uri $url -OutFile $tempFile
    if($sha512 -and (Get-FileHash $tempFile -Algorithm SHA512).Hash.ToLowerInvariant() -ne $sha512.ToLowerInvariant()) { throw 'SHA512 dogrulamasi basarisiz' }
    $zip = [IO.Compression.ZipFile]::OpenRead($tempFile)
    try {
      $entry = $zip.GetEntry('plugin.yml'); if(!$entry) { $entry=$zip.GetEntry('paper-plugin.yml') }
      if(!$entry) { throw 'Sunucu eklentisi tanimi yok; istemci modu indirilmez.' }
      $reader=New-Object IO.StreamReader($entry.Open());try{$definition=$reader.ReadToEnd()}finally{$reader.Dispose()}
      if($definition -notmatch ('(?m)^name:\s*'+[regex]::Escape($name)+'\s*$')) { throw "Beklenen eklenti adi bulunamadi: $name" }
      if($name -eq 'SimplePets' -and !($zip.Entries | Where-Object { $_.FullName -match '1_21_10|v1_21_R6|1\.21\.10' })) { Write-Warning 'SimplePets 1.21.10 destegi kaynakta mevcut; NMS bileseni ilk acilista ayrica inebilir. Surum satirini konsoldan kontrol edin.' }
    } finally { $zip.Dispose() }
    $hash=(Get-FileHash $tempFile -Algorithm SHA256).Hash.ToLowerInvariant()
    $destination=Join-Path $pluginsDir ($name+'-'+$hash.Substring(0,12)+'.jar')
    if(Test-Path $destination) { if((Get-FileHash $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hash){throw 'Var olan dosyanin uzerine yazilmaz'} } else { Move-Item $tempFile $destination }
    $script:manifest += [PSCustomObject]@{plugin=$name;file=[IO.Path]::GetFileName($destination);sha256=$hash;source=$url}
    Write-Host ($name+' indirildi ve sunucu JAR tanimi dogrulandi.')
  } finally { if(Test-Path $tempFile){Remove-Item $tempFile} }
}
function Modrinth-Plugin($slug,$name) {
 $query='https://api.modrinth.com/v2/project/'+$slug+'/version?loaders='+[Uri]::EscapeDataString('["paper","spigot","bukkit"]')+'&game_versions='+[Uri]::EscapeDataString('["1.21.10"]')
 $versions=Invoke-RestMethod -Headers $headers -Uri $query
 $version=$versions | Where-Object {$_.version_type -eq 'release'} | Sort-Object date_published -Descending | Select-Object -First 1
 if(!$version){throw ('1.21.10 icin kararli sunucu surumu bulunamadi: '+$slug)}
 $file=$version.files | Where-Object {$_.filename -match '\.jar$'} | Sort-Object @{Expression={$_.primary};Descending=$true} | Select-Object -First 1
 if(!$file -or !$file.hashes.sha512){throw 'Dogrulanabilir JAR bulunamadi'}
 Receive-Plugin $file.url $name $file.hashes.sha512
}
foreach($plugin in @(@{slug='grimac';name='GrimAC'},@{slug='drivebackupv2';name='DriveBackupV2'},@{slug='minimotd';name='MiniMOTD'})) {
 try{Modrinth-Plugin $plugin.slug $plugin.name}catch{Write-Warning ($plugin.name+': '+$_.Exception.Message+' Resmi indirme sayfasi README dosyasinda. Baska surum otomatik secilmedi.')}
}
try {
 $base='https://jenkins.bsdevelopment.org/job/SimplePets/lastSuccessfulBuild'
 $build=Invoke-RestMethod -Headers $headers -Uri ($base+'/api/json?tree=artifacts[relativePath,fileName],number')
 $file=$build.artifacts | Where-Object {$_.fileName -match '^SimplePets.*\.jar$' -and $_.fileName -notmatch 'sources|javadoc|api'} | Select-Object -First 1
 if(!$file -or $file.relativePath -match '\.\.' -or $file.relativePath -notmatch '^[A-Za-z0-9_./-]+$') {throw 'Resmi Jenkins JAR dosyasi secilemedi'}
 Receive-Plugin ($base+'/artifact/'+$file.relativePath) 'SimplePets' $null
}catch{Write-Warning ('SimplePets: '+$_.Exception.Message)}
$settings=Join-Path $PSScriptRoot 'ayarlar\plugins'
Get-ChildItem $settings -File -Recurse | ForEach-Object {
 $relative=$_.FullName.Substring($settings.Length).TrimStart('\','/')
 $destination=Join-Path $pluginsDir $relative
 New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
 if(!(Test-Path $destination)){Copy-Item $_.FullName $destination}
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $outDir 'INDIRILENLER-SHA256.json')
Write-Host 'Yalniz kuruluma-hazir/plugins icin dosyalar hazirlandi. Sunucuya yuklemeden once durdur; ayni eklentinin eski JAR dosyasini kaldir, veri klasorlerini silme.'
if($manifest.Count -ne 4){Write-Warning 'Dort dosyanin tamami inmedi. README resmi baglantilarini kullan; eksik dosyalar kuruldu sayilmaz.'}
