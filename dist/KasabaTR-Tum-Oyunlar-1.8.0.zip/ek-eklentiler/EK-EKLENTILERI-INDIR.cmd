@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0EK-EKLENTILERI-INDIR.ps1"
pause
