$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$releaseRoot = Split-Path $PSScriptRoot -Parent
$headers = @{ 'User-Agent' = 'KasabaTR-VoiceInstaller/1.0' }
$uri = 'https://api.modrinth.com/v2/project/9eGKb6K1/version?game_versions=%5B%221.21.10%22%5D'
try {
  $all = Invoke-RestMethod -Uri $uri -Headers $headers
  $versions = @($all | Where-Object { $_.version_type -eq 'release' -and $_.project_id -eq '9eGKb6K1' -and $_.game_versions -contains '1.21.10' })
  $servers = @($versions | Where-Object { $_.loaders -contains 'paper' -or $_.loaders -contains 'bukkit' -or $_.loaders -contains 'spigot' })
  $clients = @($versions | Where-Object { $_.loaders -contains 'fabric' })
  function Get-BaseVersion($item) { return [regex]::Match($item.version_number, '2\.6\.\d+').Value }
  $common = @($servers | ForEach-Object { Get-BaseVersion $_ } | Where-Object { $v = $_; $v -and @($clients | Where-Object { (Get-BaseVersion $_) -eq $v }).Count -gt 0 } | Sort-Object { [version]$_ } -Descending -Unique)
  if ($common.Count -eq 0) { throw '1.21.10 icin ortak kararli 2.6.x Paper/Fabric surumu bulunamadi. Resmi surum sayfasini kontrol et.' }
  $selected = @((@($servers | Where-Object { (Get-BaseVersion $_) -eq $common[0] } | Sort-Object date_published -Descending))[0], (@($clients | Where-Object { (Get-BaseVersion $_) -eq $common[0] } | Sort-Object date_published -Descending))[0])
  $folders = @((Join-Path $releaseRoot 'plugins'), (Join-Path $releaseRoot 'oyuncu-modu'))
  $manifest = @()
  for ($i = 0; $i -lt 2; $i++) {
    $item = $selected[$i]
    $files = @($item.files | Where-Object { $_.primary -and $_.filename.EndsWith('.jar') })
    if ($files.Count -ne 1) { throw 'Resmi surumun ana JAR dosyasi belirsiz.' }
    $file = $files[0]
    if ([IO.Path]::GetFileName($file.filename) -ne $file.filename -or $file.filename -notmatch '^[A-Za-z0-9_.+-]+\.jar$') { throw 'Guvenli olmayan dosya adi.' }
    $url = [Uri]$file.url
    if ($url.Scheme -ne 'https' -or $url.Host -ne 'cdn.modrinth.com') { throw 'Beklenmeyen indirme adresi.' }
    if ($file.hashes.sha512 -notmatch '^[0-9a-fA-F]{128}$') { throw 'Resmi dosya dogrulama ozeti eksik.' }
    New-Item -ItemType Directory -Force -Path $folders[$i] | Out-Null
    $target = Join-Path $folders[$i] $file.filename
    if (Test-Path $target) {
      if ((Get-FileHash -Path $target -Algorithm SHA512).Hash.ToLowerInvariant() -ne $file.hashes.sha512.ToLowerInvariant()) { throw ('Mevcut dosya farkli; uzerine yazilmadi: ' + $target) }
    } else {
      $temp = $target + '.indiriliyor'
      try {
        Invoke-WebRequest -Uri $file.url -Headers $headers -OutFile $temp -UseBasicParsing
        if ((Get-FileHash -Path $temp -Algorithm SHA512).Hash.ToLowerInvariant() -ne $file.hashes.sha512.ToLowerInvariant()) { throw 'SHA512 dogrulamasi basarisiz.' }
        Move-Item -LiteralPath $temp -Destination $target
      } finally { if (Test-Path $temp) { Remove-Item -LiteralPath $temp } }
    }
    $manifest += [pscustomobject]@{ name = $file.filename; version = $item.version_number; version_id = $item.id; sha512 = $file.hashes.sha512; source = $file.url }
    Write-Host ('Hazir: ' + $target) -ForegroundColor Green
  }
  $manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'INDIRILEN-RESMI-SURUMLER.json') -Encoding UTF8
  Write-Host 'plugins klasorunu sunucuya yukle. oyuncu-modu icindeki tek JAR Fabric 1.21.10 mods klasorune gider.' -ForegroundColor Yellow
  Write-Host 'Hosting panelinde UDP 24454 portunu ac. Ayni eklentinin eski JAR surumu kalmasin.' -ForegroundColor Yellow
} catch {
  Write-Error ('Ses dosyalari indirilemedi: ' + $_.Exception.Message)
  exit 1
}
