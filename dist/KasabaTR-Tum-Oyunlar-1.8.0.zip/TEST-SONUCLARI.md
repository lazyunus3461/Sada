# KasabaTR 1.8.0 doğrulaması

Paper 1.21.10 build 130, Java 21, sadece 127.0.0.1 üzerinde ayrılmış test sunucusu. Mevcut dünyalar ve veriler korundu. Paketlenen 20 üretim JAR'ının SHA256 değerleri gerçek sunucuda kullanılan, ses/yönetim ve HUD denemeleriyle doğrulanan JAR'larla aynıdır. Son yeniden başlatma ses API'si olmadan da kontrol edilir. Test düzeneğinin hiçbir JAR'ı dağıtıma konmaz.

## Otomatik kontroller

- 20 üretim modülü derlendi; birim test raporları `DOGRULAMA-KAYITLARI.json` içindeki `unit` bölümünde. Hata, başarısız ve atlanan test yok.
- **Hesap/IP:** gerçek ayrı loopback soket IP'leriyle ikinci kayıt reddi, mevcut adın uyarıda görünmesi, yetkisiz onay engeli, tekrar onayda en fazla iki hesap, aynı IP'den mevcut iki hesabın eşzamanlı girişi, onayı kaldırma ve bağımsız IP kaydı.
- **Ses/yönetim:** ilk başarılı hesap girişinde resmî 1.21.10/Fabric indirme düğmesi, eski düğmelerin geçersizleşmesi, eksik/bağlanıyor/kapalı/hazır durumları, VK ve Hat giriş/start kontrolü, grubun tamamının reddedilmesi, kopma sonrası cezasız dönüş; non-VIP OP ile iki kişilik testler. Yüklü 28 kalıcı dünyada açık düzenleme, yetkisiz engel, OP kaldırıldığında ve `/yonet çık` sonrasında önceki modun dönüşü.
- **VIP ayrılma:** 12 oyun/modda gerçek maçtan çıkıp anında yeniden girebilme; normal oyuncunun 15 dakika cezasının korunması; eski VIP cezasının temizlenmesi; gerçek bağlantı kopması ve tekrar giriş. `/vip` açıklaması.
- **Ada/balık:** normal 50 Akçe tek arsa, VIP iki ücretsiz arsa; ilk Creative girişi, dışarıdan `/ada git 2` ve pusulayla ana ada seçimi, envanter dönüşü; balığın envantere gelmesi, başka oyuncunun kopya balığının satılamaması, 15 balığa 0,75 Akçe ve kota.
- **Ortak/özel odalar:** Arena, iki yarış, Şans Yolu, Renk Kaçışı, Eşya Saklambacı, Boya Savaşı, Lanetli Taç, Banka Baskını, VK ve BR'de minimum sayısı/60 saniye/diğer lobilere duyuru ve otomatik başlama. VIP özel oda sahipliği, elle start, yetkisiz çıkarma engeli, çıkarılanın odaya dönememesi ve zorunlu çıkışın cezasızlığı. Gizli bilgi içeren oyunlar izlemeye kapalı; açık oyunlarda görünmez seyirci/koruma/envanter dönüşü.
- **Lonca/sohbet:** 50 Akçe tek ödeme, ad/etiket, lider izinleri, 50 üye sınırı; susturma/sona erme/restart kayıtları, reklam/küfür ve yerel mesaj GUI'si dahil farklı mesaj kanalları.
- **Banka:** yerli sağ tıkla altın alma, gerçek oyuncu saldırısıyla yakalama, hücreden çıkış, puanlama, iki turda takım değişimi, sonuç/envanter dönüşü ve üç eşzamanlı dünya.
- **HUD:** kişisel profil ile X Arena ve Şans Yolu'nun doğal skor tabloları ayrı; renkler ve kompakt sekiz satır korunur; tekrar giriş/çıkışta envanter kalır.
- **Eşya görünümü:** gerçek BlockDisplay varlıklarında saklanan ve sabit nesnenin malzeme/ışık/gölge/dönüş ayarları eşit; sabit nesneye yerli sağ tık yanlış tahmin yavaşlatması verir; geçici varlık/dünya temizliği ve envanter dönüşü.
- **İsteğe bağlı pet köprüsü:** gerçek Bukkit kurdu ve R5 açık API sözleşmesini taklit eden ayrı test eklentisiyle lobide izin, maçta kaldırma/üretmeme, binme engeli ve varsayılan rol izinleri. Bu test gerçek SimplePets NMS sürümünün tamamını doğrulamaz.
- **İki ayrı yeni deneme:** onaysız başlangıçta menü/dünya açmama, OP ile iki kişilik test, davetsiz giriş engeli; kargo yakınlık/kapasite/atomik aktarım/altı sipariş/sonuç/temizlik; mimar model gizleme/yerli blok koyma/alan sınırı/uçuş engeli/üç tur/puan/envanter ve mod dönüşü. Deneme ZIP'inde ayrı kayıt ve kaynakları bulunur.

## Bulunup giderilen hatalar

İç içe Paper komutlarının ertelenmesi nedeniyle ilk Oyna'nın yalnız lobiye girmesi; hızlı `/lobi` ardından yeni oyun seçiminde eski geçici dünya konumunun yedeklenmesi; OP düzenlemede Multiverse'in oyun modunu değiştirmesi ve OP kaldırıldığında Creative kalması; çok hızlı reddedilen hesap bağlantısında eski izin/Netty dinleyicilerinin kalması; yarış girişinde normal ayrılma cezası hatasının komut dışına taşması; eşya kılıklarının farklı ışık/gölge ayarı. Yeni Ayna Mimar'da yerleştirme etkileşiminin yanlışlıkla engellenmesi de teslimden önce giderildi.

## Testin sınırları

Bu, bütün olası hataların yok olduğu iddiası değildir. İstemciler gerçek Minecraft ağ protokolünü kullanır; ses için resmî API sözleşmesi üzerinden ayrı test düzeneği vardır, **gerçek mikrofon, UDP 24454, gerçek Simple Voice Chat/SimplePets/GrimAC/DriveBackup/MiniMOTD JAR'ları ve Windows indirme betikleri bu ortamda çalıştırılamadı**. Resmî sürüm uçları 403 verdiğinden üçüncü taraf dosya uydurulmadı veya ZIP'e konmadı. Kullanıcının canlı sunucusuna bağlantı/yükleme yapılmadı. Gölgelendirici/kaynak paketi ve farklı ekran ölçeklerinde gerçek istemci görüntüsü ayrıca kontrol edilmeli. Ölçek ve uzun süreli yük testi yapılmadı.

İlk canlı kontrolde iki normal istemciyle `/ses`, VIP/non-VIP maç çıkışı, yaratıcı adaya giriş, at/tekne bitişi ve eklentileri eklediğinde ses/pet/hareket uyumluluğunu dene. Dünya/config/hesap klasörlerini silme.
