# KasabaTR Sunucu Güncellemesi 1.7.1

Paper **1.21.10**, Java **21**. Paket 22 Kasaba üretim eklentisi içerir. Sunucuya yüklemeyi sen yapacaksın.

## Kurulum

1. Sunucuyu **tamamen durdur**. `plugins` ve dünya klasörlerinin yedeğini al.
2. ZIP içindeki `plugins/*.jar` dosyalarını sunucunun `plugins` klasörüne koy. **Yalnız aynı isimli eklentilerin eski JAR sürümlerini kaldır**; örneğin eski `KasabaHub-...jar` yerine yenisi kalsın. Aynı eklentinin iki sürümünü birlikte tutma.
3. **Config, veri, dünya klasörleri ve kayıtlı arena doğmalarını silme.** Paket bu dosyaların üzerine yazmaz. Multiverse ve diğer mevcut eklentilerin kalsın.
4. Sunucuyu yeniden başlat; `/reload` kullanma. Banka Baskını, Çöken Otel, Altın Tavuk ve Şüpheli Hat'ın haritaları ve ayrı lobileri JAR içinden eksiklerse otomatik kurulur. `/mv import` veya `/oyunlar ekle` gerekmez.
5. Oyunda `/oyunlar` aç. **15 oyun seçeneği** ilk sayfada görünür. İlk giriş oyun lobisine götürür; **Oyna** seçmeden maça alınmazsın. Pusula ve envanterden menü eşyasına tıklama çalışır.

Arena bakımda kalırsa önce konsoldaki KasabaArena hatasını ve kayıtlı dünyanın yüklü olduğunu kontrol et; doğmaları yeniden ayarlamadan önce mevcut `plugins/KasabaArena` kayıtlarını koru. Bu güncelleme arena ayarlarını sıfırlamaz.

## Ses kurulumu

Şüpheli Hat için sunucuda Simple Voice Chat, oyuncularda tek Simple Voice Chat modu gerekir. ZIP'i bilgisayarında açıp **SES-DOSYALARINI-INDIR.cmd** dosyasına çift tıkla; resmî ve aynı 2.6.x sürümdeki sunucu JAR'ını `plugins`, Fabric 1.21.10 istemci JAR'ını `oyuncu-modu` klasörüne indirir, SHA512 doğrular. Ardından plugins'i sunucuya yükle. Hosting panelinde **UDP 24454** açılmalı. Ayrıntı: [Ses kurulumu](ses/SES-KURULUMU.md). Resmî indirme alanları bu ortamda 403 verdiği için bu üçüncü taraf iki dosya ZIP'te hazır gelmez; indirme aracı kullanıcı bilgisayarında çalışır. Ses eklentisi kurulana kadar yalnız Şüpheli Hat bakımda görünür. Diğer oyunlar modsuz çalışır.

## Bütün odalı oyunların yeni düzeni

Normal oyuncu **Oyna** seçer; sistem boş ortak odayı doldurur veya kendisi açar. Minimum oyuncu sayısı sağlanınca **60 saniye** geri sayar. Oyun adı ve doluluk duyurusu spawn ve bütün oyun lobilerine gider; kalan süre odadakilerin üstünde görünür. Minimumun altına düşülürse sayım iptal olur. Odanın dolması bu 60 saniyeyi kısaltmaz. Sistem oda sayısı sınırına ulaştığında yeni maç boş yer bekler.

**Yalnız VIP özel oda kurabilir.** VIP sahibi geçerli minimum oyuncu sayısıyla istediği zaman `/oda başlat` kullanır. `/oda çıkar Oyuncu` ile çıkardığı kişi aynı oda bitene kadar geri gelemez; zorunlu çıkarılan kişiye terk cezası verilmez. `/oda` yönetim sayfasıdır. `/vip` yeni ayrıcalıkları açıklar. VIP olmak normal odalarda 60 saniyeyi atlama yetkisi vermez.

Bu düzen Arena 1v1/2v2, At/Tekne Yarışı, Şans Yolu, Renk Kaçışı, Eşya Saklambacı, Boya Savaşı, Lanetli Taç, Banka Baskını, Vampir Köylü, Battle Royale, Çöken Otel, Altın Tavuk ve Şüpheli Hat'ta uygulanır. Sürekli X Arena ve yaratıcı Adanı Yap oda sistemi kullanmaz. Yönetici denemeleri ve doğrudan kabul edilen `/vs` teklifleri ortak sıra sayımından ayrıdır.

| Oyun | Oyna | VIP özel oda | Lobi |
|---|---|---|---|
| Arena | `/arena 1v1`, `/arena 2v2` | `/arena oda oluştur [1v1/2v2]` | `/arena lobi` |
| At Yarışı | `/yaris oyna at` | `/yaris oluştur at` | `/yaris ayrıl` |
| Tekne Yarışı | `/yaris oyna tekne` | `/yaris oluştur tekne` | `/yaris ayrıl` |
| Şans Yolu | `/sansyolu oyna` | `/sansyolu oluştur` | `/sansyolu lobi` |
| Renk Kaçışı | `/renk oyna` | `/renk kur` | `/renk lobi` |
| Eşya Saklambacı | `/esya oyna` | `/esya oda kur` | `/esya lobi` |
| Boya Savaşı | `/boya oyna` | `/boya oda kur` | `/boya lobi` |
| Lanetli Taç | `/tac oyna` | `/tac oda kur` | `/tac lobi` |
| Banka Baskını | `/banka oyna` | `/banka oda kur` | `/banka lobi` |
| Çöken Otel | `/otel oyna` | `/otel oda kur` | `/otel lobi` |
| Altın Tavuk | `/tavuk oyna` | `/tavuk oda kur` | `/tavuk lobi` |
| Şüpheli Hat | `/hat oyna` | `/hat oda kur` | `/hat lobi` |
| Vampir Köylü | `/vk oyna` | `/vk oda kur` | `/vk lobi` |
| Battle Royale | `/br solo`, `/br ikili`, `/br dörtlü` | `/br oda kur solo` (veya ikili/dörtlü) | `/br lobi` |

Genel `/lobi` ana spawna götürür. Lobideyken pusula → **Oyun lobileri** ile diğer oyunlara doğrudan geçilir. Aktif normal maçı terk etmek o oyuna 15 dakika giriş cezası verir; bekleme, normal bitiş, elenme, zorunlu VIP çıkarılması ve yönetici denemesi cezasızdır.

## Yeni oyunlar

**Çöken Otel:** Normal 4–12 kişi, üç eşzamanlı maç. Her oyuncu 1., 2. ve 3. kattaki yeşil bloklardan kendi anahtarlarını alır. Ortadaki asansör taşlarına sağ tıklayarak kat değiştirir. Üç anahtarla çatı helipedine çıkan kurtulur. 25 saniyede bir oda çöker; 7 saniye önce uyarır. O katın son sağlam odası çökmez; anahtar çöken odadaysa sağlam odaya taşınır. Süre 210 saniye, sonuçtan 5 saniye sonra Otel lobisine dönüş. İki kişi test: ikiniz `/otel oyna`, OP oyuncu `/otel deneme`. Denemede galibiyet yazılmaz. `/otel testharita` güvenli doğmaları ve anahtar işaretlerini kontrol eder.

**Banka Baskını:** Normal 4–12 kişi, iki eşit takım, üç ayrı maç. Soyguncu kasaya sağ tıklayıp altını etkin kaçış noktasına taşır. Polis copla vurarak yakalar; altın geri alınır ve soyguncu 6 saniye hücrede kalır. 120 saniyelik iki tur arasında 8 saniye geçiş vardır; roller ve kaçış noktası değişir. Çok altın kazanır; eşitlikte yakalama sayısı belirler. Sonuçtan 5 saniye sonra Banka lobisine dönüş. İki kişi test: ikiniz `/banka oyna`, OP oyuncu `/banka deneme`.

**Altın Tavuk:** 2–8 kişi, 180 saniye, üç ayrı maç. Tavuğu taşıyan saniyede 1 puan toplar, parlar ve yavaşlar. Yakından görüş hattıyla vurarak çalınır; çalma aralığı 3 sn. En yüksek puan, beraberlikte eşit liderler kazanır. İki kişi yönetici testi: ikiniz `/tavuk oyna`, OP `/tavuk deneme`.

**Şüpheli Hat:** 4–8 kişi, 55 sn süren dört tur; komşu odadaki kişi, farklı dosya sahibi, işbirliği/ihanet ve dört rakamlı şifre. Herkes kendi kapalı odasında. `/hat telefon` veya `/hat ara Ali`, karşı taraf `/hat kabul` / `/hat reddet`; görüşme 30 sn, `/hat kapat`. `/hat cevap` sayfası, son tur `/hat şifre 1234`. İlk doğru şifre 5, sonraki doğru 2 puan; üç yanlış hak, yanlışlar arası 5 sn. Her maçın hattı ayrı, üç maç aynı anda. VIP özel oda minimum 4; OP iki kişilik denemede şifre parçaları iki oyuncuya da dağıtılır. Ses koparsa 5 sn sonra cezasız lobiye dönüş.

## Arena teklifi ve hayalet izleme

- İkiniz de Arena'nın güvenli lobisinde: `/vs Ali`. Ali: `/vs kabul Redkit` veya `/vs reddet Redkit`. Teklif 30 saniye geçerli; kabulde uygun boş 1v1 alanına doğrudan geçilir. Normal en fazla üç raunt kuralı korunur.
- `/izle` → maç listesi; `/izle Ali` → hayalet olarak izle; `/izle çık` → ayrıl. Arena **1v1/2v2**, At/Tekne Yarışı, Şans Yolu ve Renk Kaçışı açıktır. X Arena ve gizli bilgi içeren diğer oyunlar izlenemez.
- İzleyici görünmez, etkileşemez, dışarı ışınlanamaz, farklı maçtaki oyuncuya kamera bağlayamaz, mesaj/fısıltı/grup bilgisi gönderemez. Aktiflik Akçesi kazanmaz. Envanteri ve durumu çıkışta veya yeniden bağlanınca korunarak geri yüklenir. Oyuncuların oyun dışı sesli iletişimi eklentiyle engellenemez.

## Lonca ve sohbet

- `/lonca kur Kasaba KSB` → **50 Akçe**, ad 3–24 karakter, kısaltma tam üç harf; benzersiz ad/etiket, oyuncu başına bir lonca, lider dahil **50 kişi**.
- Lider: `/lonca davet Ali`; Ali: `/lonca katıl KSB`. Yalnız lider üye alır/çıkarır: `/lonca çıkar Ali`. `/lonca devret Ali`, `/lonca çık`, `/lonca dağıt onayla` (ücret iade edilmez).
- `/lonca`, `/lonca üyeler`, `/lonca sohbet mesaj`, `/lonca takvim`. Lonca sohbeti spawn/lobilerde. Normal `[Oyuncu]` yerine `[KSB]`; VIP/yetkililerde rütbe + lonca görünür. TAB, sohbet, kafa üstü ve mevcut bilgi tablosu birlikte güncellenir.
- İlk savaş takvimi **10 Ocak 2027**, sonra her ayın 10'u, Türkiye tarihi. **Bu sürüm lonca ve takvimi kurar; savaş kuralları/saati henüz belirlenmediğinden savaş otomatik başlamaz.**
- Yetkili/OP: `/sustur Ali 15 [sebep]`, `/sustur kaldır Ali`. Yetki düğümü: `kasaba.sohbet.sustur`. Süre çevrimdışı da geçer, yeniden başlatmada korunur. VIP cezanın dışına çıkamaz.
- Reklam, küfür, hızlı/tekrarlı mesaj engeli ana sohbet, özel mesaj/fısıltı, arkadaş sayfası, grup ve lonca sohbetine uygulanır. Ayarlar `plugins/KasabaTopluluk/config.yml`; dış bağlantı filtresi sunucunun kendi adreslerine izin verir. Yanlış algılama olursa kelime listesi ayarlanabilir.

## Görünüm düzeltmesi (KasabaBilgi 1.0.2)

X Arena öldürme listesi ile oyuncu profili birleştirilmez. X Arena ve kendi sağ tablosu olan diğer oyunlar yalnız kendi skorlarını gösterir; oyun tablosu kalkınca kişisel profil geri gelir. Kendi skor tablosu olmayan oyunlarda kişisel panel sekiz satırda kalır.

Oyuncu mavi, rütbe mor, Akçe altın, klan yeşil, süre turkuaz tonundadır. Rütbe değeri kendi rengini korur (Kurucu kırmızı). Oyun sırasında tüm satırlar gri olmaz. Genişlik büyümez; kısa süre biçimi ve en fazla 104 piksel metin genişliği korunur. Gerçek yazı ölçeği ve arka plan saydamlığı Minecraft ayarıdır. Yalnız bu görünüm düzeltmesini kuracaksan eski KasabaBilgi JAR'ını kaldırıp `KasabaBilgi-1.0.2.jar` koyman yeterlidir.

Eşya Saklambacı'nda saklananlar yavaş uçabilir; uygun yan blokta kısa süre durunca otomatik blok hizasına oturur. Önceki VIP fiyatları, ekonomi, arsa ve oyun verileri korunur.

ZIP yalnız üretim JAR'ları ve kurulum/doğrulama belgelerini içerir; Paper, Multiverse, test eklentisi veya oyuncu verisi içermez.
