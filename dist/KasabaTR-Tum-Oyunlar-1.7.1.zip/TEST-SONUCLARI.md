# 1.7.1: kişisel bilgi ve oyun tablosunun ayrılması

KasabaBilgi **1.0.2**. Önceki birleşik görünüm kaldırıldı. Bir oyunun Bukkit SIDEBAR'ı varsa yalnız o oyun tablosu gösterilir; kişisel tablo geri çekilir. Native tablo kalkınca kişisel bilgi otomatik döner. Oyun tablosu olmayan oyunlarda kişisel bilgiler sekiz satırda, ayrı renkler ve gerçek rütbe rengiyle görünür. En fazla 104 piksel metin genişliği / kısa süre gösterimi korunur. Yeni dev panel veya ikinci görsel katman eklenmedi.

Dört geçen birim testi `unit-bilgi-results.json`: zaman/ondalık para, istenen alanlar, dar genişlik, oyun sırasında farklı renkler ve gerçek rütbe rengi. Native iki oyunculu protokol testi `hud-results.json`: lobi renkleri/gerçek Kurucu kırmızısı, test native objective'ine devir/toggle/geri dönüş, X Arena'da yalnız orijinal öldürme tablosu, kendi tablosu olmayan Eşya maçında sekiz renkli satır, Şans Yolu'nda ortak native tablonun birleştirilmeden korunması ve envanter iadesi. Gerçek grafik istemcisiyle yeni ekran görüntüsü alınmadı.

Yalnız KasabaBilgi JAR'ı değişir. Diğer 21 üretim JAR'ının önceki temiz yeniden başlatmada test edilen SHA256'larıyla eşitliği paketlemede zorunludur. Önceki 1.7.0'ın 64 akış kontrolü ve ses eklentisi olmadan 2 kontrolü `../1.7.0/` altında korunur. Yeni dosyalar eski yayımları değiştirmez.

Simple Voice Chat sunucu/istemci JAR'ları resmî indirme alanlarının bu ortama 403 vermesi nedeniyle ZIP'te hazır gelmez. Paket içindeki Windows indirme aracı bunları resmî Modrinth API'sinden SHA512 ile doğrulayarak indirir. Önceki ses testleri yalnız resmî API arabirimleriyle bağlantı/grup/paket kurallarıdır; gerçek UDP/mikrofon sesi doğrulanmadı. Kurulum ve bu sınır yeni pakette açıkça yazılıdır. Test eklentileri ve sahte ses sunucusu ZIP'e konmaz.
