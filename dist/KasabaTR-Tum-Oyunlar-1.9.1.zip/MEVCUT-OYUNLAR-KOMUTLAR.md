# 1.9.0 güncellemesi: ses, OP yönetimi, VIP çıkışları

- Vampir Köylü ve Şüpheli Hat: bağlı Simple Voice Chat zorunlu. Lobi ziyareti serbest; eksik mod/bağlantıda indirme ve kurulum sayfası. `/ses` tekrar açar. Kamuya açık/VIP odası, komut ve OP denemesinde yeniden kontrol edilir. Gerçek mikrofon/UDP testi bu ortamda yapılamadı; yayından önce iki bilgisayarla dene.
- `/yonet` (veya `/yönet`): yalnız OP yönetici paneli. VIP olman gerekmez.
- `/yonet haritalar`: yüklü kalıcı haritalar listesi; dünya adına basınca yaratıcı modda düzenleme açılır. `/yonet harita DunyaAdi` doğrudan gider. Maçtaysan önce `/lobi` kullan. Geçici maç kopyaları düzenlenmez.
- Bulunduğun yerde `/yonet düzenleme aç`: kırma, koyma, etkileşim. `/yonet düzenleme kapat`: korumayı ve önceki oyun modunu geri getirir. `/yonet çık`: kapatıp ana lobiye döner. OP kaldırılırsa düzenleme de biter. Değişiklikler haritaya kalıcı yazılır; harita düzenlerken yeni maç açma.
- İki kişilik test: ikiniz aynı oyuna girip **Oyna** seçin. OP oyuncu `/yonet deneme` yazsın. Yarışlar, Şans Yolu, Renk Kaçışı, Eşya Saklambacı, Boya Savaşı, Lanetli Taç, Banka Baskını, Şüpheli Hat ve Vampir Köylü desteklenir. Sesli iki oyunda iki oyuncunun sesi bağlı olmalı. Arena'da ikiniz **1v1** seçip aynı komutu kullanın; BR'de önce Solo seçin, mevcut yönetici `/br başlat <oda>` komutu da geçerlidir. Test, boş odaya sahte oyuncu eklemez; en az iki kişi gerekir.
- VIP: `/lobi`, oyunlar arası geçiş veya sunucudan çıkışta 15 dakikalık ayrılma cezası yok. Normal oyuncunun kuralı devam eder. Bu yalnız oyun terk cezasıdır; susturma ve diğer yönetim cezaları devam eder. `/vip` bilgi sayfası güncellendi.
- Önceki kompakt, renkli profil ve oyunların ayrı tabloları aynen korunur.

## Mevcut sunucuya yükleme

1. Sunucuyu tamamen durdur; `/reload` kullanma.
2. Güncelleme ZIP'inin `plugins` klasöründeki eklentilerin eski **JAR dosyalarını** sunucunun `plugins` içinden kaldır; yeni JAR dosyalarını yükle. Aynı eklentinin iki JAR sürümü birlikte kalmasın. Hub ile oyun güncellemelerini birlikte yükle.
3. Dünya klasörleri, `plugins/Kasaba...` veri klasörleri ve mevcut ayar dosyalarını silme. Konumlar, oyuncular, bakiyeler ve adalar korunur. Hazır güncelleme harita dünyalarını yeniden kurmaz.
4. Ses eklentisi yoksa resmî indirme aracını kendi bilgisayarında çalıştır, indirilen sunucu JAR'ını da yükle. Oyuncular istemci JAR'ını kendi bilgisayarlarına kurar.
5. Sunucuyu başlat. Konsoldan `op OyuncuAdin`, oyunda `/yonet` ve `/ses` ile kontrol et. Ekranda dünya görünmüyorsa `/yonet haritalar` listesini kullan; dünya adı uydurma.

Aşağıda önceki kurulum ve bütün komutlar yer alır.

# KasabaTR Sunucu Güncellemesi 1.9.0

Paper **1.21.10**, Java **21**. Yeni tam paket 24 Kasaba üretim eklentisi içerir. Sunucuya yüklemeyi sen yapacaksın.

## Kurulum

1. Sunucuyu **tamamen durdur**. `plugins` ve dünya klasörlerinin yedeğini al.
2. ZIP içindeki `plugins/*.jar` dosyalarını sunucunun `plugins` klasörüne koy. **Yalnız aynı isimli eklentilerin eski JAR sürümlerini kaldır**; örneğin eski `KasabaHub-...jar` yerine yenisi kalsın. Aynı eklentinin iki sürümünü birlikte tutma.
3. **Config, veri, dünya klasörleri ve kayıtlı arena doğmalarını silme.** Paket bu dosyaların üzerine yazmaz. Multiverse ve diğer mevcut eklentilerin kalsın.
4. Sunucuyu yeniden başlat; `/reload` kullanma. Banka Baskını ve Şüpheli Hat'ın haritaları ve ayrı lobileri JAR içinden eksiklerse otomatik kurulur. `/mv import` veya `/oyunlar ekle` gerekmez.
5. Oyunda `/oyunlar` aç. **13 oyun seçeneği** ilk sayfada görünür. İlk giriş oyun lobisine götürür; **Oyna** seçmeden maça alınmazsın. Pusula ve envanterden menü eşyasına tıklama çalışır.

Arena bakımda kalırsa önce konsoldaki KasabaArena hatasını ve kayıtlı dünyanın yüklü olduğunu kontrol et; doğmaları yeniden ayarlamadan önce mevcut `plugins/KasabaArena` kayıtlarını koru. Bu güncelleme arena ayarlarını sıfırlamaz.

## Ses kurulumu

Vampir Köylü **ve** Şüpheli Hat için sunucuda Simple Voice Chat, oyuncuda tek Simple Voice Chat modu gerekir. Sunucuda Paper 1.21.10 kalır. ZIP'i bilgisayarında açıp **SES-DOSYALARINI-INDIR.cmd** dosyasını çalıştır; resmî aynı 2.6.x sürümdeki sunucu JAR'ını `plugins`, Fabric 1.21.10 istemci JAR'ını `oyuncu-modu` içine indirir ve SHA512 doğrular. Sunucuda **UDP 26338** açık olmalı. Ayrıntı: [Ses kurulumu](ses/SES-KURULUMU.md). Bu iki üçüncü taraf dosya hazır ZIP'e gömülü değildir; diğer oyunlar modsuz çalışır. Ses hizmeti veya istemci eksikse iki oyunun lobileri ziyaret edilebilir, maça girilemez. İlk başarılı hesap girişinde kurulum düğmesi gösterilir (oyuncu başına bir kez); `/ses` ile yeniden açılır. Sunucu oyuncunun bilgisayarına mod kuramaz.

## Bütün odalı oyunların yeni düzeni

Normal oyuncu **Oyna** seçer; sistem boş ortak odayı doldurur veya kendisi açar. Minimum oyuncu sayısı sağlanınca **60 saniye** geri sayar. Oyun adı ve doluluk duyurusu spawn ve bütün oyun lobilerine gider; kalan süre odadakilerin üstünde görünür. Minimumun altına düşülürse sayım iptal olur. Odanın dolması bu 60 saniyeyi kısaltmaz. Sistem oda sayısı sınırına ulaştığında yeni maç boş yer bekler.

**Yalnız VIP özel oda kurabilir.** VIP sahibi geçerli minimum oyuncu sayısıyla istediği zaman `/oda başlat` kullanır. `/oda çıkar Oyuncu` ile çıkardığı kişi aynı oda bitene kadar geri gelemez; zorunlu çıkarılan kişiye terk cezası verilmez. `/oda` yönetim sayfasıdır. `/vip` yeni ayrıcalıkları açıklar. VIP olmak normal odalarda 60 saniyeyi atlama yetkisi vermez.

Bu düzen Arena 1v1/2v2, At/Tekne Yarışı, Şans Yolu, Renk Kaçışı, Eşya Saklambacı, Boya Savaşı, Lanetli Taç, Banka Baskını, Vampir Köylü, Battle Royale ve Şüpheli Hat'ta uygulanır. Sürekli X Arena ve yaratıcı Adanı Yap oda sistemi kullanmaz. Yönetici denemeleri ve doğrudan kabul edilen `/vs` teklifleri ortak sıra sayımından ayrıdır.

| Oyun | Oyna | VIP özel oda | Lobi |
|---|---|---|---|
| Arena | `/arena 1v1`, `/arena 2v2` | `/arena oda oluştur [1v1/2v2]` | `/arena lobi` |
| At Yarışı | `/yaris oyna at` | `/yaris oluştur at` | `/yaris ayrıl` |
| Tekne Yarışı | `/yaris oyna tekne` | `/yaris oluştur tekne` | `/yaris ayrıl` |
| Şans Yolu | `/sansyolu oyna` | `/sansyolu oluştur` | `/sansyolu lobi` |
| Renk Kaçışı | `/renk oyna` | `/renk kur` | `/renk lobi` |
| Eşya Saklambacı | `/esya oyna` | `/esya oda kur` | `/esya lobi` |
| Boya Savaşı | `/boya oyna` | `/boya oda kur` | `/boya lobi` |
| Lanetli Taç | `/tac oyna` | `/tac oda kur` | `/tac lobi` |
| Banka Baskını | `/banka oyna` | `/banka oda kur` | `/banka lobi` |
| Şüpheli Hat | `/hat oyna` | `/hat oda kur` | `/hat lobi` |
| Vampir Köylü | `/vk oyna` | `/vk oda kur` | `/vk lobi` |
| Battle Royale | `/br solo`, `/br ikili`, `/br dörtlü` | `/br oda kur solo` (veya ikili/dörtlü) | `/br lobi` |

Genel `/lobi` ana spawna götürür. Lobideyken pusula → **Oyun lobileri** ile diğer oyunlara doğrudan geçilir. VIP olmayan normal oyuncu aktif maçı terk ederse o oyuna 15 dakika giriş cezası alır; VIP ve OP yönetici ceza almaz, eski ayrılma cezaları giriş/kontrol sırasında temizlenir; bekleme, normal bitiş, elenme, zorunlu VIP çıkarılması ve yönetici denemesi cezasızdır.

## Oyun notları


**Banka Baskını:** Normal 4–12 kişi, iki eşit takım, üç ayrı maç. Soyguncu kasaya sağ tıklayıp altını etkin kaçış noktasına taşır. Polis copla vurarak yakalar; altın geri alınır ve soyguncu 6 saniye hücrede kalır. 120 saniyelik iki tur arasında 8 saniye geçiş vardır; roller ve kaçış noktası değişir. Çok altın kazanır; eşitlikte yakalama sayısı belirler. Sonuçtan 5 saniye sonra Banka lobisine dönüş. İki kişi test: ikiniz `/banka oyna`, OP oyuncu `/banka deneme`.


**Şüpheli Hat:** 4–8 kişi, 55 sn süren dört tur; komşu odadaki kişi, farklı dosya sahibi, işbirliği/ihanet ve dört rakamlı şifre. Herkes kendi kapalı odasında. `/hat telefon` veya `/hat ara Ali`, karşı taraf `/hat kabul` / `/hat reddet`; görüşme 30 sn, `/hat kapat`. `/hat cevap` sayfası, son tur `/hat şifre 1234`. İlk doğru şifre 5, sonraki doğru 2 puan; üç yanlış hak, yanlışlar arası 5 sn. Her maçın hattı ayrı, üç maç aynı anda. VIP özel oda minimum 4; OP iki kişilik denemede şifre parçaları iki oyuncuya da dağıtılır. Ses koparsa 5 sn sonra cezasız lobiye dönüş.

## Arena teklifi ve hayalet izleme

- İkiniz de Arena'nın güvenli lobisinde: `/vs Ali`. Ali: `/vs kabul Redkit` veya `/vs reddet Redkit`. Teklif 30 saniye geçerli; kabulde uygun boş 1v1 alanına doğrudan geçilir. Normal en fazla üç raunt kuralı korunur.
- `/izle` → maç listesi; `/izle Ali` → hayalet olarak izle; `/izle çık` → ayrıl. Arena **1v1/2v2**, At/Tekne Yarışı, Şans Yolu ve Renk Kaçışı açıktır. X Arena ve gizli bilgi içeren diğer oyunlar izlenemez.
- İzleyici görünmez, etkileşemez, dışarı ışınlanamaz, farklı maçtaki oyuncuya kamera bağlayamaz, mesaj/fısıltı/grup bilgisi gönderemez. Aktiflik Akçesi kazanmaz. Envanteri ve durumu çıkışta veya yeniden bağlanınca korunarak geri yüklenir. Oyuncuların oyun dışı sesli iletişimi eklentiyle engellenemez.

## Klan ve sohbet

- `/klan kur Kasaba KSB` → **50 Akçe**, ad 3–24 karakter, kısaltma tam üç harf; benzersiz ad/etiket, oyuncu başına bir klan, lider dahil **50 kişi**.
- Lider: `/klan davet Ali`; Ali: `/klan katıl KSB`. Yalnız lider üye alır/çıkarır: `/klan çıkar Ali`. `/klan devret Ali`, `/klan çık`, `/klan dağıt onayla` (ücret iade edilmez).
- `/klan`, `/klan üyeler`, `/klan sohbet mesaj`, `/klan takvim`. Klan sohbeti spawn/lobilerde. Normal `[Oyuncu]` yerine `[KSB]`; VIP/yetkililerde rütbe + klan görünür. TAB, sohbet, kafa üstü ve mevcut bilgi tablosu birlikte güncellenir.
- İlk savaş takvimi **10 Ocak 2027**, sonra her ayın 10'u, Türkiye tarihi. **Bu sürüm klan ve takvimi kurar; savaş kuralları/saati henüz belirlenmediğinden savaş otomatik başlamaz.**
- Yetkili/OP: `/sustur Ali 15 [sebep]`, `/sustur kaldır Ali`. Yetki düğümü: `kasaba.sohbet.sustur`. Süre çevrimdışı da geçer, yeniden başlatmada korunur. VIP cezanın dışına çıkamaz.
- Reklam, küfür, hızlı/tekrarlı mesaj engeli ana sohbet, özel mesaj/fısıltı, arkadaş sayfası, grup ve klan sohbetine uygulanır. Ayarlar `plugins/KasabaTopluluk/config.yml`; dış bağlantı filtresi sunucunun kendi adreslerine izin verir. Yanlış algılama olursa kelime listesi ayarlanabilir.

## Kompakt bilgi tablosu (KasabaBilgi 1.0.3)

X Arena öldürme listesi ile oyuncu profili birleştirilmez. X Arena ve kendi sağ tablosu olan diğer oyunlar yalnız kendi skorlarını gösterir; oyun tablosu kalkınca kişisel profil geri gelir. Kendi skor tablosu olmayan oyunlarda kişisel panel sekiz satırda kalır.

Oyuncu mavi, rütbe mor, Akçe altın, klan yeşil, süre turkuaz tonundadır. Rütbe değeri kendi rengini korur (Kurucu kırmızı). Oyun sırasında tüm satırlar gri olmaz. Genişlik büyümez; kısa süre biçimi ve en fazla 104 piksel metin genişliği korunur. Gerçek yazı ölçeği ve arka plan saydamlığı Minecraft ayarıdır. Bu paketteki KasabaBilgi 1.0.3 bu görünümü korur; bağlantı kesilirken paket dinleyicisinin güvenli kapanmasını da düzeltir.

Eşya Saklambacı'nda saklananlar yavaş uçabilir; uygun yan blokta kısa süre durunca otomatik blok hizasına oturur. Önceki VIP fiyatları, ekonomi, arsa ve oyun verileri korunur.

ZIP yalnız üretim JAR'ları ve kurulum/doğrulama belgelerini içerir; Paper, Multiverse, test eklentisi veya oyuncu verisi içermez.

