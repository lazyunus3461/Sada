package tr.kasabatr.mimar;
public final class KasabaMimarPlugin extends DemoGame {
 boolean architect(){return true;}String rootCommand(){return "mimar";}String id(){return "aynamimar";}String title(){return "Ayna Mimar";}
}
