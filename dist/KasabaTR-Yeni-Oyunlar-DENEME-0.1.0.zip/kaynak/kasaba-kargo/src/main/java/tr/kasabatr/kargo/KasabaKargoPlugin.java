package tr.kasabatr.kargo;
public final class KasabaKargoPlugin extends DemoGame {
 boolean architect(){return false;}String rootCommand(){return "kargo";}String id(){return "kargoustasi";}String title(){return "Kargo Ustası";}
}
