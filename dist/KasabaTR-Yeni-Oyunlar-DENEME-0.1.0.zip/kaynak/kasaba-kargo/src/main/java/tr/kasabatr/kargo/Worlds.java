package tr.kasabatr.kargo;
import java.io.*;import java.nio.file.*;import java.util.*;import org.bukkit.*;import org.bukkit.generator.ChunkGenerator;
final class Worlds {
 final DemoGame plugin;final Path root;final String prefix,marker;World lobby;final Set<UUID> owned=new HashSet<>();
 Worlds(DemoGame p){plugin=p;root=Bukkit.getWorldContainer().toPath().toAbsolutePath().normalize();prefix="demo_"+p.rootCommand()+"_";marker=".kasaba-"+p.rootCommand()+"-generated";}
 World openLobby()throws IOException{String name=prefix+"lobi";boolean fresh=!Files.exists(root.resolve(name));lobby=open(name);if(fresh){floor(lobby,-10,10,-10,10);lobby.setSpawnLocation(new Location(lobby,.5,81,.5));}return lobby;}
 World room()throws IOException{World w=open(prefix+"room_"+UUID.randomUUID().toString().replace("-","").substring(0,12));floor(w,-34,34,-18,18);w.setSpawnLocation(new Location(w,.5,81,.5));return w;}
 private World open(String name)throws IOException{Path dir=root.resolve(name);if(!dir.getParent().equals(root)||Files.isSymbolicLink(dir))throw new IOException("Guvenli olmayan dunya yolu");if(Files.exists(dir)&&(!Files.isRegularFile(dir.resolve(marker))||!Files.readString(dir.resolve(marker)).equals(plugin.getName())))throw new IOException("Var olan isaretsiz dunyaya dokunulmadi: "+name);if(!Files.exists(dir)){Files.createDirectory(dir);Files.writeString(dir.resolve(marker),plugin.getName());}World w=Bukkit.getWorld(name);if(w==null)w=Bukkit.createWorld(new WorldCreator(name).generator(new VoidGenerator()).generateStructures(false));if(w==null)throw new IOException("Dunya acilamadi");w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE,false);w.setGameRule(GameRule.DO_WEATHER_CYCLE,false);w.setGameRule(GameRule.DO_MOB_SPAWNING,false);w.setGameRule(GameRule.KEEP_INVENTORY,true);w.setGameRule(GameRule.LOCATOR_BAR,false);w.setGameRule(GameRule.RANDOM_TICK_SPEED,0);w.setTime(1000);w.setStorm(false);owned.add(w.getUID());return w;}
 static void floor(World w,int minX,int maxX,int minZ,int maxZ){for(int x=minX;x<=maxX;x++)for(int z=minZ;z<=maxZ;z++){w.getBlockAt(x,79,z).setType(Material.STONE,false);w.getBlockAt(x,80,z).setType((x+z)%2==0?Material.SMOOTH_STONE:Material.STONE_BRICKS,false);if(x==minX||x==maxX||z==minZ||z==maxZ){w.getBlockAt(x,81,z).setType(Material.GLASS,false);w.getBlockAt(x,82,z).setType(Material.GLASS,false);}}}
 boolean managed(World w){return w!=null&&owned.contains(w.getUID());}
 void close(World w){close(w,0);}
 private void close(World w,int attempt){if(w==null||w==lobby)return;if(!w.getPlayers().isEmpty()){if(plugin.isEnabled()&&!plugin.stopping&&attempt<20)Bukkit.getScheduler().runTaskLater(plugin,()->close(w,attempt+1),10);return;}Path dir=w.getWorldFolder().toPath().toAbsolutePath().normalize();if(!dir.getParent().equals(root)||!w.getName().startsWith(prefix+"room_"))return;try{if(!Files.readString(dir.resolve(marker)).equals(plugin.getName()))return;if(!Bukkit.unloadWorld(w,false))return;owned.remove(w.getUID());try(var walk=Files.walk(dir)){var paths=walk.sorted(Comparator.reverseOrder()).toList();if(paths.stream().anyMatch(Files::isSymbolicLink))throw new IOException("Baglanti bulunan gecici klasor korundu");for(Path p:paths)Files.delete(p);}}catch(IOException e){plugin.getLogger().warning("Gecici dunya korunuyor: "+e.getMessage());}}
 static final class VoidGenerator extends ChunkGenerator{
 @Override public Location getFixedSpawnLocation(World w,Random r){return new Location(w,.5,81,.5);}
 @Override public boolean shouldGenerateNoise(){return false;}
 @Override public boolean shouldGenerateSurface(){return false;}
 @Override public boolean shouldGenerateBedrock(){return false;}
 @Override public boolean shouldGenerateCaves(){return false;}
 @Override public boolean shouldGenerateDecorations(){return false;}
 @Override public boolean shouldGenerateMobs(){return false;}
 @Override public boolean shouldGenerateStructures(){return false;}
 }
}
