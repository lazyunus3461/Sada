# İki ayrı deneme oyunu

**Kargo Ustası** ile **Ayna Mimar**, beğenmen için ayrı hazırlandı. Ana 20 eklentilik sunucu paketinde yoklar. Haritaları basit test alanlarıdır; son görünüm ve denge için oyun içinde senin değerlendirmen gerekir.

## Kurulum

1. Önce KasabaTR 1.8.0 ana paketini kur. Paper 1.21.10, Java 21 gerekir.
2. Sunucu kapalıyken bu ZIP'in `plugins` içindeki iki JAR'ı sunucunun `plugins` klasörüne ekle. Tekini denemek istersen yalnız onu koy.
3. Başlat. Varsayılan `approved: false`: normal oyunculara otomatik açılmaz, `/oyunlar` listene eklenmez ve harita kurulmaz.
4. Bir arkadaşınla giriş yap. İkiniz de ana lobideyken OP hesabından `/kargo deneme ArkadasAdi` veya `/mimar deneme ArkadasAdi` yaz. Yalnız bu iki hesap denemeye alınır. Mod gerekmez.
5. Çıkış: `/lobi`. Deneme maçı galibiyet tablosuna puan ve ayrılma cezası yazmaz. Önceki envanter/durum yedeklenip geri yüklenir.

Beğenirsen OP hesabından `/kargo onayla` veya `/mimar onayla`: o oyun kalıcı olarak `/oyunlar` sistemine açılır. Onay sonrası ortak oda minimum iki kişide 60 saniye sayar; özel oda kurmak VIP'e aittir. Harita başına değil, toplam üç ayrı maç aynı anda açılabilir. Ana sunucuya yüklemeye sen karar vereceksin.

## Kargo Ustası

**2–6 kişi**, işbirliği, **180 saniye**. Her oyuncunun siparişi farklıdır. Köşelerdeki Elma, Kağıt, Demir ve Odun depolarından kaynak alıp merkezdeki masada teslim edin. Çanta dört parça alır. Takımın hedefi kişi başına üç teslimattır; tüm ekip birlikte kazanır.

- Depoya yakınken varile sağ tık veya `/kargo al elma` (`kağıt`, `demir`, `odun`).
- Merkezde masaya sağ tık, pusuladaki **Siparişi teslim et** veya `/kargo teslim`.
- Yakındaki arkadaşına bütün çantanı ver: `/kargo ver Oyuncu`. Arkadaşında yeterli yer yoksa hiçbir şey aktarılmaz.
- Yanlış kaynak topladıysan merkez masasında `/kargo boşalt`; siparişin korunur.
- `/kargo` pusula menüsü, `/kargo lobi` oyunun lobisi, `/lobi` ana lobi.

## Ayna Mimar

**2–8 kişi**, üç tur hafıza ve inşa. Kendi bölümündeki renkli **3×3 modeli 8 saniye** incele. Model kaybolunca **45 saniyede** önündeki dokuz zemin kutusuna kopyala. Modelin üst sırası zemindeki uzak sıraya karşılık gelir.

Altı yün rengi eline verilir. Kendi dokuz kutuna blok koyup kırabilirsin. Diğer bölümler, uçuş ve yaratıcı envanterden eşya alma kapalıdır. Her doğru kutu **10 puan**; tam doğru ve erken bitirene ek puan. Üç tur sonunda toplamı yüksek olan kazanır; beraberlik mümkündür.

`/mimar` menü, `/mimar lobi` oyun lobisi, `/lobi` ana lobi.

## Harita ve kaldırma

Dünyalar `demo_kargo_lobi`, `demo_mimar_lobi` ve o maç için üretilen geçici kopyalardır. Mevcut oyun dünyalarına dokunulmaz. Maç bitince oyuncular beş saniye sonra kendi oyun lobisine döner, geçici kopya temizlenir. Oyunu istemezsen sunucu kapalıyken yalnız ilgili deneme JAR'ını kaldır. Veri/dünya klasörlerini silmen gerekmez.
