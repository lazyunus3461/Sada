# KasabaTR 1.9.0 — kendi eklentilerimiz ve dikey Ayna Mimar

Paper **1.21.10**, Java **21**. Tam paket **24 JAR** içerir: 23 ortak/oyun eklentisi ve isteğe bağlı Ayna Mimar 0.1.1. Güncelleme paketi **7 JAR** içerir: KasabaEvcil, KasabaYedek, KasabaVitrin, KasabaHub 1.9.0, KasabaRoles 1.4.2, KasabaArena 1.4.2 ve Ayna Mimar 0.1.1.

## Kurulum

1. Sunucuyu durdur ve mevcut `plugins` ile dünyalarını yedekle.
2. Eski **KasabaHub**, **KasabaRoles**, **KasabaArena** ve **KasabaMimar** JAR sürümlerini kaldır. Aynı eklentinin iki sürümü kalmasın. Diğer oyunların konum/config/veri klasörlerini silme.
3. Bu ZIP'in `plugins` içindeki JAR'larını sunucunun `plugins` klasörüne koy. Tam paketi kullanıyorsan diğer Kasaba eklentilerinin eski JAR'larını da yenileriyle değiştir.
4. **GrimAC/Grim, KasabaKoruma, DriveBackupV2, MiniMOTD ve SimplePets JAR'ları kuruluysa kaldır.** Bunların indiricisi/ayarları bu pakette yok. Eski dört ayar klasörü kendi Kasaba eklentilerimiz tarafından kullanılmaz; istersen sunucu kapalıyken başka yere taşıyabilirsin. Mevcut Multiverse ve tek ses modu için Simple Voice Chat ayrı görevlerine devam eder.
5. Başlat. OP hesabında `/yedek durum`, `/vitrin önizle`, `/evcil` ile kontrol et. `/reload` kullanma.

## KasabaEvcil

Tamamen Kasaba kodu; ek istemci modu gerekmez. `/evcil` renkli seçim sayfasını açar. `/dost kedi`, `/dost kurt`, `/dost kapat` da kullanılabilir. Aynı anda bir hayvan olur. Seçimin yeniden girişte ve sunucu yeniden başlatıldığında korunur.

Hayvan yalnız hesabına giriş yaptıktan sonra ana spawn veya güvenli oyun lobisinde görünür. Maça, adaya veya hayalet izlemeye geçince kaldırılır; uygun lobiye dönünce seçiminle geri gelir. Oyuncu gizleme, evcilini de gizler. Hayvana vurma, besleme/etkileşim, binme, saldırma, üreme, eşya düşürme ve eşya toplama kapalıdır. Gerçek kedi/kurt varlığı kullanır; kaynak paketi ve SimplePets gerekmez.

## KasabaYedek

- `/yedek al`: anlık dünya ve eklenti yedeği başlatır. Aynı anda iki yedek başlatılmaz.
- `/yedek durum`: devam eden iş, son durum, süre ve hedef.
- `/yedek liste`: son tamamlanmış ZIP'ler.
- `/yedek yenile`: yedek çalışmıyorken config'i yeniden okur.

Varsayılan **60 dakikada bir**, oyuncu olmasa da yerel yedek; **son 24 kendi arşivi** saklanır. Sunucu ana dizininde **KasabaYedekler** klasörüne yazar. Çevrimiçi dünyaları kaydeder; ZIP hazırlanırken otomatik dünya kayıtlarını durdurur, tamamlanınca/hatada/kapanışta önceki ayarlarını geri getirir. ZIP sıkıştırma ve SHA256 doğrulama arka planda yapılır. Canlı sunucuda sonradan oluşan değişiklikler sonraki yedeğe kalabilir.

Dünyalar, eklenti JAR ve verileri, kayıt/hesaplar ve gizli IP anahtarı dahil temel sunucu ayarları kapsanır. Geçici `*_room_*` maç dünyaları, önbellekler, kilit/yarım dosyalar ve yedeklerin kendisi alınmaz. Sembolik bağlantılar takip edilmez. Başarısız dosya `.part` olarak tamamlanmış sayılmaz; doğrulanan ZIP atomik olarak yayımlanır. Saklama temizliği başka normal ZIP dosyalarına dokunmaz.

Bu **yerel yedektir**. Google Drive/başka uzak hesaba gönderme eklenmedi. Panelden düzenli olarak bir ZIP'i bilgisayarına da indir. Arşiv hesap verisi içerdiğinden herkese açık indirme bağlantısında paylaşma. Geri yükleme: sunucu tamamen kapalıyken ZIP'i ayrı klasöre aç, gereken dünya/verileri yedekleyip geri koy; eklenti çalışırken otomatik geri yükleme komutu yoktur.

## KasabaVitrin

Sunucu listesindeki renkli iki satırı kendi kodumuz yazar; gerçek çevrimiçi sayı ve kapasite korunur. Örnek oyuncu isimleri listede gizlidir.

- `/vitrin önizle`: mevcut metin.
- `/vitrin yenile`: `plugins/KasabaVitrin/config.yml` içindeki iki satırı yenile.
- `/vitrin bakım aç` / `/vitrin bakım kapat`: yalnız listedeki bakım yazısını değiştirir. Oyuncu girişini kapatmaz.

Renkler `&6`, `&b`, `&d`, kalın yazı `&l`; `{cevrimici}` ve `{kapasite}` kullanılabilir. Ayar iki satır olmalıdır.

## Hile koruması kaldırıldı

Bu pakette KasabaKoruma veya GrimAC yoktur. Kaldırmak için sunucuyu durdur, `plugins` içindeki ilgili **.jar dosyasını** kaldır, yeniden başlat. Yalnız config klasörünü silmek eklentiyi kapatmaz. Atılma mesajı özellikle “uçmak bu sunucuda etkin değil” ise `server.properties` içindeki `allow-flight=true` ayarı ayrıca kontrol edilmelidir; bu Minecraft'ın kendi kontrolüdür.

## Ayna Mimar 0.1.1 — dikey ve özel odalar

Örnek 8 saniye dikey 3×3 duvarda görünür. Kaybolunca **aynı dikey duvarı** 45 saniyede yeniden yaparsın. Eski yatay zemin alanı düzenlenmez. Üç turun puanlaması korunur.

Herkesin tavanlı, aydınlık, yan/ön/arka duvarları kapalı kendi bölümü vardır. Rakibin bölümüne yürümek veya ışınlanmak engellenir. Maçtaki oyuncular birbirinden ve dışarıdan izleyenlerden gizlenir; lobiye dönünce görünürlük geri gelir. Uçuş ve yaratıcı envanterden dışarı eşya alma kapalıdır.

Güncellemede eski `KasabaMimar-0.1.0.jar` yerine `KasabaMimar-0.1.1.jar` koy, veri/config klasörünü koru. Yeni kurulumda henüz herkese açılmaz: iki kişi ana lobideyken OP `/mimar deneme ArkadasAdi`. Beğenirsen `/mimar onayla`. Kargo Ustası bu pakete eklenmedi; önceki ayrı deneme JAR'ı kalabilir.

## Ses portun: 26338 / UDP

Minecraft'ın mevcut oyun portu **28757**. Ses için ayırdığın alt port **26338**. Simple Voice Chat kurulu sunucuda `plugins/voicechat/voicechat-server.properties` içinde şu değerleri kullan:

```properties
port=26338
bind_address=0.0.0.0
voice_host=185.255.92.108:26338
force_voice_chat=false
```

Hazır yeni kurulum örneği `ses/voicechat-server.properties` içindedir. Mevcut ses dosyanın tamamının üzerine yazma; bu dört değeri güncelle. Sunucuyu yeniden başlat. Hosting panelindeki tahsisin **UDP** trafiğini de açtığını kontrol et. Buradan gerçek UDP erişimi veya mikrofon bağlantısı doğrulanmadı. Diğer oyunlar için ses modu zorunlu değildir; Vampir Köylü ve Şüpheli Hat maçında gereklidir. Oyuncu kurulumu `/ses` ile açılır.

## Diğer oyunlar

Önceki 1.8.0 düzeltmeleri ve oyun/veri konumları korunur; tam komut rehberi `MEVCUT-OYUNLAR-KOMUTLAR.md` içindedir. Çöken Otel ve Altın Tavuk hâlâ çıkarılmıştır. Kargo Ustası/Ayna Mimar ayrı, isteğe bağlı deneme paketindedir; bu güncellemede Kargo değişmedi, Ayna Mimar 0.1.1 eklendi.
