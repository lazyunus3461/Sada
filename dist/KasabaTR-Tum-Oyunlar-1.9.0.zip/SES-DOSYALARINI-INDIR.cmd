@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ses\SES-DOSYALARINI-INDIR.ps1"
pause
