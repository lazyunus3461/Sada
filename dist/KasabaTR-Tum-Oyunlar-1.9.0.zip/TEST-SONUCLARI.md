# KasabaTR 1.9.0 — son kapsam ve doğrulama

Paper **1.21.10 build 130**, Java **21**, ayrı **127.0.0.1** test sunucusu. Kullanıcının son isteğiyle **hile koruması çıkarıldı**: KasabaKoruma veya GrimAC dağıtılmaz. Üç yeni eklenti **KasabaEvcil / KasabaYedek / KasabaVitrin** kendi kodumuzdur. Ek olarak **Ayna Mimar 0.1.1** dikey duvar ve özel bölümlerle güncellendi.

Tam ZIP: **23 ortak/oyun eklentisi + isteğe bağlı Ayna Mimar = 24 JAR**. Güncelleme ZIP: **7 JAR**. Kargo Ustası değiştirilmedi ve bu pakete eklenmedi. Önceden açık Ayna ayarları korunur; yeni kurulumda varsayılan onay kapalıdır.

## Kontroller

- **206 üretim birim testi + Ayna Mimar için 3 test**, hata/başarısız/atlanan yok. Gerçek arşiv dosyaları, SHA256 bozulması, yol/symlink/kaçış, yarım dosya temizliği, saklama ve başka ZIP'lerin korunması; evcil tercih kalıcılığı/bozuk dosya/tür sınırı; vitrinin iki satırı ve gerçek sayaçlar; dikey duvar koordinatları/yönü ve eski zeminin düzenlenememesi.
- Üç kendi altyapı eklentimiz, mevcut 20 eklentiyle Paper'da birlikte açılır; SimplePets, MiniMOTD, DriveBackupV2, GrimAC ve KasabaKoruma kurulu değildir. Sunucu listesinden **gerçek Minecraft durum sorgusu**: renkli iki satır, gerçek üç oyuncu, boş isim örneği, bakım metni aç/kapat.
- Gerçek `/evcil` menüsünden kedi/kurt seçimi, tek hayvan sınırı, eski düğmeyle çoğaltamama, vurma/etkileşim/binme engeli; oyuncu gizleme ile petin de gizlenmesi. Arena güvenli lobisinde hayvan, X Arena'da kaldırılma ve lobiye kayıtlı hayvanla dönüş. Yetkili yeni yönetim komutları korumalı oyun lobisinde çalışır.
- Gerçek yaklaşık **227 MB** kaynak için arka plan ZIP'i: dünya ve hesap IP anahtarı alınır, geçici dünyalar/kilit/kendi arşivleri dışlanır; normal oyuncu başlatamaz, ikinci eşzamanlı iş reddedilir, önceki otomatik dünya kayıt bayrakları geri gelir. Arşiv CRC ve içerik doğrulaması yapıldı. Gerçek yedek ZIP'i hesap verisi içerdiği için dağıtılmaz.
- Yeni profilde yeniden çalışan kontroller: ses/yönetim, VIP terk cezası, lonca/sohbet, ortak/VIP odaları/60 saniye/izleyici, Banka iki tur ve üç dünya, ayrı HUD, eşya nesne ışığı/tıklama, ada/ilk Creative/ikinci ada seçimi/balık kotası.
- Ayna: model dikey duvarda gösterilir ve kaybolur; gerçek Minecraft sağ tıklaması aynı dikey duvara yün koyar. Eski yatay zemin korunur. Rakibin bölümüne yürümek/ışınlanmak engellenir, tavan ve iki uç kapalıdır; katılımcılar rakipten ve dışarıdaki oyuncudan gizlidir. Üç tur duvar puanlaması, geçici dünya temizliği, lobiye dönüşte görünürlük ve envanter geri gelir.
- Son temiz açılışta ses test adaptörü çıkarılır ve kayıt/IP kuralı tekrar açılır. Evcil seçimi ve tamamlanmış yedek listesi yeniden başlatmada korunur. Paket JAR'ları ilgili native test SHA256'larıyla eşleşir.

## Sınırlar

Oyuncunun canlı sunucusuna dosya yüklenmedi. Yedek yerel ZIP'tir; uzak bulut hesabına bağlanılmaz. Canlı verilerin tümü için veritabanı anlık görüntüsü garantisi veya yüksek oyuncu yükü testi yoktur.

Panelde ayırılan **26338** ses portu için örnek ayar hazırdır. Gerçek UDP erişimi/mikrofon buradan doğrulanmadı; ses API testi ayrı loopback adaptörüyledir. Üretim ZIP'lerinde test eklentileri, gerçek oyuncu hesapları, özel IP anahtarı veya dünya verisi bulunmaz. Ses için daha önce seçilen tek Simple Voice Chat modu ayrı kalır.
