# 29 Ekim 2026 akşam kayıtlarının incelemesi

10 yüklenen kaydın toplamı 637,194 saniye (10 dakika 37 saniye). Görüntüler başlangıçtan sona saniyelik kareler halinde incelendi; son 2,5 saniyeler ayrıca saniyede 5 kare olarak çıkarıldı. Menü açıklamaları asıl 906–930 piksel genişliğindeki karelerde açıldı. Bu yöntem, gerçek zamanlı bir Minecraft istemcisiyle oynama veya her 30 FPS karenin ayrı ayrı incelenmesi değildir. Dokuz kaydın ses kanalı sessiz (-91 dB); 20:23:29 kaydında çok düşük seviyeli ses var, konuşma transkripsiyonu yapılmadı. Kaynak videolar dağıtım paketine konmaz.

| Kayıt | Süre | Görülenler ve önemli zamanlar |
|---|---:|---|
| 19:56:40 | 110,549 sn | 0–13 warp menüsü: hayvanlar/PvP/etkinlik/mob/zindan/kasalar; 14–108 kasalar alanı ve ödül önizlemeleri. Spawner, kasa anahtarı, süreli VIP, yapı malzemeleri, eşya, para ödülleri. 22–28 Deniz Kalbi açıklaması, 36–49 Kadim, 52–55 Kazan Kaybet, 58–63 Kaos, 66–69 Reborn, 74–80 Efsanevi, 83–90 Nadir, 92–97 Ödül, 100–106 Şanslı. |
| 20:07:42 | 26,795 sn | VIP paketlerinin fiyatları/hediyeleri; 1–3 ilk kademe, 4–5 ikinci, 6–7 üçüncü, 8–9 dördüncü, 12–13 üst paket. 14–23 yıldızla yükselen VIP kasası, miktar ve satın alma onayı. Uzun açıklamaların üst satırları ekran dışındadır; bütün yetkiler okunmuş sayılmaz. |
| 20:09:35 | 84,373 sn | 0–13 kredi/VIP marketi; 14–18 anahtarlar; 21–30 spawnerlar/rastgele kutu; 33–38 çiftçi seti/uçuş; 40 kozmetik; 42 geçmiş/hediye kabulü; 44–60 malzeme marketine geçiş ve kategoriler; 65–70 kazıcı/besleyici; 74–78 büyük depo; 80–81 çiftçi. |
| 20:13:31 | 92,117 sn | 0–15 temel bloklar; 16–24 renkler; 25–38 yapı parçaları; 39–41 odun; 42–48 maden; 49–54 tarım/yiyecek; 55–60 mob ürünleri; 62–68 yumurtalar; 69–75 çeşitli. Kategoriler sabit düğmeler, içerik sayfalanıyor; mevcut bakiye görünür. 90–son sohbet girişinde tam metin: “sonuna kadar izlediysen bana izledim knk de”. Parola: **izledim knk**. |
| 20:16:40 | 21,013 sn | 0–6 çimen seviyesinde çok küçük tuzak kapaklı görünür lav/taş/su jeneratörü; 7–10 başlangıç sandığı ve ağacın dibindeki sandık; 11–19 rehber karakter, adanın altı/şekli, boşluğa düşüş ve geri dönüş. Kullanıcı 20:16:40 kaydındaki küçük düzeneği açıkça onayladı; bu şekil esas alındı. |
| 20:19:56 | 32,512 sn | 0–7 oynayarak kazanılan para için satılabilir ürünler; 8–11 para açıklaması ve stok yenileme saati; 13–19 sınırlı stoklu anahtar/kutu/VIP; 22–30 sürekli stoklu ödüller. |
| 20:21:18 | 18,219 sn | Ada tüccarı aşamaları; 2–5 kilitli aşama/seviye/takas eşikleri; 6–9 açıklama; 10 son takası tekrarla; 11 üye erişimi; 12–14 aşama içerikleri. |
| 20:23:29 | 97,109 sn | Ortak buğday alanına warp, 4–8 havada 15 dakika yenilenme sayacı; 9–71 kesme ve ürün toplama. Aynı yerde diğer oyuncular. Her ürünün sohbet mesajı oluşturması okunurluk sorunu; bizim uygulamada eylem çubuğu/toplu bildirim tercih edilir. 72–83 sat/hepsi ile satış; 84–son hasada devam. |
| 20:24:36 | 43,520 sn | Ortak tarla, 1–30 hasat ve oyuncular; 31–39 satış menüsüne ürün koyup satış; 40–son tarlaya dönüş. Alan bütünüyle özel bir kopya değil. |
| 20:25:37 | 10,987 sn | 0–4 biçilen tarlanın görünüşü, 7–9 yerleşim/peyzaj, 10–son duraklatma. |

## Uygulama kararı

- Kullanıcının son isteği kişisel tarla isteğinin yerini alır: tek ortak kasaba tarlası, ortak 15 dakika yenilenmesi. Eski özel tarla kayıtları/dünyadaki yapılar oyuncu verisi silinmeden erişimden çıkarılır.
- /market dar bir alış/satış girişi olmalı. Market alt sekmeleri bütün alt sayfalarda aynı sırada kalmalı; VIP/spawner/minyon içeriği malzeme listesine karıştırılmamalı. Spawner simgesi SPAWNER olmalı.
- Jeneratör ve minyon geliştirmelerinde işlev, mevcut durum, sonraki maliyet, ödeme kaynağı ve kilit sebebi ayrı kısa satırlar olmalı. Yükseltme önce onaylanmalı.
- Elle besleme üretici başına günlük sınır taşımalı. Bakıcı kendi sandığındaki gerçek ekmeği kullanır; bu sınırı iş paylaşımıyla ortadan kaldırmak mümkün olmamalı.
- Dört rütbe: VIP, VIP+, MegaVIP, UltraVIP. Mevcut süreler ve kalıcı atamalar korunmalı. Eski oyunlardaki VIP özel oda ve diğer gerçekten mevcut haklar bütün VIP kademelerine aktarılmalı; yeni savaş avantajı uydurulmamalı.
- İnek/domuz/tavuk için tek ortak hayvan alanı; kontrollü yeniden doğma, yalnız bu hayvanlara kesim izni, alan/NPC koruması ve doğurma yumurtası yasağı sürmeli.
- Kasalar özgün adlar ve oranlarla tasarlanmalı; önizleme, açık oranlar, anahtar bakiyesi, onay, kalıcı ödül ve tekrar tıklama koruması olmalı. Başka sunucunun isimleri/ekonomisi birebir alınmaz.

## Ek kayıt: 21:28:49 (22,571 saniye)

Kayıt baştan sona saniyelik karelerle incelendi; önizleme ve ödül kareleri tam çözünürlükte açıldı. 0–8 kasa meydanı ve VIP kasaları; 9–12 kişisel açılış sayısı, sol tık önizleme / sağ tık açılış; 13–14 ödül listesi (para, VIP, spawner, bloklar); 15–19 anahtar kontrolü ve gerçek açılış sonunda ürün kazanma; 20–22 meydandan çıkış/duraklatma. Yeni bir son parola görünmüyor. Bizde özgün beş kasa korunur; sol tık önizleme, sağ tık son onay, kişiye özel kalıcı açılış sayısı ve anahtar bakiyesi eklenir. Ses transkripsiyonu yapılmadı; bulgular görüntüye dayanır.

## Son kullanıcı düzeltmeleri

- Mühürün adı **Yonca** olur. Aynı `seal:` kayıtları korunur; yeni ve kafa karıştırıcı bir bakiye eklenmez.
- Yonca alanı tek ortak stoktur: önce gelen kazır; yenilenince tıklanabilir “Yonca yenilendi! /warp yoncatarla” duyurusu çıkar. Varsayılan 24 bitki, bitki başına 1 Yonca, 15 dakika; yönetici süre/ödülü ayarlayabilir. Buğdayla aynı bitki veya para alanı değildir.
- `/market` Skyblock kaynak alışverişidir. VIP satışını veya VIP haklarına satış bağlantısını içermez. Dört VIP paketi `/sb` menüsünde ayrı bölümde kalır.
