# KasabaLabirent 1.0.0

Paper 1.21.10 / Java21 / KasabaAuth / KasabaHub1.12.

Özgün Değişen Labirent: 13×13 hücre, her oyuncuya özel üç mühür, çıkış yarışı, 45 saniyede bir bağlantılı yeni duvar düzeni ve beş saniye uyarı. Oyuncunun kapladığı yer ve yakın geri çekilme alanına duvar eklenmez. Tek kişilik deneme veya mevcut Hub kuyruğu/partileriyle 2–8 kişilik maç. Türkçe pusula menüsü ve ilk yardım; kişisel mühürler, üst süre çubuğu, yan panel, korumalar ve envanter kurtarma.

Oda dünyaları eklentiye ait işaretli geçici dünyalardır. Normal kapanışta boş olanlar temizlenir. Sunucu zorla kapatılırsa kalan `kasaba_labirent_oda_*` klasörleri oyuncu eşyası içermez; oyuncu yedeği `plugins/KasabaLabirent/recoveries` içinde kalır. Sonraki hesap girişinde kurtarılır. İşaretsiz dünyalara dokunulmaz.

Maven ile `mvn package`. KasabaAuth1.4 minimum API ve Hub1.12 sağlanan bağımlılıkları yerel Maven deposunda olmalıdır. Beş birim testi yüzlerce üretim tohumu üzerinde bağlantı, güvenli değişim, sınır, tekrar toplamayı engelleme ve çıkış kilidini doğrular. Yerel Paper protokol sonuçları dağıtım paketindedir. Özel test adaptörleri dağıtılmaz.
