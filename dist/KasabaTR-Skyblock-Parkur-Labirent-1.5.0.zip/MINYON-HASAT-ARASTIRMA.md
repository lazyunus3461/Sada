# Hasat ve minyon düzenlemesi için araştırma notu

## Kaynağı gerçekten okunan mekanikler

- [NEU Cobblestone Minion I kaydı](https://raw.githubusercontent.com/NotEnoughUpdates/NotEnoughUpdates-REPO/master/items/COBBLESTONE_GENERATOR_1.json): açık alan, blok üretme/kazma, çevrimdışı çalışma, 14 saniyelik örnek eylem aralığı ve sınırlı depo kavramlarını açıklar. HTTP 200 ile okundu.
- [NEU Small Storage kaydı](https://raw.githubusercontent.com/NotEnoughUpdates/NotEnoughUpdates-REPO/master/items/SMALL_ENCHANTED_CHEST.json): minyonun yanına konan sandığa ürün aktarımı ve ayrı depolama alanı tarif edilir. Bu referansta sandık, iç depo dolunca kullanılan üç alanlı ek depodur. HTTP 200 ile okundu.
- [BentoBox Greenhouses](https://raw.githubusercontent.com/BentoBoxWorld/Greenhouses/develop/README.md): ada içindeki sınırlı bölgenin kendi bitki/biyom/yağış davranışını ve bölgesel yönetim fikrini gösterir. HTTP 200 ile okundu. Bu eklenti pakete eklenmez ve kodu alınmaz.

Kasaba'da uygulanan tasarım bunlarla aynı ürün değildir: Taşçı mevcut jeneratörün taş ve cevher çıktısını işler; ürün doğrudan kendi açılabilir sandığında birikir. Ayrı bir “depoyu topla” aşaması kullanılmaz. 4/2,5/1,5 saniyelik Taşçı aralıkları ve 9–54 alanlı sandık Kasaba'nın denge tercihidir; kaynak belgedeki değerler kopyalanmış gibi sunulmaz.

## Güncel ortak tarla kararı

Kullanıcının son talebi önceki kişisel bahçe isteğinin yerini alır. Yeni sistemde SB kasabasındaki **tek buğday tarlası** herkes tarafından birlikte kullanılır; toplam154buğday ve ortak15dakika sayacı vardır. İlk biçen ürünü alır. 616Altın/yenilenme toplam alan arzıdır, kişi başı kota değildir. Koruma olgun buğdaya izin verir; toprak/su/yapılar korunur. Eski özel bahçe kayıtları silinmeden erişimden çıkarılır.

Ayrı **Yonca tarlası** ortak sınırlı stoktur. Varsayılan24yeşil bitki, bitki başına1Yonca ve15dakikada yenilenme; önce gelen toplar. Yenilenince “Yonca yenilendi! /warp yoncatarla” tıklanabilir duyurusu çıkar. Süre ve ödül yönetici ayarından değişir. Mühür bakiyesi yeni bir para oluşturmadan aynı kayıtlarla Yonca adını alır. Bitki/sayaç/ödül birlikte kalıcı kaydedilir; aynı bitki ikinci kez ödeme yapmaz. Yeniden giriş/yeniden başlatma stokları sıfırlamaz.

Elle minyon besleme üretici başına varsayılan60dakika/Türkiye günüyle sınırlıdır ve bütün üyeler/kooperatif ortak kullanır. Bakıcının gerçek ekmek dağıtımı bu el kotasını kullanmaz. Bu, Bakıcıya gerçek bir kullanım amacı sağlar; minyonu söküp aynı yuvaya kurmak günlük kotayı yenilemez.

## Erişim sınırları

Hypixel Wiki ve AdvancedPlugins minyon sayfaları bu ortamda 403 erişim hatası verdi; okunmuş veya video izlenmiş sayılmaz. Açık raw GitHub kayıtları okundu ve yerel kopyaları `/workspace/scratch/skyblock130-research` altında saklandı. Paper başlangıç belgesinin denenmiş raw yolu 404 döndü; yazılım gereksinimleri bu notta mevcut POM ve plugin.yml dosyalarından doğrulandı. Üretim oyuncu yükü benchmark'ı yapılmış değildir.
