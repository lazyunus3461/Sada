# KasabaParkur 1.2.1

Paper1.21.10 / Java21 / KasabaAuth / KasabaHub1.12. Üç ayrı 100 bölümlük rota; yeni kıvrımlı geometri, 21–22 engel ailesi, canlı en ileri beş oyuncu sıralaması ve ayrı bitiriş süresi rekorları. Deneme/yardımlı koşular sıralamaya girmez. Düşünce rotanın en başına dönülür.

Yeni dünya `kasaba_parkur_v12`; önceki dünya ve rekorlar silinmez. Rotalar değiştiği için yeni süre dosyası `sure-rekorlari-v12.json`. Eski config bir kez yedeklenir. Ayrıntılı kurulum dağıtım ZIP’indedir.

Haritayı üretmek için Python3, numpy, nbtlib, Pillow ile `scripts/build-world.py`, fiziksel blok denetimi için `scripts/audit-world.py`; ardından Java21/Maven `mvn package`. Kendi boş dünya NBT şablonu scripts/void-level-template.dat ve üretilmiş hazır harita dağıtım kaynağında bulunur. JAR’dan dünya ilk kez güvenli geçici klasöre açılır. Var olan dünya üzerine yazılmaz.

1.2.1: Renksiz scoreboard takımı varken canlı panelin açılmaması düzeltildi; taşınan takımın renk ve çarpışma/görünürlük seçenekleri korunur.
