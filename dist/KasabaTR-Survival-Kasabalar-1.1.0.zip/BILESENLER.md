# Bileşenler ve kaynakları

KasabaHub 1.10.0, KasabaRoles 1.5.1, KasabaKimlik 0.2.2, KasabaSikke 1.1.0 ve KasabaTowny 1.1.0 KasabaTR kaynaklarından derlendi. Değişen modüllerin kaynakları kaynak/KasabaTR-Survival-1.1.0-KAYNAK.zip içindedir.

Towny 0.103.2.14: yüklenen paketteki JAR değiştirilmeden kullanıldı. Yazarlar LlmDl, Warrior ve TownyAdvanced katkıcıları. https://github.com/TownyAdvanced/Towny/tree/0.103.2.14 — CC BY-NC-ND 3.0. Lisans ve aynı etiketin kaynakları eklidir.

Vault 1.7.3: yüklenen paketteki JAR değiştirilmeden kullanıldı. MilkBowl / Sleaker ve katkıcıları. https://github.com/MilkBowl/Vault/tree/1.7.3 — LGPL-3.0. Lisans ve aynı etiketin kaynakları eklidir.

Chunky 1.4.0-kasabatr: pop4959/Chunky resmi 1.4.0 etiketi, commit cb3aee6217d0d3cad43e871595739302c2a59326. https://github.com/pop4959/Chunky/tree/cb3aee6217d0d3cad43e871595739302c2a59326 — GPL-3.0. Java21/Paper derlemesinde yalnız isteğe bağlı bStats ve üçüncü taraf WorldBorder bağlantıları çıkarıldı; chunk üretim çekirdeği değiştirilmedi. Tam değişmiş kaynaklar, lisans ve yeniden derleme betiği kaynak/Chunky-1.4.0-kasabatr-SOURCES.zip içindedir. Standart Chunky komutları durur; KasabaTR kendi hazırlık planını API'den yönetir.

Bağımlılık JAR'larının adını değiştirerek ikinci kopyasını bırakmayın. ZIP test/Probe eklentisi veya canlı oyuncu verisi içermez.
