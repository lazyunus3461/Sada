# KasabaTR Survival / Kasabalar 1.1.0

Paper 1.21.10 ve Java 21 içindir. Bu bir güncelleme paketidir: mevcut KasabaTR sunucusu (KasabaAuth ve diğer oyunlar) gerekir. Canlı sunucuya yükleme yapılmadı; yüklemeyi sunucu sahibi yapacak.

## Yükleme

1. Sunucuyu durdur. Dünya klasörleri ile `plugins/` klasörünün yedeğini al.
2. `plugins/` içindeki eski **KasabaHub, KasabaRoles, KasabaKimlik, KasabaSikke, KasabaTowny** JAR'larını çıkar; bu eklentilerin veri klasörlerini koru. ZIP'in `plugins/` içindeki JAR'larını yükle. Towny, Vault veya Chunky zaten varsa aynı eklentinin iki JAR'ını birlikte bırakma. Başka ekonomi sağlayıcılı bağımsız bir Towny kurulumunun üzerine bu paketi doğrudan kurma.
3. Sunucuyu normal şekilde başlat; `/reload` kullanma. Yeni dünyalar otomatik oluşur, ayrıca dünya indirmen gerekmez. Mevcut Arena/lobi spawn dosyalarını bu ZIP değiştirmez.
4. Konsoldan `ktr hazirlik durum` ile harita hazırlığını takip et. İlk hazırlık bitene kadar Survival'ı oyunculara açmamak için `yonet bakim survival ac` kullan; hazırlanırken kurucu test edebilir. Bitince `yonet bakim survival kapat`.
5. `/oyunlar` üst satırındaki **Survival • Kasabalar** ile gir. `/ktr rehber` açıklamaları gösterir.

## Dünyalar ve Chunky

- `kasabatr_survival`: kalıcı ana dünya, **10.000×10.000 blok**. Kasabalar burada kurulur.
- `kasabatr_kaynak`: ayrı kaynak/maden dünyası, 4.000×4.000. Burada kasaba kurulmaz. `/ktr kaynak`, dönüş `/ktr don`.
- `kasabatr_survival_nether`: 1.250×1.250; `kasabatr_survival_the_end`: 5.000×5.000.
- `kasabatr_sancak` ve `kasabatr_boss`: ayrı savaş/boss alanları.

Chunky bu dört doğal dünyayı sırayla oluşturur. Normal oyuncu çevrimiçiyken, TPS 18,5 altındayken, RAM veya disk alanı azken duraklar; koşullar düzelince sürer. İlk hazırlık donanıma göre uzun sürebilir ve disk kullanır. Chunky, yeni arazi üretiminin maç sırasında oluşturacağı yükü azaltır; bütün lag nedenlerini kaldırmaz. Bu paket hazır üretilmiş 10.000×10.000 harita içermez.

Yönetici: `/ktr hazirlik durum`, `/ktr hazirlik baslat`, `/ktr hazirlik duraklat`, `/ktr hazirlik devam`. Konsolda baştaki `/` kullanılmaz. Otomatik planla aynı dünyada ayrıca elle farklı Chunky işi başlatma.

Ana dünya kalıcıdır. Kaynak dünyası malzeme toplamak içindir; **otomatik silme/sıfırlama takvimi eklenmedi**. Portal geçişleri bu Survival boyutlarına yönlenir. Survival çantası, ender sandığı ve XP diğer oyunlardan ayrı saklanır.

## Para ve kasabalar

**Sikke** yalnız Survival ekonomisidir; **Akçe** mevcut sunucu parası olarak ayrı kalır.

- `/sikke`: bakiye. `/ktr gunluk`: günde bir 12 Sikke; her yedinci gün +8. Gün sınırı Türkiye saatidir.
- `/ktr teslim bugday|komur|bakir|demir|balik Adet`: malzeme sat. Günlük teslim geliri en fazla 400 Sikke. Birim fiyat: 0,40 / 0,70 / 0,90 / 1,25 / 1,00 Sikke.
- `/ktr takas teklif Oyuncu 5.50`: elindeki eşya yığınını en fazla 5 blok uzaktaki oyuncuya teklif et. Alıcı `/ktr takas kabul`; iptal `/ktr takas iptal`.
- `/town new KasabaAdi`, ardından **`/confirm`**: 400 Sikke, ilk 4 chunk (32×32 alan) dahil. `/town add Oyuncu`: üye daveti. `/town claim`: ilave arazi, 40 Sikke.
- En fazla 25 üye. Başlangıç 4 claim; 17 üyede 16 claim aşamasına geçilir. `/ktr proje` menüsü ek arazi/savunma projelerini gösterir; claim üst sınırı 36.
- `/ktr gorev`: kasabanın haftalık ortak görevleri. `/ktr gorev odun|tas|demir`: envanterden katkı yap. 500 kütük / 768 kırıktaş veya kırık kayraktaşı / 128 demir külçesi görevlerine karşılık ortak kasaya 30 / 40 / 50 Sikke. Pazartesi yenilenir; ödül görevi bitiren oyuncuya değil kasabaya gider.
- İlk 7 gün bakım ücretsiz; sonra kasaba kasasından 5 Sikke/gün. Ödenmezse uyarı süresinden sonra arazi koruması kalkabilir; yapılar silinmez. `/ktr durum`, `/ktr vergi`, `/ktr harita` ayrıntıları gösterir.
- `/ktr savas`, `/ktr boss`: paket içindeki ayrı savaş ve boss mekanikleri. Kasabalar ilk 72 saat savaş korumasındadır; savaş gerçek evleri yıkmaz.

Kütüphaneci büyü kitabı teklifleri, Survival dünyalarında zombileştirip iyileştirerek ucuzlatılamaz. Kitaplar taban teklifin %125'iyle (en fazla 64 zümrüt) sabitlenir; tekrar açma/iyileştirme fiyatı tekrar tekrar çarpmaz. Diğer meslekler ve diğer oyun dünyalarının alışverişi değiştirilmez.

## Sunucu genelindeki ekler

- `/sor Arena'da kit nasıl alırım?`: ücretsiz ve özel rehber yanıtı. Gerçek sunucu bilgilerine dayalıdır; dış AI hizmeti veya API anahtarı gerektirmez. Bilmediği soruda cevap uydurmaz.
- `/yonet` → bakım menüsü; doğrudan `/yonet bakim arena ac|kapat` veya `survival`, `renk` gibi oyun kimliği. `ac` bakıma alır, `kapat` bakımdan çıkarır. Devam eden maçlar bitmeye devam eder. OP/Kurucu test için girebilir; VIP bakım engelini aşmaz. Kalıcı ayarlar `KasabaHub/bakim.yml` içindedir.
- `/beta ver Oyuncu`, `/beta al Oyuncu`, `/beta liste`: yönetici için kalıcı **Öncü** takdiri. Küçük ✧ işareti; oyun gücü veya yönetici yetkisi vermez. VIP/Kurucu/Rehber rolünü silmez, bitiş tarihi yoktur.
- Kimlik etiketi, oyuncunun klanı yoksa Survival kasabasını Towny API üzerinden gösterebilir; PlaceholderAPI şart değildir.
- Ana pusula menüsündeki **VIP satın al** kısayolu kaldırıldı. Mevcut VIP avantajları/fiyatları ve marketin yeniden düzenlenmesi sonraya bırakıldı; bu paket yeni VIP ürünü eklemez.

## Dosyalar

ZIP'te yalnız güncellenen beş KasabaTR eklentisi ile Towny, Vault ve Chunky vardır. Oyun/veri klasörlerinin tamamını değiştiren bir paket değildir. Kaynaklar `kaynak/`, lisans/kaynak kökenleri `BILESENLER.md`, test kapsamı `TEST-SONUCLARI.json`, bütünlük değerleri `SHA256SUMS.txt` içindedir. Özel test eklentileri dağıtıma dahil değildir.

Towny'nin mevcut ayarı ilk uyarlamada `config-before-kasabatr-1.1.0.yml` adıyla yedeklenir. Vergi/para ve yeni dünya varsayılanları bir kez uyarlanır. KasabaTR verileri bozuksa sessiz sıfırlama yerine açılış durdurulur; konsoldaki hatayı düzeltip yeniden başlat.
