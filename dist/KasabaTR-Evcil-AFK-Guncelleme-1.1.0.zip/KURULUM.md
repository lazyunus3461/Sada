# Evcil Mağazası, AFK Akçe Koruması ve Sağ Panel

## Yükleme

1. Sunucuyu durdur ve `plugins/` klasörünü yedekle.
2. Eski KasabaAuth, KasabaHub, KasabaSosyal, KasabaArena, KasabaParkur ve
   KasabaEvcil ve KasabaBilgi JAR dosyalarını kaldır. **Eklenti veri klasörlerini silme.**
3. ZIP'in `plugins/` klasöründeki yedi JAR'ı sunucunun `plugins/` klasörüne koy.
4. Sunucuyu başlat; `/reload` kullanma. Harita veya spawn kurulumunu tekrarlama.

Paper 1.21.10 / Java 21 ve mevcut KasabaAkce/KasabaRoles altyapısı gerekir.
Sürümler: Auth 1.4.2, Hub 1.9.5, Sosyal 1.3.3, Arena 1.4.3,
Parkur 1.1.1, Evcil 1.1.0, Bilgi 1.0.6.

## Evcil mağazası

- `/evcil`: Sayfalı tür listesi, bakiye ve fiyatlar. Yeni tür için onay ekranı açılır.
- `/dost papagan`: Papağan satın alma sayfası; sahipsen ücretsiz çağırır.
- `/dost kapat`: Evcili gizle; sahipliğin veya VIP hakkın sıfırlanmaz.
- **Bütün türler 10 Akçe.** VIP'in ilk edindiği tür bir kez ücretsizdir;
  ikinci ve sonraki türler 10 Akçedir. Bu hak VIP yenilemede yeniden verilmez.
- Türler kalıcı açılır. Sahip olduğun bir türü tekrar çağırmak veya diğer
  sahip olduğun türe geçmek için para alınmaz. Aynı anda yalnız bir evcil görünür.
- 39 tür: kedi, kurt, papağan, tavşan, tilki, panda, inek, mantar ineği, koyun,
  domuz, tavuk, keçi, at, iskelet at, zombi at, eşek, katır, deve, lama,
  tüccar laması, kaplumbağa, kurbağa, aksolotl, arı, yarasa, oselot,
  kutup ayısı, armadillo, koklayıcı, lavgezer, hoglin, yunus, mürekkep balığı,
  parlayan mürekkep balığı, morina, somon, tropik balık, kirpi balığı, mutlu ghast.
- Evciller kozmetiktir. AI, saldırı, eşya toplama, çiftleşme ve binme kapalıdır.
  Büyük türler küçültülür; uçan/su türleri sahibinin yanında havada gösterilir.
- Yalnız spawn ve güvenli oyun lobilerinde görünür; aktif oyunda gizlenir.
  Lobiye dönünce seçili evcil geri gelir. Oyuncu gizleme evcili de gizler.
- İlk evcil yokken menünün kendiliğinden düğmeleri geçersiz kılması düzeltildi.
  Parkur lobisi de gerçek evcillere izin verir; rastgele yaratıklar açılmaz.

Sahiplik, seçili tür, ücretsiz hak ve bekleyen işlemler `KasabaEvcil/evciller.json`
dosyasına kaydedilir. Ödeme kimliği Akçe sisteminde tek sefer uygulanır; ödeme
sonrası kesinti olursa bekleyen edinim aynı işlemle tamamlanır. Yetersiz bakiyede
hak açılmaz. Önceden seçilmiş kedi/kurt korunur; bu eski ücretsiz edinim tek
ücretsiz hak sayılır. Eski `secimler.properties` dosyası değiştirilmez.

## Parkur ve X Arena AFK kuralı

- Oyuncu 5 dakika boyunca son anlamlı hareket noktasının çevresindeki
  **5×5 blokluk yatay alanın** dışına çıkmazsa AFK sayılır.
- AFK sırasında 15 dakikalık aktiflik süresi birikmez ve bu süreyle yeni ödül
  kazanılmaz. Daha önce kazanılmış süre silinmez.
- Zıplama, bakış çevirme, tıklama, menü kullanma ve yerinde küçük hareketler
  AFK sayacını sıfırlamaz. X Arena'da yerinde vuruş yapmak da yeterli değildir.
- Alanın dışına normal hareketle çıkınca aktiflik birikimi yeniden başlar.
- Parkurda otomatik başa dönüş, ölüm ışınlanması veya başka ışınlanmalar AFK
  sayacını sıfırlamaz. Çıkıp girme ve sunucu yeniden başlatma da yeni süre hakkı vermez.
- Kural Parkur'un aktif rotalarında ve X Arena'dadır. 1v1/2v2 ve diğer maçların
  mevcut aktiflik ölçümü korunur; lobi/seyirci/hapishane zaten sayılmaz.
- Toplam 15 dakika = 0,20 Akçe; günlük en çok 5 ödül kuralı devam eder.
- `/kazanç` ve rehber kitabı bu kuralı açıklar; oyuncuya AFK/aktif bildirimleri gelir.

## İlk giriş yazısı

“Kasaba'ya Hoş Geldin” büyük başlık yerine Minecraft'ın **yarı boydaki alt başlık**
satırında gösterilir. Kayıt/giriş yönlendirmesi ayrı kısa mesajdır. Mod veya
kaynak paketi gerekmez; istemcinin arayüz ölçeği görüntüyü ayrıca etkiler.

## Sağ bilgi paneli

Alttaki sunucu adresi, Discord, Instagram ve ayırıcı çizgi kaldırıldı. Panelin
genişliği artık uzun sosyal medya satırlarına göre büyümez; Minecraft'ın sağ
kenarına dayanan daha dar bir panel görünür. Oyuncu, rütbe, Akçe, klan ve süre
etiketleri ile renkleri korunur. Lobide 7, oyunda 5 satırdır. Oyunun kendi puan
tablosu varsa öncelik yine ondadır. `/tablo aç` ve `/tablo kapat` kullanılabilir.

Test kapsamı `TEST-SONUCLARI.json` içindedir. Testler yerel Paper sunucusundadır;
canlı sunucuya bağlanılmadı ve yüklemeyi sen yapacaksın.
