# KasabaTR Kimlik 0.2.0 — hazır sunucu uyarlaması

Paper 1.21.10 / Java 21. Bu paket, gönderilen Kimlik 0.1.0 kaynaklarının
mevcut KasabaTR altyapısına uyarlanmış sürümüdür.

## Kurulum

1. Sunucuyu durdur ve `plugins/` klasörünü yedekle.
2. Eski `KasabaKimlik-*.jar` varsa kaldır. Eski `KasabaRoles-*.jar` ve
   `KasabaBilgi-*.jar` dosyalarını da kaldır; aynı eklentinin iki sürümünü bırakma.
3. ZIP içindeki `plugins/` klasöründen **üç JAR'ı** sunucunun `plugins/` klasörüne koy:
   `KasabaKimlik-0.2.0.jar`, `KasabaRoles-1.4.3.jar`, `KasabaBilgi-1.0.7.jar`.
4. Sunucuyu başlat. `/reload` kullanma. **Eklenti veri klasörlerini silme.**

Mevcut KasabaAuth ve KasabaHub gerekir. Rol atamaları, VIP süreleri, Akçe,
klanlar, dünyalar ve kayıtlı lobi/arena konumları değiştirilmez. Harita yüklemek
veya spawn komutlarını yeniden yazmak gerekmez. Yeni eklenti otomatik etkinleşir.

## Kafa üstü kimliği

Örnek: gerçek rütbesi Kurucu, klanı KSB olan bir oyuncu:

```text
✦ KURUCU ✦
⚑ [KSB] · KLAN
OyuncuAdı
```

- Rütbe ve renk **KasabaRoles** servisinden okunur. Kurucu, Admin, Moderatör,
  Rehber, VIP, Oyuncu ve özel eklenmiş roller otomatik desteklenir.
- Geçici VIP ve staff önceliği mevcut rütbe sistemiyle aynıdır; kimlik için
  ayrı bir rol/yetki veya LuckPerms kurulumu gerekmez.
- Klan satırı **KasabaTopluluk** servisinden okunur. Klan kurma, katılma,
  ayrılma ve etiket değişiklikleri yaklaşık iki saniyede güncellenir.
- Klan yoksa `◇ KASABATR · YOLCU` görünür. Kasaba veya başkanlık uydurulmaz.
- Gönderilen paketteki isteğe bağlı Towny desteği korunur: Towny ve PlaceholderAPI
  gerçekten kuruluysa, klanı olmayan oyuncunun kasaba/rol bilgisi okunabilir.
  Bu eklentiler gerekli değildir ve bu pakete eklenmemiştir.
- Rozetler başkalarının oyuncunun üzerinde gördüğü iki yazıdır. Kendi başındaki
  rozetler kendi istemcisine gönderilmez; kendi bilgini `/kimlik` ile görürsün.
- Normal oyuncu adı korunur. KasabaRoles aynı rol/klan önekini kafa üstünde
  ikinci kez yazmaz; sohbet ve TAB listesinin renkli biçimi korunur.
- Yaklaşık 24 blok görüş mesafesi ve küçük, hafif arka planlı yazı kullanılır.
  Rozetler oyuncuyu takip eder; **oyuncuya yolcu olarak bağlanmaz.** Bu nedenle
  ışınlanmayı ve at/tekneye binmeyi etkilemez. Envantere eşya eklenmez.

## Oyun gizliliği

Aktif yerel mini oyunlarda kimlik rozetleri kaldırılır. Özellikle Eşya Saklambacı,
Battle Royale ve Vampir Köylü'nün isim/gizlilik kuralları aşılmaz; X Arena ve
aktif parkurda da rozetler kapalıdır. Oyun lobisine dönünce yeniden görünür.

Giriş yapmamış, görünmez, ölü, hayalet/seyirci veya gizlenmiş oyuncuların
rozetleri gösterilmez. Oyuncu gizleme düğmesi rozetleri de o izleyiciden gizler.
Takımların isim görünürlüğü ve dünya/mesafe sınırları ayrıca kontrol edilir.
Oyunun kendi isimleri, yakınlık sınırları ve puan tabloları değiştirilmez.

Eklenti scoreboard oluşturmaz veya oyuncunun scoreboard'unu değiştirmez.
Kapanırken kendi yazıları silinir; KasabaRoles normal kafa üstü öneklerine döner.

## Sağ panel düzeltmesi

Panelin en altında **play.kasabatr.com** tekrar görünür. Oyuncu, rütbe, Akçe,
klan ve süre etiketleri renkli kalır. Discord/Instagram satırları eklenmez;
dar panel korunur. Oyun kendi puan tablosunu gösteriyorsa öncelik ondadır.

## Komutlar

- `/kimlik` veya `/kimlik durum`: kendi rütbe/klanını ve rozet durumunu gösterir.
- `/kimlik yenile`: kimlik ayarlarını yeniden okur. OP, Kurucu'nun mevcut
  `kasabaroles.admin` yetkisi veya `kasabatr.kimlik.admin` gerekir. Konsolda da çalışır.
- `/rol ver Oyuncu rehber` gibi mevcut rol komutları aynı şekilde kullanılır.
- `/klan` mevcut klan menüsüdür.
- `/tablo aç` / `/tablo kapat`: sağ kişisel bilgi panelini açar veya kapatır.

İsteğe bağlı görünüm ayarları otomatik oluşan `KasabaKimlik/config.yml` içindedir:
`height-offset`, `text-scale`, `view-distance`, `refresh-ticks`.
Hiçbir ayarı elle değiştirmek zorunda değilsin.

## Doğrulama

Derleme ve test kanıtı `TEST-SONUCLARI.json`, JAR sağlamaları `SHA256SUMS.txt`
içindedir. Testler izole Paper 1.21.10 sunucusunda protokol istemcileriyle yapılır;
canlı sunucuya yükleme yapılmaz. Towny/PlaceholderAPI isteğe bağlı yolu gerçek
Towny kurulumu ile sınanmaz; metin temizleme ve boş üyelik kuralları birim testlidir.
Bu kontrol bir oyuncu bilgisayarından çekilmiş görsel/video testi değildir.
Vampir Köylü testinde ses istemcisinin bağlı olması özel yerel test aracıyla
benzetilir; gerçek ses aktarımı bu kimlik güncellemesinin test kapsamı değildir.
